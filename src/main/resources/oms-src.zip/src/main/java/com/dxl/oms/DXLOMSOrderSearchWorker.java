package com.dxl.oms;

import java.io.IOException;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.ParseException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;

import com.dxl.oms.bean.OMSAuthTokenResponseBean;
import com.dxl.oms.bean.OrderSearchResponse;
import com.dxl.oms.bean.ordersearch.OrderSearch;
import com.dxl.oms.connection.OMSWorkerInfo;
import com.fasterxml.jackson.databind.ObjectMapper;

import atg.nucleus.GenericService;

/**
 * Worker thread used to handle the thread request to the OMS Gateway Service.
 *
 * @author TAISTech
 */
public class DXLOMSOrderSearchWorker extends GenericService implements Runnable {
	private Thread mWorkerThread = null;

	public static final int RETRY_COUNT = 1;
	private OrderSearchResponse mOrderSearchResponse;
	private String orderNumber;
	private static final String AUTHORIZATION = "Authorization";
	private OMSWorkerInfo omsWorkerInfo;

	/**
	 * constructor
	 *
	 * @param omsResponse
	 *
	 */
	public DXLOMSOrderSearchWorker(OrderSearchResponse orderSearchResponse, String orderNumber, OMSWorkerInfo omsWorkerInfo) {
		this.mOrderSearchResponse = orderSearchResponse;
		this.orderNumber = orderNumber;
		this.omsWorkerInfo = omsWorkerInfo;

		if (mWorkerThread == null) {
			mWorkerThread = new Thread(this, "OMS Order Id Search Communication Thread");
			// start thread
			mWorkerThread.start();
		}
	}

	/**
	 * sends the Order Search Request to the OMS Service.
	 */
	public void run() {

		if (isLoggingDebug()) {
			logDebug("OMS OrderSearch Service is available");
		}
		String responseJSON = null;
		ObjectMapper objectMapper = null;
		HttpResponse response = null;
		if (isLoggingDebug()) {
			logDebug("connectionURL:" + omsWorkerInfo.getOmsOrderSearchEndPointURL());
		}
		HttpClient httpclient = HttpClientBuilder.create().build();
		HttpGet get = new HttpGet(omsWorkerInfo.getOmsOrderSearchEndPointURL().replace("{orderId}", orderNumber));

		String accessToken = omsWorkerInfo.getOmsManager().getAccessToken(false);
		if (accessToken != null) {
			response = getOMSResponse(httpclient, get, accessToken);
			if (response != null && response.getStatusLine().getStatusCode() != 200) {
				HttpEntity entity = response.getEntity();
				try {
					responseJSON = EntityUtils.toString(entity, "UTF-8");
				} catch (ParseException | IOException e) {
					if (isLoggingError()) {
						logError("ParseException | IOException caught: ", e);
					}
				}
				if (isLoggingDebug()) {
					logDebug("omsResponseJSON From DXLOMSOrderSearchWorker=" + responseJSON);
				}
				if (responseJSON != null && responseJSON.contains("invalid_token")) {
					accessToken = omsWorkerInfo.getOmsManager().getAccessToken(true);
					if (accessToken != null) {
						response = getOMSResponse(httpclient, get, accessToken);
					}
				}
			}
		}
		if (response != null && response.getStatusLine().getStatusCode() == 200) {
			synchronized (mOrderSearchResponse) {
				objectMapper = new ObjectMapper();
				try {
					OrderSearch omsResponse = objectMapper.readValue(response.getEntity().getContent(), OrderSearch.class);
					if (omsResponse != null) {
						mOrderSearchResponse.setOmsResponse(omsResponse);
						mOrderSearchResponse.setSuccess(true);
					}
				} catch (IllegalStateException | IOException e) {
					if (isLoggingError()) {
						logError("IllegalStateException | IOException caught: ", e);
					}
				}
			}
		}
		if (isLoggingDebug()) {
			logDebug("Done Worker");
		}
		// Release the connection.
		if (get != null) {
			get.releaseConnection();
		}
		if (isLoggingDebug()) {
			logDebug("communication completed");
		}
	}

	private HttpResponse getOMSResponse(HttpClient httpclient, HttpGet get, String accessToken) {

		String authorizationHeader = omsWorkerInfo.getAuthorizationHeader() + accessToken;
		get.setHeader(AUTHORIZATION, authorizationHeader);
		HttpResponse response = null;
		try {
			response = httpclient.execute(get);
		} catch (IOException e) {
			if (isLoggingError()) {
				logError("IOException caught: ", e);
			}
		}
		return response;
	}

	public OMSWorkerInfo getOmsWorkerInfo() {
		return omsWorkerInfo;
	}

	public void setOmsWorkerInfo(OMSWorkerInfo omsWorkerInfo) {
		this.omsWorkerInfo = omsWorkerInfo;
	}

}
