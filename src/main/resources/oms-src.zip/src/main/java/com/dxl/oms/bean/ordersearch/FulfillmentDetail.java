
package com.dxl.oms.bean.ordersearch;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "ShipmentId",
    "ServiceLevelCode",
    "CreatedTimestamp",
    "TrackingNumber",
    "Process",
    "PackageDetailId",
    "FulfillmentDate",
    "ItemId",
    "FulfillmentId",
    "UpdatedBy",
    "FulfillmentDetailId",
    "ReturnTrackingNumber",
    "GcNumber",
    "UpdatedTimestamp",
    "GiftCardPIN",
    "CreatedBy",
    "Quantity",
    "ShipViaId",
    "GiftCardNumber",
    "ReleaseId",
    "ReleaseLineId",
    "GcPIN",
    "OrgId",
    "UOM",
    "Eta",
    "SerialNumber",
    "ContextId",
    "CarrierCode",
    "StatusId",
    "PackageId",
    "PK"
})
public class FulfillmentDetail {

    @JsonProperty("ShipmentId")
    private String shipmentId;
    @JsonProperty("ServiceLevelCode")
    private String serviceLevelCode;
    @JsonProperty("CreatedTimestamp")
    private String createdTimestamp;
    @JsonProperty("TrackingNumber")
    private String trackingNumber;
    @JsonProperty("Process")
    private Object process;
    @JsonProperty("PackageDetailId")
    private String packageDetailId;
    @JsonProperty("FulfillmentDate")
    private Object fulfillmentDate;
    @JsonProperty("ItemId")
    private String itemId;
    @JsonProperty("FulfillmentId")
    private String fulfillmentId;
    @JsonProperty("UpdatedBy")
    private String updatedBy;
    @JsonProperty("FulfillmentDetailId")
    private String fulfillmentDetailId;
    @JsonProperty("ReturnTrackingNumber")
    private Object returnTrackingNumber;
    @JsonProperty("GcNumber")
    private Object gcNumber;
    @JsonProperty("UpdatedTimestamp")
    private String updatedTimestamp;
    @JsonProperty("GiftCardPIN")
    private Object giftCardPIN;
    @JsonProperty("CreatedBy")
    private String createdBy;
    @JsonProperty("Quantity")
    private Integer quantity;
    @JsonProperty("ShipViaId")
    private String shipViaId;
    @JsonProperty("GiftCardNumber")
    private Object giftCardNumber;
    @JsonProperty("ReleaseId")
    private String releaseId;
    @JsonProperty("ReleaseLineId")
    private String releaseLineId;
    @JsonProperty("GcPIN")
    private Object gcPIN;
    @JsonProperty("OrgId")
    private String orgId;
    @JsonProperty("UOM")
    private String uOM;
    @JsonProperty("Eta")
    private Object eta;
    @JsonProperty("SerialNumber")
    private Object serialNumber;
    @JsonProperty("ContextId")
    private String contextId;
    @JsonProperty("CarrierCode")
    private String carrierCode;
    @JsonProperty("StatusId")
    private String statusId;
    @JsonProperty("PackageId")
    private String packageId;
    @JsonProperty("PK")
    private String pK;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("ShipmentId")
    public String getShipmentId() {
        return shipmentId;
    }

    @JsonProperty("ShipmentId")
    public void setShipmentId(String shipmentId) {
        this.shipmentId = shipmentId;
    }

    @JsonProperty("ServiceLevelCode")
    public String getServiceLevelCode() {
        return serviceLevelCode;
    }

    @JsonProperty("ServiceLevelCode")
    public void setServiceLevelCode(String serviceLevelCode) {
        this.serviceLevelCode = serviceLevelCode;
    }

    @JsonProperty("CreatedTimestamp")
    public String getCreatedTimestamp() {
        return createdTimestamp;
    }

    @JsonProperty("CreatedTimestamp")
    public void setCreatedTimestamp(String createdTimestamp) {
        this.createdTimestamp = createdTimestamp;
    }

    @JsonProperty("TrackingNumber")
    public String getTrackingNumber() {
        return trackingNumber;
    }

    @JsonProperty("TrackingNumber")
    public void setTrackingNumber(String trackingNumber) {
        this.trackingNumber = trackingNumber;
    }

    @JsonProperty("Process")
    public Object getProcess() {
        return process;
    }

    @JsonProperty("Process")
    public void setProcess(Object process) {
        this.process = process;
    }

    @JsonProperty("PackageDetailId")
    public String getPackageDetailId() {
        return packageDetailId;
    }

    @JsonProperty("PackageDetailId")
    public void setPackageDetailId(String packageDetailId) {
        this.packageDetailId = packageDetailId;
    }

    @JsonProperty("FulfillmentDate")
    public Object getFulfillmentDate() {
        return fulfillmentDate;
    }

    @JsonProperty("FulfillmentDate")
    public void setFulfillmentDate(Object fulfillmentDate) {
        this.fulfillmentDate = fulfillmentDate;
    }

    @JsonProperty("ItemId")
    public String getItemId() {
        return itemId;
    }

    @JsonProperty("ItemId")
    public void setItemId(String itemId) {
        this.itemId = itemId;
    }

    @JsonProperty("FulfillmentId")
    public String getFulfillmentId() {
        return fulfillmentId;
    }

    @JsonProperty("FulfillmentId")
    public void setFulfillmentId(String fulfillmentId) {
        this.fulfillmentId = fulfillmentId;
    }

    @JsonProperty("UpdatedBy")
    public String getUpdatedBy() {
        return updatedBy;
    }

    @JsonProperty("UpdatedBy")
    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    @JsonProperty("FulfillmentDetailId")
    public String getFulfillmentDetailId() {
        return fulfillmentDetailId;
    }

    @JsonProperty("FulfillmentDetailId")
    public void setFulfillmentDetailId(String fulfillmentDetailId) {
        this.fulfillmentDetailId = fulfillmentDetailId;
    }

    @JsonProperty("ReturnTrackingNumber")
    public Object getReturnTrackingNumber() {
        return returnTrackingNumber;
    }

    @JsonProperty("ReturnTrackingNumber")
    public void setReturnTrackingNumber(Object returnTrackingNumber) {
        this.returnTrackingNumber = returnTrackingNumber;
    }

    @JsonProperty("GcNumber")
    public Object getGcNumber() {
        return gcNumber;
    }

    @JsonProperty("GcNumber")
    public void setGcNumber(Object gcNumber) {
        this.gcNumber = gcNumber;
    }

    @JsonProperty("UpdatedTimestamp")
    public String getUpdatedTimestamp() {
        return updatedTimestamp;
    }

    @JsonProperty("UpdatedTimestamp")
    public void setUpdatedTimestamp(String updatedTimestamp) {
        this.updatedTimestamp = updatedTimestamp;
    }

    @JsonProperty("GiftCardPIN")
    public Object getGiftCardPIN() {
        return giftCardPIN;
    }

    @JsonProperty("GiftCardPIN")
    public void setGiftCardPIN(Object giftCardPIN) {
        this.giftCardPIN = giftCardPIN;
    }

    @JsonProperty("CreatedBy")
    public String getCreatedBy() {
        return createdBy;
    }

    @JsonProperty("CreatedBy")
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    @JsonProperty("Quantity")
    public Integer getQuantity() {
        return quantity;
    }

    @JsonProperty("Quantity")
    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    @JsonProperty("ShipViaId")
    public String getShipViaId() {
        return shipViaId;
    }

    @JsonProperty("ShipViaId")
    public void setShipViaId(String shipViaId) {
        this.shipViaId = shipViaId;
    }

    @JsonProperty("GiftCardNumber")
    public Object getGiftCardNumber() {
        return giftCardNumber;
    }

    @JsonProperty("GiftCardNumber")
    public void setGiftCardNumber(Object giftCardNumber) {
        this.giftCardNumber = giftCardNumber;
    }

    @JsonProperty("ReleaseId")
    public String getReleaseId() {
        return releaseId;
    }

    @JsonProperty("ReleaseId")
    public void setReleaseId(String releaseId) {
        this.releaseId = releaseId;
    }

    @JsonProperty("ReleaseLineId")
    public String getReleaseLineId() {
        return releaseLineId;
    }

    @JsonProperty("ReleaseLineId")
    public void setReleaseLineId(String releaseLineId) {
        this.releaseLineId = releaseLineId;
    }

    @JsonProperty("GcPIN")
    public Object getGcPIN() {
        return gcPIN;
    }

    @JsonProperty("GcPIN")
    public void setGcPIN(Object gcPIN) {
        this.gcPIN = gcPIN;
    }

    @JsonProperty("OrgId")
    public String getOrgId() {
        return orgId;
    }

    @JsonProperty("OrgId")
    public void setOrgId(String orgId) {
        this.orgId = orgId;
    }

    @JsonProperty("UOM")
    public String getUOM() {
        return uOM;
    }

    @JsonProperty("UOM")
    public void setUOM(String uOM) {
        this.uOM = uOM;
    }

    @JsonProperty("Eta")
    public Object getEta() {
        return eta;
    }

    @JsonProperty("Eta")
    public void setEta(Object eta) {
        this.eta = eta;
    }

    @JsonProperty("SerialNumber")
    public Object getSerialNumber() {
        return serialNumber;
    }

    @JsonProperty("SerialNumber")
    public void setSerialNumber(Object serialNumber) {
        this.serialNumber = serialNumber;
    }

    @JsonProperty("ContextId")
    public String getContextId() {
        return contextId;
    }

    @JsonProperty("ContextId")
    public void setContextId(String contextId) {
        this.contextId = contextId;
    }

    @JsonProperty("CarrierCode")
    public String getCarrierCode() {
        return carrierCode;
    }

    @JsonProperty("CarrierCode")
    public void setCarrierCode(String carrierCode) {
        this.carrierCode = carrierCode;
    }

    @JsonProperty("StatusId")
    public String getStatusId() {
        return statusId;
    }

    @JsonProperty("StatusId")
    public void setStatusId(String statusId) {
        this.statusId = statusId;
    }

    @JsonProperty("PackageId")
    public String getPackageId() {
        return packageId;
    }

    @JsonProperty("PackageId")
    public void setPackageId(String packageId) {
        this.packageId = packageId;
    }

    @JsonProperty("PK")
    public String getPK() {
        return pK;
    }

    @JsonProperty("PK")
    public void setPK(String pK) {
        this.pK = pK;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
