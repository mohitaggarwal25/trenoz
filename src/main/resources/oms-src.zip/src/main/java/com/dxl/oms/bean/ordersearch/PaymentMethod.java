
package com.dxl.oms.bean.ordersearch;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "Actions",
    "PK",
    "CreatedBy",
    "CreatedTimestamp",
    "UpdatedBy",
    "UpdatedTimestamp",
    "Translations",
    "Messages",
    "OrgId",
    "PaymentMethodId",
    "CurrencyCode",
    "AlternateCurrencyCode",
    "ConversionRate",
    "AlternateCurrencyAmount",
    "AccountNumber",
    "AccountDisplayNumber",
    "NameOnCard",
    "SwipeData",
    "CardExpiryMonth",
    "CardExpiryYear",
    "GiftCardPin",
    "CustomerSignature",
    "CustomerPaySignature",
    "ChangeAmount",
    "Amount",
    "CurrentAuthAmount",
    "CurrentSettledAmount",
    "CurrentRefundAmount",
    "ChargeSequence",
    "IsSuspended",
    "EntryTypeId",
    "GatewayId",
    "RoutingNumber",
    "RoutingDisplayNumber",
    "CheckNumber",
    "DriversLicenseNumber",
    "DriversLicenseState",
    "DriversLicenseCountry",
    "BusinessName",
    "BusinessTaxId",
    "CheckQuantity",
    "OriginalAmount",
    "IsModifiable",
    "CurrentFailedAmount",
    "ParentOrderId",
    "ParentPaymentGroupId",
    "ParentPaymentMethodId",
    "IsVoided",
    "IsCopied",
    "GatewayAccountId",
    "LocationId",
    "TransactionReferenceId",
    "CapturedInEdgeMode",
    "BillingAddress",
    "PaymentMethodAttribute",
    "PaymentMethodEncrAttribute",
    "PaymentTransaction",
    "ParentOrderPaymentMethod",
    "PaymentType",
    "AccountType",
    "Extended",
    "CardType"
})
public class PaymentMethod {

    @JsonProperty("Actions")
    private Actions_ actions;
    @JsonProperty("PK")
    private String pK;
    @JsonProperty("CreatedBy")
    private String createdBy;
    @JsonProperty("CreatedTimestamp")
    private String createdTimestamp;
    @JsonProperty("UpdatedBy")
    private String updatedBy;
    @JsonProperty("UpdatedTimestamp")
    private String updatedTimestamp;
    @JsonProperty("Translations")
    private Object translations;
    @JsonProperty("Messages")
    private Object messages;
    @JsonProperty("OrgId")
    private String orgId;
    @JsonProperty("PaymentMethodId")
    private String paymentMethodId;
    @JsonProperty("CurrencyCode")
    private String currencyCode;
    @JsonProperty("AlternateCurrencyCode")
    private Object alternateCurrencyCode;
    @JsonProperty("ConversionRate")
    private Object conversionRate;
    @JsonProperty("AlternateCurrencyAmount")
    private Object alternateCurrencyAmount;
    @JsonProperty("AccountNumber")
    private String accountNumber;
    @JsonProperty("AccountDisplayNumber")
    private String accountDisplayNumber;
    @JsonProperty("NameOnCard")
    private String nameOnCard;
    @JsonProperty("SwipeData")
    private Object swipeData;
    @JsonProperty("CardExpiryMonth")
    private String cardExpiryMonth;
    @JsonProperty("CardExpiryYear")
    private String cardExpiryYear;
    @JsonProperty("GiftCardPin")
    private Object giftCardPin;
    @JsonProperty("CustomerSignature")
    private Object customerSignature;
    @JsonProperty("CustomerPaySignature")
    private Object customerPaySignature;
    @JsonProperty("ChangeAmount")
    private Object changeAmount;
    @JsonProperty("Amount")
    private Double amount;
    @JsonProperty("CurrentAuthAmount")
    private Double currentAuthAmount;
    @JsonProperty("CurrentSettledAmount")
    private Integer currentSettledAmount;
    @JsonProperty("CurrentRefundAmount")
    private Integer currentRefundAmount;
    @JsonProperty("ChargeSequence")
    private Object chargeSequence;
    @JsonProperty("IsSuspended")
    private Boolean isSuspended;
    @JsonProperty("EntryTypeId")
    private Object entryTypeId;
    @JsonProperty("GatewayId")
    private Object gatewayId;
    @JsonProperty("RoutingNumber")
    private Object routingNumber;
    @JsonProperty("RoutingDisplayNumber")
    private Object routingDisplayNumber;
    @JsonProperty("CheckNumber")
    private Object checkNumber;
    @JsonProperty("DriversLicenseNumber")
    private Object driversLicenseNumber;
    @JsonProperty("DriversLicenseState")
    private Object driversLicenseState;
    @JsonProperty("DriversLicenseCountry")
    private Object driversLicenseCountry;
    @JsonProperty("BusinessName")
    private Object businessName;
    @JsonProperty("BusinessTaxId")
    private Object businessTaxId;
    @JsonProperty("CheckQuantity")
    private Object checkQuantity;
    @JsonProperty("OriginalAmount")
    private Object originalAmount;
    @JsonProperty("IsModifiable")
    private Boolean isModifiable;
    @JsonProperty("CurrentFailedAmount")
    private Integer currentFailedAmount;
    @JsonProperty("ParentOrderId")
    private Object parentOrderId;
    @JsonProperty("ParentPaymentGroupId")
    private Object parentPaymentGroupId;
    @JsonProperty("ParentPaymentMethodId")
    private Object parentPaymentMethodId;
    @JsonProperty("IsVoided")
    private Boolean isVoided;
    @JsonProperty("IsCopied")
    private Boolean isCopied;
    @JsonProperty("GatewayAccountId")
    private Object gatewayAccountId;
    @JsonProperty("LocationId")
    private Object locationId;
    @JsonProperty("TransactionReferenceId")
    private Object transactionReferenceId;
    @JsonProperty("CapturedInEdgeMode")
    private Boolean capturedInEdgeMode;
    @JsonProperty("BillingAddress")
    private BillingAddress billingAddress;
    @JsonProperty("PaymentMethodAttribute")
    private List<Object> paymentMethodAttribute = null;
    @JsonProperty("PaymentMethodEncrAttribute")
    private List<Object> paymentMethodEncrAttribute = null;
    @JsonProperty("PaymentTransaction")
    private List<PaymentTransaction> paymentTransaction = null;
    @JsonProperty("ParentOrderPaymentMethod")
    private List<Object> parentOrderPaymentMethod = null;
    @JsonProperty("PaymentType")
    private PaymentType paymentType;
    @JsonProperty("AccountType")
    private Object accountType;
    @JsonProperty("Extended")
    private Extended__ extended;
    @JsonProperty("CardType")
    private CardType cardType;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("Actions")
    public Actions_ getActions() {
        return actions;
    }

    @JsonProperty("Actions")
    public void setActions(Actions_ actions) {
        this.actions = actions;
    }

    @JsonProperty("PK")
    public String getPK() {
        return pK;
    }

    @JsonProperty("PK")
    public void setPK(String pK) {
        this.pK = pK;
    }

    @JsonProperty("CreatedBy")
    public String getCreatedBy() {
        return createdBy;
    }

    @JsonProperty("CreatedBy")
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    @JsonProperty("CreatedTimestamp")
    public String getCreatedTimestamp() {
        return createdTimestamp;
    }

    @JsonProperty("CreatedTimestamp")
    public void setCreatedTimestamp(String createdTimestamp) {
        this.createdTimestamp = createdTimestamp;
    }

    @JsonProperty("UpdatedBy")
    public String getUpdatedBy() {
        return updatedBy;
    }

    @JsonProperty("UpdatedBy")
    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    @JsonProperty("UpdatedTimestamp")
    public String getUpdatedTimestamp() {
        return updatedTimestamp;
    }

    @JsonProperty("UpdatedTimestamp")
    public void setUpdatedTimestamp(String updatedTimestamp) {
        this.updatedTimestamp = updatedTimestamp;
    }

    @JsonProperty("Translations")
    public Object getTranslations() {
        return translations;
    }

    @JsonProperty("Translations")
    public void setTranslations(Object translations) {
        this.translations = translations;
    }

    @JsonProperty("Messages")
    public Object getMessages() {
        return messages;
    }

    @JsonProperty("Messages")
    public void setMessages(Object messages) {
        this.messages = messages;
    }

    @JsonProperty("OrgId")
    public String getOrgId() {
        return orgId;
    }

    @JsonProperty("OrgId")
    public void setOrgId(String orgId) {
        this.orgId = orgId;
    }

    @JsonProperty("PaymentMethodId")
    public String getPaymentMethodId() {
        return paymentMethodId;
    }

    @JsonProperty("PaymentMethodId")
    public void setPaymentMethodId(String paymentMethodId) {
        this.paymentMethodId = paymentMethodId;
    }

    @JsonProperty("CurrencyCode")
    public String getCurrencyCode() {
        return currencyCode;
    }

    @JsonProperty("CurrencyCode")
    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    @JsonProperty("AlternateCurrencyCode")
    public Object getAlternateCurrencyCode() {
        return alternateCurrencyCode;
    }

    @JsonProperty("AlternateCurrencyCode")
    public void setAlternateCurrencyCode(Object alternateCurrencyCode) {
        this.alternateCurrencyCode = alternateCurrencyCode;
    }

    @JsonProperty("ConversionRate")
    public Object getConversionRate() {
        return conversionRate;
    }

    @JsonProperty("ConversionRate")
    public void setConversionRate(Object conversionRate) {
        this.conversionRate = conversionRate;
    }

    @JsonProperty("AlternateCurrencyAmount")
    public Object getAlternateCurrencyAmount() {
        return alternateCurrencyAmount;
    }

    @JsonProperty("AlternateCurrencyAmount")
    public void setAlternateCurrencyAmount(Object alternateCurrencyAmount) {
        this.alternateCurrencyAmount = alternateCurrencyAmount;
    }

    @JsonProperty("AccountNumber")
    public String getAccountNumber() {
        return accountNumber;
    }

    @JsonProperty("AccountNumber")
    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    @JsonProperty("AccountDisplayNumber")
    public String getAccountDisplayNumber() {
        return accountDisplayNumber;
    }

    @JsonProperty("AccountDisplayNumber")
    public void setAccountDisplayNumber(String accountDisplayNumber) {
        this.accountDisplayNumber = accountDisplayNumber;
    }

    @JsonProperty("NameOnCard")
    public String getNameOnCard() {
        return nameOnCard;
    }

    @JsonProperty("NameOnCard")
    public void setNameOnCard(String nameOnCard) {
        this.nameOnCard = nameOnCard;
    }

    @JsonProperty("CardType")
    public CardType getCardType() {
        return cardType;
    }

    @JsonProperty("CardType")
    public void setCardType(CardType cardType) {
        this.cardType = cardType;
    }

    @JsonProperty("SwipeData")
    public Object getSwipeData() {
        return swipeData;
    }

    @JsonProperty("SwipeData")
    public void setSwipeData(Object swipeData) {
        this.swipeData = swipeData;
    }

    @JsonProperty("CardExpiryMonth")
    public String getCardExpiryMonth() {
        return cardExpiryMonth;
    }

    @JsonProperty("CardExpiryMonth")
    public void setCardExpiryMonth(String cardExpiryMonth) {
        this.cardExpiryMonth = cardExpiryMonth;
    }

    @JsonProperty("CardExpiryYear")
    public String getCardExpiryYear() {
        return cardExpiryYear;
    }

    @JsonProperty("CardExpiryYear")
    public void setCardExpiryYear(String cardExpiryYear) {
        this.cardExpiryYear = cardExpiryYear;
    }

    @JsonProperty("GiftCardPin")
    public Object getGiftCardPin() {
        return giftCardPin;
    }

    @JsonProperty("GiftCardPin")
    public void setGiftCardPin(Object giftCardPin) {
        this.giftCardPin = giftCardPin;
    }

    @JsonProperty("CustomerSignature")
    public Object getCustomerSignature() {
        return customerSignature;
    }

    @JsonProperty("CustomerSignature")
    public void setCustomerSignature(Object customerSignature) {
        this.customerSignature = customerSignature;
    }

    @JsonProperty("CustomerPaySignature")
    public Object getCustomerPaySignature() {
        return customerPaySignature;
    }

    @JsonProperty("CustomerPaySignature")
    public void setCustomerPaySignature(Object customerPaySignature) {
        this.customerPaySignature = customerPaySignature;
    }

    @JsonProperty("ChangeAmount")
    public Object getChangeAmount() {
        return changeAmount;
    }

    @JsonProperty("ChangeAmount")
    public void setChangeAmount(Object changeAmount) {
        this.changeAmount = changeAmount;
    }

    @JsonProperty("Amount")
    public Double getAmount() {
        return amount;
    }

    @JsonProperty("Amount")
    public void setAmount(Double amount) {
        this.amount = amount;
    }

    @JsonProperty("CurrentAuthAmount")
    public Double getCurrentAuthAmount() {
        return currentAuthAmount;
    }

    @JsonProperty("CurrentAuthAmount")
    public void setCurrentAuthAmount(Double currentAuthAmount) {
        this.currentAuthAmount = currentAuthAmount;
    }

    @JsonProperty("CurrentSettledAmount")
    public Integer getCurrentSettledAmount() {
        return currentSettledAmount;
    }

    @JsonProperty("CurrentSettledAmount")
    public void setCurrentSettledAmount(Integer currentSettledAmount) {
        this.currentSettledAmount = currentSettledAmount;
    }

    @JsonProperty("CurrentRefundAmount")
    public Integer getCurrentRefundAmount() {
        return currentRefundAmount;
    }

    @JsonProperty("CurrentRefundAmount")
    public void setCurrentRefundAmount(Integer currentRefundAmount) {
        this.currentRefundAmount = currentRefundAmount;
    }

    @JsonProperty("ChargeSequence")
    public Object getChargeSequence() {
        return chargeSequence;
    }

    @JsonProperty("ChargeSequence")
    public void setChargeSequence(Object chargeSequence) {
        this.chargeSequence = chargeSequence;
    }

    @JsonProperty("IsSuspended")
    public Boolean getIsSuspended() {
        return isSuspended;
    }

    @JsonProperty("IsSuspended")
    public void setIsSuspended(Boolean isSuspended) {
        this.isSuspended = isSuspended;
    }

    @JsonProperty("EntryTypeId")
    public Object getEntryTypeId() {
        return entryTypeId;
    }

    @JsonProperty("EntryTypeId")
    public void setEntryTypeId(Object entryTypeId) {
        this.entryTypeId = entryTypeId;
    }

    @JsonProperty("GatewayId")
    public Object getGatewayId() {
        return gatewayId;
    }

    @JsonProperty("GatewayId")
    public void setGatewayId(Object gatewayId) {
        this.gatewayId = gatewayId;
    }

    @JsonProperty("RoutingNumber")
    public Object getRoutingNumber() {
        return routingNumber;
    }

    @JsonProperty("RoutingNumber")
    public void setRoutingNumber(Object routingNumber) {
        this.routingNumber = routingNumber;
    }

    @JsonProperty("RoutingDisplayNumber")
    public Object getRoutingDisplayNumber() {
        return routingDisplayNumber;
    }

    @JsonProperty("RoutingDisplayNumber")
    public void setRoutingDisplayNumber(Object routingDisplayNumber) {
        this.routingDisplayNumber = routingDisplayNumber;
    }

    @JsonProperty("CheckNumber")
    public Object getCheckNumber() {
        return checkNumber;
    }

    @JsonProperty("CheckNumber")
    public void setCheckNumber(Object checkNumber) {
        this.checkNumber = checkNumber;
    }

    @JsonProperty("DriversLicenseNumber")
    public Object getDriversLicenseNumber() {
        return driversLicenseNumber;
    }

    @JsonProperty("DriversLicenseNumber")
    public void setDriversLicenseNumber(Object driversLicenseNumber) {
        this.driversLicenseNumber = driversLicenseNumber;
    }

    @JsonProperty("DriversLicenseState")
    public Object getDriversLicenseState() {
        return driversLicenseState;
    }

    @JsonProperty("DriversLicenseState")
    public void setDriversLicenseState(Object driversLicenseState) {
        this.driversLicenseState = driversLicenseState;
    }

    @JsonProperty("DriversLicenseCountry")
    public Object getDriversLicenseCountry() {
        return driversLicenseCountry;
    }

    @JsonProperty("DriversLicenseCountry")
    public void setDriversLicenseCountry(Object driversLicenseCountry) {
        this.driversLicenseCountry = driversLicenseCountry;
    }

    @JsonProperty("BusinessName")
    public Object getBusinessName() {
        return businessName;
    }

    @JsonProperty("BusinessName")
    public void setBusinessName(Object businessName) {
        this.businessName = businessName;
    }

    @JsonProperty("BusinessTaxId")
    public Object getBusinessTaxId() {
        return businessTaxId;
    }

    @JsonProperty("BusinessTaxId")
    public void setBusinessTaxId(Object businessTaxId) {
        this.businessTaxId = businessTaxId;
    }

    @JsonProperty("CheckQuantity")
    public Object getCheckQuantity() {
        return checkQuantity;
    }

    @JsonProperty("CheckQuantity")
    public void setCheckQuantity(Object checkQuantity) {
        this.checkQuantity = checkQuantity;
    }

    @JsonProperty("OriginalAmount")
    public Object getOriginalAmount() {
        return originalAmount;
    }

    @JsonProperty("OriginalAmount")
    public void setOriginalAmount(Object originalAmount) {
        this.originalAmount = originalAmount;
    }

    @JsonProperty("IsModifiable")
    public Boolean getIsModifiable() {
        return isModifiable;
    }

    @JsonProperty("IsModifiable")
    public void setIsModifiable(Boolean isModifiable) {
        this.isModifiable = isModifiable;
    }

    @JsonProperty("CurrentFailedAmount")
    public Integer getCurrentFailedAmount() {
        return currentFailedAmount;
    }

    @JsonProperty("CurrentFailedAmount")
    public void setCurrentFailedAmount(Integer currentFailedAmount) {
        this.currentFailedAmount = currentFailedAmount;
    }

    @JsonProperty("ParentOrderId")
    public Object getParentOrderId() {
        return parentOrderId;
    }

    @JsonProperty("ParentOrderId")
    public void setParentOrderId(Object parentOrderId) {
        this.parentOrderId = parentOrderId;
    }

    @JsonProperty("ParentPaymentGroupId")
    public Object getParentPaymentGroupId() {
        return parentPaymentGroupId;
    }

    @JsonProperty("ParentPaymentGroupId")
    public void setParentPaymentGroupId(Object parentPaymentGroupId) {
        this.parentPaymentGroupId = parentPaymentGroupId;
    }

    @JsonProperty("ParentPaymentMethodId")
    public Object getParentPaymentMethodId() {
        return parentPaymentMethodId;
    }

    @JsonProperty("ParentPaymentMethodId")
    public void setParentPaymentMethodId(Object parentPaymentMethodId) {
        this.parentPaymentMethodId = parentPaymentMethodId;
    }

    @JsonProperty("IsVoided")
    public Boolean getIsVoided() {
        return isVoided;
    }

    @JsonProperty("IsVoided")
    public void setIsVoided(Boolean isVoided) {
        this.isVoided = isVoided;
    }

    @JsonProperty("IsCopied")
    public Boolean getIsCopied() {
        return isCopied;
    }

    @JsonProperty("IsCopied")
    public void setIsCopied(Boolean isCopied) {
        this.isCopied = isCopied;
    }

    @JsonProperty("GatewayAccountId")
    public Object getGatewayAccountId() {
        return gatewayAccountId;
    }

    @JsonProperty("GatewayAccountId")
    public void setGatewayAccountId(Object gatewayAccountId) {
        this.gatewayAccountId = gatewayAccountId;
    }

    @JsonProperty("LocationId")
    public Object getLocationId() {
        return locationId;
    }

    @JsonProperty("LocationId")
    public void setLocationId(Object locationId) {
        this.locationId = locationId;
    }

    @JsonProperty("TransactionReferenceId")
    public Object getTransactionReferenceId() {
        return transactionReferenceId;
    }

    @JsonProperty("TransactionReferenceId")
    public void setTransactionReferenceId(Object transactionReferenceId) {
        this.transactionReferenceId = transactionReferenceId;
    }

    @JsonProperty("CapturedInEdgeMode")
    public Boolean getCapturedInEdgeMode() {
        return capturedInEdgeMode;
    }

    @JsonProperty("CapturedInEdgeMode")
    public void setCapturedInEdgeMode(Boolean capturedInEdgeMode) {
        this.capturedInEdgeMode = capturedInEdgeMode;
    }

    @JsonProperty("BillingAddress")
    public BillingAddress getBillingAddress() {
        return billingAddress;
    }

    @JsonProperty("BillingAddress")
    public void setBillingAddress(BillingAddress billingAddress) {
        this.billingAddress = billingAddress;
    }

    @JsonProperty("PaymentMethodAttribute")
    public List<Object> getPaymentMethodAttribute() {
        return paymentMethodAttribute;
    }

    @JsonProperty("PaymentMethodAttribute")
    public void setPaymentMethodAttribute(List<Object> paymentMethodAttribute) {
        this.paymentMethodAttribute = paymentMethodAttribute;
    }

    @JsonProperty("PaymentMethodEncrAttribute")
    public List<Object> getPaymentMethodEncrAttribute() {
        return paymentMethodEncrAttribute;
    }

    @JsonProperty("PaymentMethodEncrAttribute")
    public void setPaymentMethodEncrAttribute(List<Object> paymentMethodEncrAttribute) {
        this.paymentMethodEncrAttribute = paymentMethodEncrAttribute;
    }

    @JsonProperty("PaymentTransaction")
    public List<PaymentTransaction> getPaymentTransaction() {
        return paymentTransaction;
    }

    @JsonProperty("PaymentTransaction")
    public void setPaymentTransaction(List<PaymentTransaction> paymentTransaction) {
        this.paymentTransaction = paymentTransaction;
    }

    @JsonProperty("ParentOrderPaymentMethod")
    public List<Object> getParentOrderPaymentMethod() {
        return parentOrderPaymentMethod;
    }

    @JsonProperty("ParentOrderPaymentMethod")
    public void setParentOrderPaymentMethod(List<Object> parentOrderPaymentMethod) {
        this.parentOrderPaymentMethod = parentOrderPaymentMethod;
    }

    @JsonProperty("PaymentType")
    public PaymentType getPaymentType() {
        return paymentType;
    }

    @JsonProperty("PaymentType")
    public void setPaymentType(PaymentType paymentType) {
        this.paymentType = paymentType;
    }

    @JsonProperty("AccountType")
    public Object getAccountType() {
        return accountType;
    }

    @JsonProperty("AccountType")
    public void setAccountType(Object accountType) {
        this.accountType = accountType;
    }

    @JsonProperty("Extended")
    public Extended__ getExtended() {
        return extended;
    }

    @JsonProperty("Extended")
    public void setExtended(Extended__ extended) {
        this.extended = extended;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
