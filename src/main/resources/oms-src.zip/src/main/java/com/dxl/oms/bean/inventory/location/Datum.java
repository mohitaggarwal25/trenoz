
package com.dxl.oms.bean.inventory.location;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "ItemId",
    "LocationId",
    "Status",
    "StatusCode",
    "Quantity",
    "NextAvailabilityDate",
    "TransactionDateTime",
    "ViewName",
    "ViewId"
})
public class Datum {

    @JsonProperty("ItemId")
    private String itemId;
    @JsonProperty("LocationId")
    private String locationId;
    @JsonProperty("Status")
    private String status;
    @JsonProperty("StatusCode")
    private Integer statusCode;
    @JsonProperty("Quantity")
    private Integer quantity;
    @JsonProperty("NextAvailabilityDate")
    private Object nextAvailabilityDate;
    @JsonProperty("TransactionDateTime")
    private String transactionDateTime;
    @JsonProperty("ViewName")
    private String viewName;
    @JsonProperty("ViewId")
    private String viewId;

    @JsonProperty("ItemId")
    public String getItemId() {
        return itemId;
    }

    @JsonProperty("ItemId")
    public void setItemId(String itemId) {
        this.itemId = itemId;
    }

    @JsonProperty("LocationId")
    public String getLocationId() {
        return locationId;
    }

    @JsonProperty("LocationId")
    public void setLocationId(String locationId) {
        this.locationId = locationId;
    }

    @JsonProperty("Status")
    public String getStatus() {
        return status;
    }

    @JsonProperty("Status")
    public void setStatus(String status) {
        this.status = status;
    }

    @JsonProperty("StatusCode")
    public Integer getStatusCode() {
        return statusCode;
    }

    @JsonProperty("StatusCode")
    public void setStatusCode(Integer statusCode) {
        this.statusCode = statusCode;
    }

    @JsonProperty("Quantity")
    public Integer getQuantity() {
        return quantity;
    }

    @JsonProperty("Quantity")
    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    @JsonProperty("NextAvailabilityDate")
    public Object getNextAvailabilityDate() {
        return nextAvailabilityDate;
    }

    @JsonProperty("NextAvailabilityDate")
    public void setNextAvailabilityDate(Object nextAvailabilityDate) {
        this.nextAvailabilityDate = nextAvailabilityDate;
    }

    @JsonProperty("TransactionDateTime")
    public String getTransactionDateTime() {
        return transactionDateTime;
    }

    @JsonProperty("TransactionDateTime")
    public void setTransactionDateTime(String transactionDateTime) {
        this.transactionDateTime = transactionDateTime;
    }

    @JsonProperty("ViewName")
    public String getViewName() {
        return viewName;
    }

    @JsonProperty("ViewName")
    public void setViewName(String viewName) {
        this.viewName = viewName;
    }

    @JsonProperty("ViewId")
    public String getViewId() {
        return viewId;
    }

    @JsonProperty("ViewId")
    public void setViewId(String viewId) {
        this.viewId = viewId;
    }

}
