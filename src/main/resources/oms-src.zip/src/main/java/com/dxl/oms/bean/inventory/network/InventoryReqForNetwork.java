package com.dxl.oms.bean.inventory.network;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
	"Items",
	"ViewName"
})
public class InventoryReqForNetwork {

	@JsonProperty("Items")
	private List<String> items = null;
	@JsonProperty("ViewName")
	private String viewName;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	@JsonProperty("Items")
	public List<String> getItems() {
		return items;
	}

	@JsonProperty("Items")
	public void setItems(List<String> items) {
		this.items = items;
	}

	@JsonProperty("ViewName")
	public String getViewName() {
		return viewName;
	}

	@JsonProperty("ViewName")
	public void setViewName(String viewName) {
		this.viewName = viewName;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

}