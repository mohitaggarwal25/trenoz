package com.dxl.oms;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.AmazonSQSClientBuilder;
import com.amazonaws.services.sqs.model.Message;
import com.amazonaws.services.sqs.model.MessageAttributeValue;
import com.amazonaws.services.sqs.model.ReceiveMessageRequest;
import com.amazonaws.services.sqs.model.ReceiveMessageResult;
import com.amazonaws.services.sqs.model.SendMessageRequest;

import atg.nucleus.GenericService;
import atg.nucleus.ServiceException;

/**
 *
 * @author TAISTech
 */
public class DXLSQSClient extends GenericService {


	private String accessKey;
	private String secretKey;
	private String queueName;
	private String organizationId;
	private String user;
	private String msgType;
	
	
	BasicAWSCredentials awsCreds = null;
	AmazonSQS sqs = null;
	
	public void initiateQueue() {
		try {
			this.awsCreds = new BasicAWSCredentials(getAccessKey(), getSecretKey());
			this.sqs = AmazonSQSClientBuilder.standard().
					withCredentials(new AWSStaticCredentialsProvider(awsCreds)).withRegion(Regions.US_WEST_2).build();
	
		} catch(Exception e) {
			if(isLoggingError()){
				logError("Exception occured while initialysing SQS client: "+e);
			}
		}
	}
	public void sendMessageToQueue(String queueName, String message) {

		if(isLoggingDebug()) {
			logDebug("Sending message to SQS");
			logDebug("SQS Client: queueName "+queueName);
			logDebug("SQS Client: message "+message);
		}
		
		if(this.sqs == null) {
			initiateQueue();
		}
		
		String queueUrl = this.sqs.getQueueUrl(queueName).getQueueUrl();
		SendMessageRequest send_msg_request = new SendMessageRequest()
                .withQueueUrl(queueUrl)
                .withMessageBody(message)
                .withDelaySeconds(5);
		try {
			send_msg_request.setMessageAttributes(getMessageAttributes());
			this.sqs.sendMessage(send_msg_request);
		} catch (Exception e) {
			if(isLoggingError()){
				logError("Exception occured while sending message to SQS client: "+e);
			}
		}
	}
	
	public List<Message> receiveMessageFromQueue(String queueName) {
		List<Message> messageList = null;
		if(isLoggingDebug()) {
			logDebug("Receiving message from SQS");
			logDebug("SQS Client: queueName "+queueName);
		}
		
		if(this.sqs == null) {
			initiateQueue();
		}
		
		String queueUrl = this.sqs.getQueueUrl(queueName).getQueueUrl();
		ReceiveMessageRequest receive_msg_request = new ReceiveMessageRequest(queueUrl);
		receive_msg_request.setWaitTimeSeconds(5);
		
		try {
			final ReceiveMessageResult result = this.sqs.receiveMessage(receive_msg_request);
			messageList = result.getMessages();
			
		} catch (Exception e) {
			if(isLoggingError()){
				logError("Exception occured while receiving messages from SQS client: "+e);
			}
		}
		return messageList;
	}
	
	
	/* (non-Javadoc)
	 * @see atg.nucleus.GenericService#doStartService()
	 */
	@Override
	public void doStartService() throws ServiceException {
		try {
			this.awsCreds = new BasicAWSCredentials(getAccessKey(), getSecretKey());
			this.sqs = AmazonSQSClientBuilder.standard().
					withCredentials(new AWSStaticCredentialsProvider(awsCreds)).withRegion(Regions.US_WEST_2).build();
	
		} catch(Exception e) {
			if(isLoggingError()){
				logError("Exception occured while initialysing SQS client: "+e);
			}
		}
		super.doStartService();
	}
	
	
	private Map<String, MessageAttributeValue> getMessageAttributes()
    {
        Map<String, MessageAttributeValue> messageAttributes = new HashMap<String, MessageAttributeValue>(3);
        MessageAttributeValue orgAttribute = new MessageAttributeValue();

        orgAttribute.setStringValue("{\"Organization\":\"" + getOrganizationId()
                + "\",\"MSG_TYPE\":\"" + getMsgType() + "\",\"User\":\""
                + getUser() + "\"}");
        orgAttribute.setDataType("String");
        messageAttributes.put("MSG_HEADER", orgAttribute);
        return messageAttributes;
    }
	 
	/**
	 * @return the accessKey
	 */
	public String getAccessKey() {
		return accessKey;
	}
	/**
	 * @param accessKey the accessKey to set
	 */
	public void setAccessKey(String accessKey) {
		this.accessKey = accessKey;
	}
	/**
	 * @return the secretKey
	 */
	public String getSecretKey() {
		return secretKey;
	}
	/**
	 * @param secretKey the secretKey to set
	 */
	public void setSecretKey(String secretKey) {
		this.secretKey = secretKey;
	}
	/**
	 * @return the queueName
	 */
	public String getQueueName() {
		return queueName;
	}
	/**
	 * @param queueName the queueName to set
	 */
	public void setQueueName(String queueName) {
		this.queueName = queueName;
	}
	/**
	 * @return the organizationId
	 */
	public String getOrganizationId() {
		return organizationId;
	}
	/**
	 * @param organizationId the organizationId to set
	 */
	public void setOrganizationId(String organizationId) {
		this.organizationId = organizationId;
	}
	/**
	 * @return the msgType
	 */
	public String getMsgType() {
		return msgType;
	}
	/**
	 * @param msgType the msgType to set
	 */
	public void setMsgType(String msgType) {
		this.msgType = msgType;
	}
	/**
	 * @return the user
	 */
	public String getUser() {
		return user;
	}
	/**
	 * @param user the user to set
	 */
	public void setUser(String user) {
		this.user = user;
	}
	
	
}
