package com.dxl.oms.inventory;

import java.util.ArrayList;
import java.util.List;

import com.dxl.bean.storeLocator.InventoryData;
import com.dxl.oms.bean.inventory.location.Datum;
import com.dxl.oms.bean.inventory.location.InventoryForLocation;

import atg.nucleus.GenericService;

public class DXLOMSInventoryByLocationDataPopulator extends GenericService {
	
	public List<InventoryData> populateData(InventoryForLocation inventoryForLocation){
		List<InventoryData> inventoryDataList = new ArrayList<InventoryData>();
		if(inventoryForLocation!=null){
			List<Datum> data = inventoryForLocation.getData();
			for (Datum datum : data) {
				InventoryData inventoryData = new InventoryData();
				inventoryData.setItemId(datum.getItemId());
				inventoryData.setLocationId(datum.getLocationId());
				inventoryData.setStatus(datum.getStatus());
				inventoryData.setQuantity(datum.getQuantity());
				inventoryDataList.add(inventoryData);
			}
		}else{
			vlogError("InventoryForLocation is null : {0}",inventoryForLocation);
		}
		return inventoryDataList;
	}
}
