
package com.dxl.oms.bean.ordersearch;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "CreatedTimestamp",
    "PublishCount",
    "Process",
    "FailedAmount",
    "InvoiceId",
    "FulfillmentDate",
    "SellingLocationId",
    "UpdatedBy",
    "AmountProcessed",
    "TotalCharges",
    "InvoiceSubTotal",
    "ParentOrderId",
    "TaxExemptId",
    "PublishStatus",
    "Status",
    "UpdatedTimestamp",
    "CreatedBy",
    "InvoiceLine",
    "InvoiceChargeDetail",
    "CustomerId",
    "InvoiceType",
    "OrgId",
    "InvoiceTotal",
    "TotalTaxes",
    "ContextId",
    "PackageId",
    "PK",
    "InvoiceTaxDetail",
    "TotalDiscounts"
})
public class Invoice {

    @JsonProperty("CreatedTimestamp")
    private String createdTimestamp;
    @JsonProperty("PublishCount")
    private Object publishCount;
    @JsonProperty("Process")
    private Object process;
    @JsonProperty("FailedAmount")
    private Object failedAmount;
    @JsonProperty("InvoiceId")
    private String invoiceId;
    @JsonProperty("FulfillmentDate")
    private Object fulfillmentDate;
    @JsonProperty("SellingLocationId")
    private Object sellingLocationId;
    @JsonProperty("UpdatedBy")
    private String updatedBy;
    @JsonProperty("AmountProcessed")
    private Object amountProcessed;
    @JsonProperty("TotalCharges")
    private Integer totalCharges;
    @JsonProperty("InvoiceSubTotal")
    private Double invoiceSubTotal;
    @JsonProperty("ParentOrderId")
    private Object parentOrderId;
    @JsonProperty("TaxExemptId")
    private Object taxExemptId;
    @JsonProperty("PublishStatus")
    private PublishStatus publishStatus;
    @JsonProperty("Status")
    private Status status;
    @JsonProperty("UpdatedTimestamp")
    private String updatedTimestamp;
    @JsonProperty("CreatedBy")
    private String createdBy;
    @JsonProperty("InvoiceLine")
    private List<InvoiceLine> invoiceLine = null;
    @JsonProperty("InvoiceChargeDetail")
    private List<Object> invoiceChargeDetail = null;
    @JsonProperty("CustomerId")
    private String customerId;
    @JsonProperty("InvoiceType")
    private InvoiceType invoiceType;
    @JsonProperty("OrgId")
    private String orgId;
    @JsonProperty("InvoiceTotal")
    private Double invoiceTotal;
    @JsonProperty("TotalTaxes")
    private Double totalTaxes;
    @JsonProperty("ContextId")
    private String contextId;
    @JsonProperty("PackageId")
    private String packageId;
    @JsonProperty("PK")
    private String pK;
    @JsonProperty("InvoiceTaxDetail")
    private List<Object> invoiceTaxDetail = null;
    @JsonProperty("TotalDiscounts")
    private Integer totalDiscounts;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("CreatedTimestamp")
    public String getCreatedTimestamp() {
        return createdTimestamp;
    }

    @JsonProperty("CreatedTimestamp")
    public void setCreatedTimestamp(String createdTimestamp) {
        this.createdTimestamp = createdTimestamp;
    }

    @JsonProperty("PublishCount")
    public Object getPublishCount() {
        return publishCount;
    }

    @JsonProperty("PublishCount")
    public void setPublishCount(Object publishCount) {
        this.publishCount = publishCount;
    }

    @JsonProperty("Process")
    public Object getProcess() {
        return process;
    }

    @JsonProperty("Process")
    public void setProcess(Object process) {
        this.process = process;
    }

    @JsonProperty("FailedAmount")
    public Object getFailedAmount() {
        return failedAmount;
    }

    @JsonProperty("FailedAmount")
    public void setFailedAmount(Object failedAmount) {
        this.failedAmount = failedAmount;
    }

    @JsonProperty("InvoiceId")
    public String getInvoiceId() {
        return invoiceId;
    }

    @JsonProperty("InvoiceId")
    public void setInvoiceId(String invoiceId) {
        this.invoiceId = invoiceId;
    }

    @JsonProperty("FulfillmentDate")
    public Object getFulfillmentDate() {
        return fulfillmentDate;
    }

    @JsonProperty("FulfillmentDate")
    public void setFulfillmentDate(Object fulfillmentDate) {
        this.fulfillmentDate = fulfillmentDate;
    }

    @JsonProperty("SellingLocationId")
    public Object getSellingLocationId() {
        return sellingLocationId;
    }

    @JsonProperty("SellingLocationId")
    public void setSellingLocationId(Object sellingLocationId) {
        this.sellingLocationId = sellingLocationId;
    }

    @JsonProperty("UpdatedBy")
    public String getUpdatedBy() {
        return updatedBy;
    }

    @JsonProperty("UpdatedBy")
    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    @JsonProperty("AmountProcessed")
    public Object getAmountProcessed() {
        return amountProcessed;
    }

    @JsonProperty("AmountProcessed")
    public void setAmountProcessed(Object amountProcessed) {
        this.amountProcessed = amountProcessed;
    }

    @JsonProperty("TotalCharges")
    public Integer getTotalCharges() {
        return totalCharges;
    }

    @JsonProperty("TotalCharges")
    public void setTotalCharges(Integer totalCharges) {
        this.totalCharges = totalCharges;
    }

    @JsonProperty("InvoiceSubTotal")
    public Double getInvoiceSubTotal() {
        return invoiceSubTotal;
    }

    @JsonProperty("InvoiceSubTotal")
    public void setInvoiceSubTotal(Double invoiceSubTotal) {
        this.invoiceSubTotal = invoiceSubTotal;
    }

    @JsonProperty("ParentOrderId")
    public Object getParentOrderId() {
        return parentOrderId;
    }

    @JsonProperty("ParentOrderId")
    public void setParentOrderId(Object parentOrderId) {
        this.parentOrderId = parentOrderId;
    }

    @JsonProperty("TaxExemptId")
    public Object getTaxExemptId() {
        return taxExemptId;
    }

    @JsonProperty("TaxExemptId")
    public void setTaxExemptId(Object taxExemptId) {
        this.taxExemptId = taxExemptId;
    }

    @JsonProperty("PublishStatus")
    public PublishStatus getPublishStatus() {
        return publishStatus;
    }

    @JsonProperty("PublishStatus")
    public void setPublishStatus(PublishStatus publishStatus) {
        this.publishStatus = publishStatus;
    }

    @JsonProperty("Status")
    public Status getStatus() {
        return status;
    }

    @JsonProperty("Status")
    public void setStatus(Status status) {
        this.status = status;
    }

    @JsonProperty("UpdatedTimestamp")
    public String getUpdatedTimestamp() {
        return updatedTimestamp;
    }

    @JsonProperty("UpdatedTimestamp")
    public void setUpdatedTimestamp(String updatedTimestamp) {
        this.updatedTimestamp = updatedTimestamp;
    }

    @JsonProperty("CreatedBy")
    public String getCreatedBy() {
        return createdBy;
    }

    @JsonProperty("CreatedBy")
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    @JsonProperty("InvoiceLine")
    public List<InvoiceLine> getInvoiceLine() {
        return invoiceLine;
    }

    @JsonProperty("InvoiceLine")
    public void setInvoiceLine(List<InvoiceLine> invoiceLine) {
        this.invoiceLine = invoiceLine;
    }

    @JsonProperty("InvoiceChargeDetail")
    public List<Object> getInvoiceChargeDetail() {
        return invoiceChargeDetail;
    }

    @JsonProperty("InvoiceChargeDetail")
    public void setInvoiceChargeDetail(List<Object> invoiceChargeDetail) {
        this.invoiceChargeDetail = invoiceChargeDetail;
    }

    @JsonProperty("CustomerId")
    public String getCustomerId() {
        return customerId;
    }

    @JsonProperty("CustomerId")
    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    @JsonProperty("InvoiceType")
    public InvoiceType getInvoiceType() {
        return invoiceType;
    }

    @JsonProperty("InvoiceType")
    public void setInvoiceType(InvoiceType invoiceType) {
        this.invoiceType = invoiceType;
    }

    @JsonProperty("OrgId")
    public String getOrgId() {
        return orgId;
    }

    @JsonProperty("OrgId")
    public void setOrgId(String orgId) {
        this.orgId = orgId;
    }

    @JsonProperty("InvoiceTotal")
    public Double getInvoiceTotal() {
        return invoiceTotal;
    }

    @JsonProperty("InvoiceTotal")
    public void setInvoiceTotal(Double invoiceTotal) {
        this.invoiceTotal = invoiceTotal;
    }

    @JsonProperty("TotalTaxes")
    public Double getTotalTaxes() {
        return totalTaxes;
    }

    @JsonProperty("TotalTaxes")
    public void setTotalTaxes(Double totalTaxes) {
        this.totalTaxes = totalTaxes;
    }

    @JsonProperty("ContextId")
    public String getContextId() {
        return contextId;
    }

    @JsonProperty("ContextId")
    public void setContextId(String contextId) {
        this.contextId = contextId;
    }

    @JsonProperty("PackageId")
    public String getPackageId() {
        return packageId;
    }

    @JsonProperty("PackageId")
    public void setPackageId(String packageId) {
        this.packageId = packageId;
    }

    @JsonProperty("PK")
    public String getPK() {
        return pK;
    }

    @JsonProperty("PK")
    public void setPK(String pK) {
        this.pK = pK;
    }

    @JsonProperty("InvoiceTaxDetail")
    public List<Object> getInvoiceTaxDetail() {
        return invoiceTaxDetail;
    }

    @JsonProperty("InvoiceTaxDetail")
    public void setInvoiceTaxDetail(List<Object> invoiceTaxDetail) {
        this.invoiceTaxDetail = invoiceTaxDetail;
    }

    @JsonProperty("TotalDiscounts")
    public Integer getTotalDiscounts() {
        return totalDiscounts;
    }

    @JsonProperty("TotalDiscounts")
    public void setTotalDiscounts(Integer totalDiscounts) {
        this.totalDiscounts = totalDiscounts;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
