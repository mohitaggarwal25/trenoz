
package com.dxl.oms.bean.orderhistory;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({
    "CustomerId",
    "OrderId",
    "OrderTotal",
    "CreatedTimestamp",
    "FulfillmentStatus",
    "IsConfirmed"
})
public class Template {

    @JsonProperty("CustomerId")
    private Object customerId;
    @JsonProperty("OrderId")
    private Object orderId;
    @JsonProperty("OrderTotal")
    private Object orderTotal;
    @JsonProperty("CreatedTimestamp")
    private Object createdTimestamp;
    @JsonProperty("FulfillmentStatus")
    private Object fulfillmentStatus;
    @JsonProperty("IsConfirmed")
    private Object isConfirmed;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("CustomerId")
    public Object getCustomerId() {
        return customerId;
    }

    @JsonProperty("CustomerId")
    public void setCustomerId(Object customerId) {
        this.customerId = customerId;
    }

    @JsonProperty("OrderId")
    public Object getOrderId() {
        return orderId;
    }

    @JsonProperty("OrderId")
    public void setOrderId(Object orderId) {
        this.orderId = orderId;
    }

    @JsonProperty("OrderTotal")
    public Object getOrderTotal() {
        return orderTotal;
    }

    @JsonProperty("OrderTotal")
    public void setOrderTotal(Object orderTotal) {
        this.orderTotal = orderTotal;
    }

    @JsonProperty("CreatedTimestamp")
    public Object getCreatedTimestamp() {
        return createdTimestamp;
    }

    @JsonProperty("CreatedTimestamp")
    public void setCreatedTimestamp(Object createdTimestamp) {
        this.createdTimestamp = createdTimestamp;
    }

    @JsonProperty("FulfillmentStatus")
    public Object getFulfillmentStatus() {
        return fulfillmentStatus;
    }

    @JsonProperty("FulfillmentStatus")
    public void setFulfillmentStatus(Object fulfillmentStatus) {
        this.fulfillmentStatus = fulfillmentStatus;
    }

    @JsonProperty("IsConfirmed")
    public Object getIsConfirmed() {
        return isConfirmed;
    }

    @JsonProperty("IsConfirmed")
    public void setIsConfirmed(Object isConfirmed) {
        this.isConfirmed = isConfirmed;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
