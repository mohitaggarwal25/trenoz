package com.dxl.oms.bean.inventory.location;

import com.dxl.oms.bean.inventory.location.InventoryForLocation;

public class RetrieveInventoryResponseForLocation {
	
	private InventoryForLocation inventoryForLocation;
	private boolean success = false;

	/**
	 * @return the inventoryForLocation
	 */
	public InventoryForLocation getInventoryForLocation() {
		return inventoryForLocation;
	}

	/**
	 * @param inventoryForLocation the inventoryForLocation to set
	 */
	public void setInventoryForLocation(InventoryForLocation inventoryForLocation) {
		this.inventoryForLocation = inventoryForLocation;
	}

	/**
	 * @return the success
	 */
	public boolean isSuccess() {
		return success;
	}

	/**
	 * @param success the success to set
	 */
	public void setSuccess(boolean success) {
		this.success = success;
	}

}
