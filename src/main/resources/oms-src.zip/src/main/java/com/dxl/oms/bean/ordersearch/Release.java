
package com.dxl.oms.bean.ordersearch;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "ReleaseType",
    "UpdatedTimestamp",
    "ServiceLevelCode",
    "ShipToLocationId",
    "EffectiveRank",
    "CreatedBy",
    "CreatedTimestamp",
    "ReleaseLine",
    "DeliveryMethodId",
    "ShipFromLocationId",
    "ShipViaId",
    "Process",
    "ReleaseId",
    "OrgId",
    "UpdatedBy",
    "ReleaseExtension1",
    "DestinationAction",
    "ContextId",
    "CarrierCode",
    "PK"
})
public class Release {

    @JsonProperty("ReleaseType")
    private Object releaseType;
    @JsonProperty("UpdatedTimestamp")
    private String updatedTimestamp;
    @JsonProperty("ServiceLevelCode")
    private String serviceLevelCode;
    @JsonProperty("ShipToLocationId")
    private Object shipToLocationId;
    @JsonProperty("EffectiveRank")
    private String effectiveRank;
    @JsonProperty("CreatedBy")
    private String createdBy;
    @JsonProperty("CreatedTimestamp")
    private String createdTimestamp;
    @JsonProperty("ReleaseLine")
    private List<ReleaseLine> releaseLine = null;
    @JsonProperty("DeliveryMethodId")
    private String deliveryMethodId;
    @JsonProperty("ShipFromLocationId")
    private String shipFromLocationId;
    @JsonProperty("ShipViaId")
    private String shipViaId;
    @JsonProperty("Process")
    private Object process;
    @JsonProperty("ReleaseId")
    private String releaseId;
    @JsonProperty("OrgId")
    private String orgId;
    @JsonProperty("UpdatedBy")
    private String updatedBy;
    @JsonProperty("ReleaseExtension1")
    private List<Object> releaseExtension1 = null;
    @JsonProperty("DestinationAction")
    private String destinationAction;
    @JsonProperty("ContextId")
    private String contextId;
    @JsonProperty("CarrierCode")
    private String carrierCode;
    @JsonProperty("PK")
    private String pK;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("ReleaseType")
    public Object getReleaseType() {
        return releaseType;
    }

    @JsonProperty("ReleaseType")
    public void setReleaseType(Object releaseType) {
        this.releaseType = releaseType;
    }

    @JsonProperty("UpdatedTimestamp")
    public String getUpdatedTimestamp() {
        return updatedTimestamp;
    }

    @JsonProperty("UpdatedTimestamp")
    public void setUpdatedTimestamp(String updatedTimestamp) {
        this.updatedTimestamp = updatedTimestamp;
    }

    @JsonProperty("ServiceLevelCode")
    public String getServiceLevelCode() {
        return serviceLevelCode;
    }

    @JsonProperty("ServiceLevelCode")
    public void setServiceLevelCode(String serviceLevelCode) {
        this.serviceLevelCode = serviceLevelCode;
    }

    @JsonProperty("ShipToLocationId")
    public Object getShipToLocationId() {
        return shipToLocationId;
    }

    @JsonProperty("ShipToLocationId")
    public void setShipToLocationId(Object shipToLocationId) {
        this.shipToLocationId = shipToLocationId;
    }

    @JsonProperty("EffectiveRank")
    public String getEffectiveRank() {
        return effectiveRank;
    }

    @JsonProperty("EffectiveRank")
    public void setEffectiveRank(String effectiveRank) {
        this.effectiveRank = effectiveRank;
    }

    @JsonProperty("CreatedBy")
    public String getCreatedBy() {
        return createdBy;
    }

    @JsonProperty("CreatedBy")
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    @JsonProperty("CreatedTimestamp")
    public String getCreatedTimestamp() {
        return createdTimestamp;
    }

    @JsonProperty("CreatedTimestamp")
    public void setCreatedTimestamp(String createdTimestamp) {
        this.createdTimestamp = createdTimestamp;
    }

    @JsonProperty("ReleaseLine")
    public List<ReleaseLine> getReleaseLine() {
        return releaseLine;
    }

    @JsonProperty("ReleaseLine")
    public void setReleaseLine(List<ReleaseLine> releaseLine) {
        this.releaseLine = releaseLine;
    }

    @JsonProperty("DeliveryMethodId")
    public String getDeliveryMethodId() {
        return deliveryMethodId;
    }

    @JsonProperty("DeliveryMethodId")
    public void setDeliveryMethodId(String deliveryMethodId) {
        this.deliveryMethodId = deliveryMethodId;
    }

    @JsonProperty("ShipFromLocationId")
    public String getShipFromLocationId() {
        return shipFromLocationId;
    }

    @JsonProperty("ShipFromLocationId")
    public void setShipFromLocationId(String shipFromLocationId) {
        this.shipFromLocationId = shipFromLocationId;
    }

    @JsonProperty("ShipViaId")
    public String getShipViaId() {
        return shipViaId;
    }

    @JsonProperty("ShipViaId")
    public void setShipViaId(String shipViaId) {
        this.shipViaId = shipViaId;
    }

    @JsonProperty("Process")
    public Object getProcess() {
        return process;
    }

    @JsonProperty("Process")
    public void setProcess(Object process) {
        this.process = process;
    }

    @JsonProperty("ReleaseId")
    public String getReleaseId() {
        return releaseId;
    }

    @JsonProperty("ReleaseId")
    public void setReleaseId(String releaseId) {
        this.releaseId = releaseId;
    }

    @JsonProperty("OrgId")
    public String getOrgId() {
        return orgId;
    }

    @JsonProperty("OrgId")
    public void setOrgId(String orgId) {
        this.orgId = orgId;
    }

    @JsonProperty("UpdatedBy")
    public String getUpdatedBy() {
        return updatedBy;
    }

    @JsonProperty("UpdatedBy")
    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    @JsonProperty("ReleaseExtension1")
    public List<Object> getReleaseExtension1() {
        return releaseExtension1;
    }

    @JsonProperty("ReleaseExtension1")
    public void setReleaseExtension1(List<Object> releaseExtension1) {
        this.releaseExtension1 = releaseExtension1;
    }

    @JsonProperty("DestinationAction")
    public String getDestinationAction() {
        return destinationAction;
    }

    @JsonProperty("DestinationAction")
    public void setDestinationAction(String destinationAction) {
        this.destinationAction = destinationAction;
    }

    @JsonProperty("ContextId")
    public String getContextId() {
        return contextId;
    }

    @JsonProperty("ContextId")
    public void setContextId(String contextId) {
        this.contextId = contextId;
    }

    @JsonProperty("CarrierCode")
    public String getCarrierCode() {
        return carrierCode;
    }

    @JsonProperty("CarrierCode")
    public void setCarrierCode(String carrierCode) {
        this.carrierCode = carrierCode;
    }

    @JsonProperty("PK")
    public String getPK() {
        return pK;
    }

    @JsonProperty("PK")
    public void setPK(String pK) {
        this.pK = pK;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
