
package com.dxl.oms.bean.ordersearch;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "ShipToAddress",
    "InvoiceLineSubTotal",
    "ParentLineCreatedTimestamp",
    "CreatedTimestamp",
    "IsTaxIncluded",
    "OrderedItemId",
    "InvoiceLineId",
    "ShipFromLocationId",
    "InvoiceLineTaxDetail",
    "Process",
    "PackageDetailId",
    "FulfillmentDate",
    "ItemId",
    "PhysicalOriginId",
    "UpdatedBy",
    "TotalCharges",
    "OrderLineCreatedTimestamp",
    "InvoiceLineTotal",
    "ProductClass",
    "AddressId",
    "PaymentGroupId",
    "UpdatedTimestamp",
    "ShipToLocationId",
    "CreatedBy",
    "ShipFromAddress",
    "ShipFromAddressId",
    "Quantity",
    "FulfillmentGroupId",
    "OrgId",
    "OrderedUOM",
    "UOM",
    "UnitPrice",
    "InvoiceLineChargeDetail",
    "OrderedQuantity",
    "OrderLineId",
    "TotalTaxes",
    "ContextId",
    "PK",
    "TotalDiscounts"
})
public class InvoiceLine {

    @JsonProperty("ShipToAddress")
    private ShipToAddress shipToAddress;
    @JsonProperty("InvoiceLineSubTotal")
    private Double invoiceLineSubTotal;
    @JsonProperty("ParentLineCreatedTimestamp")
    private Object parentLineCreatedTimestamp;
    @JsonProperty("CreatedTimestamp")
    private String createdTimestamp;
    @JsonProperty("IsTaxIncluded")
    private Boolean isTaxIncluded;
    @JsonProperty("OrderedItemId")
    private String orderedItemId;
    @JsonProperty("InvoiceLineId")
    private String invoiceLineId;
    @JsonProperty("ShipFromLocationId")
    private String shipFromLocationId;
    @JsonProperty("InvoiceLineTaxDetail")
    private List<InvoiceLineTaxDetail> invoiceLineTaxDetail = null;
    @JsonProperty("Process")
    private Object process;
    @JsonProperty("PackageDetailId")
    private String packageDetailId;
    @JsonProperty("FulfillmentDate")
    private Object fulfillmentDate;
    @JsonProperty("ItemId")
    private String itemId;
    @JsonProperty("PhysicalOriginId")
    private String physicalOriginId;
    @JsonProperty("UpdatedBy")
    private String updatedBy;
    @JsonProperty("TotalCharges")
    private Integer totalCharges;
    @JsonProperty("OrderLineCreatedTimestamp")
    private String orderLineCreatedTimestamp;
    @JsonProperty("InvoiceLineTotal")
    private Double invoiceLineTotal;
    @JsonProperty("ProductClass")
    private Object productClass;
    @JsonProperty("AddressId")
    private String addressId;
    @JsonProperty("PaymentGroupId")
    private Object paymentGroupId;
    @JsonProperty("UpdatedTimestamp")
    private String updatedTimestamp;
    @JsonProperty("ShipToLocationId")
    private Object shipToLocationId;
    @JsonProperty("CreatedBy")
    private String createdBy;
    @JsonProperty("ShipFromAddress")
    private Object shipFromAddress;
    @JsonProperty("ShipFromAddressId")
    private String shipFromAddressId;
    @JsonProperty("Quantity")
    private Integer quantity;
    @JsonProperty("FulfillmentGroupId")
    private String fulfillmentGroupId;
    @JsonProperty("OrgId")
    private String orgId;
    @JsonProperty("OrderedUOM")
    private String orderedUOM;
    @JsonProperty("UOM")
    private String uOM;
    @JsonProperty("UnitPrice")
    private Double unitPrice;
    @JsonProperty("InvoiceLineChargeDetail")
    private List<Object> invoiceLineChargeDetail = null;
    @JsonProperty("OrderedQuantity")
    private Integer orderedQuantity;
    @JsonProperty("OrderLineId")
    private String orderLineId;
    @JsonProperty("TotalTaxes")
    private Double totalTaxes;
    @JsonProperty("ContextId")
    private String contextId;
    @JsonProperty("PK")
    private String pK;
    @JsonProperty("TotalDiscounts")
    private Integer totalDiscounts;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("ShipToAddress")
    public ShipToAddress getShipToAddress() {
        return shipToAddress;
    }

    @JsonProperty("ShipToAddress")
    public void setShipToAddress(ShipToAddress shipToAddress) {
        this.shipToAddress = shipToAddress;
    }

    @JsonProperty("InvoiceLineSubTotal")
    public Double getInvoiceLineSubTotal() {
        return invoiceLineSubTotal;
    }

    @JsonProperty("InvoiceLineSubTotal")
    public void setInvoiceLineSubTotal(Double invoiceLineSubTotal) {
        this.invoiceLineSubTotal = invoiceLineSubTotal;
    }

    @JsonProperty("ParentLineCreatedTimestamp")
    public Object getParentLineCreatedTimestamp() {
        return parentLineCreatedTimestamp;
    }

    @JsonProperty("ParentLineCreatedTimestamp")
    public void setParentLineCreatedTimestamp(Object parentLineCreatedTimestamp) {
        this.parentLineCreatedTimestamp = parentLineCreatedTimestamp;
    }

    @JsonProperty("CreatedTimestamp")
    public String getCreatedTimestamp() {
        return createdTimestamp;
    }

    @JsonProperty("CreatedTimestamp")
    public void setCreatedTimestamp(String createdTimestamp) {
        this.createdTimestamp = createdTimestamp;
    }

    @JsonProperty("IsTaxIncluded")
    public Boolean getIsTaxIncluded() {
        return isTaxIncluded;
    }

    @JsonProperty("IsTaxIncluded")
    public void setIsTaxIncluded(Boolean isTaxIncluded) {
        this.isTaxIncluded = isTaxIncluded;
    }

    @JsonProperty("OrderedItemId")
    public String getOrderedItemId() {
        return orderedItemId;
    }

    @JsonProperty("OrderedItemId")
    public void setOrderedItemId(String orderedItemId) {
        this.orderedItemId = orderedItemId;
    }

    @JsonProperty("InvoiceLineId")
    public String getInvoiceLineId() {
        return invoiceLineId;
    }

    @JsonProperty("InvoiceLineId")
    public void setInvoiceLineId(String invoiceLineId) {
        this.invoiceLineId = invoiceLineId;
    }

    @JsonProperty("ShipFromLocationId")
    public String getShipFromLocationId() {
        return shipFromLocationId;
    }

    @JsonProperty("ShipFromLocationId")
    public void setShipFromLocationId(String shipFromLocationId) {
        this.shipFromLocationId = shipFromLocationId;
    }

    @JsonProperty("InvoiceLineTaxDetail")
    public List<InvoiceLineTaxDetail> getInvoiceLineTaxDetail() {
        return invoiceLineTaxDetail;
    }

    @JsonProperty("InvoiceLineTaxDetail")
    public void setInvoiceLineTaxDetail(List<InvoiceLineTaxDetail> invoiceLineTaxDetail) {
        this.invoiceLineTaxDetail = invoiceLineTaxDetail;
    }

    @JsonProperty("Process")
    public Object getProcess() {
        return process;
    }

    @JsonProperty("Process")
    public void setProcess(Object process) {
        this.process = process;
    }

    @JsonProperty("PackageDetailId")
    public String getPackageDetailId() {
        return packageDetailId;
    }

    @JsonProperty("PackageDetailId")
    public void setPackageDetailId(String packageDetailId) {
        this.packageDetailId = packageDetailId;
    }

    @JsonProperty("FulfillmentDate")
    public Object getFulfillmentDate() {
        return fulfillmentDate;
    }

    @JsonProperty("FulfillmentDate")
    public void setFulfillmentDate(Object fulfillmentDate) {
        this.fulfillmentDate = fulfillmentDate;
    }

    @JsonProperty("ItemId")
    public String getItemId() {
        return itemId;
    }

    @JsonProperty("ItemId")
    public void setItemId(String itemId) {
        this.itemId = itemId;
    }

    @JsonProperty("PhysicalOriginId")
    public String getPhysicalOriginId() {
        return physicalOriginId;
    }

    @JsonProperty("PhysicalOriginId")
    public void setPhysicalOriginId(String physicalOriginId) {
        this.physicalOriginId = physicalOriginId;
    }

    @JsonProperty("UpdatedBy")
    public String getUpdatedBy() {
        return updatedBy;
    }

    @JsonProperty("UpdatedBy")
    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    @JsonProperty("TotalCharges")
    public Integer getTotalCharges() {
        return totalCharges;
    }

    @JsonProperty("TotalCharges")
    public void setTotalCharges(Integer totalCharges) {
        this.totalCharges = totalCharges;
    }

    @JsonProperty("OrderLineCreatedTimestamp")
    public String getOrderLineCreatedTimestamp() {
        return orderLineCreatedTimestamp;
    }

    @JsonProperty("OrderLineCreatedTimestamp")
    public void setOrderLineCreatedTimestamp(String orderLineCreatedTimestamp) {
        this.orderLineCreatedTimestamp = orderLineCreatedTimestamp;
    }

    @JsonProperty("InvoiceLineTotal")
    public Double getInvoiceLineTotal() {
        return invoiceLineTotal;
    }

    @JsonProperty("InvoiceLineTotal")
    public void setInvoiceLineTotal(Double invoiceLineTotal) {
        this.invoiceLineTotal = invoiceLineTotal;
    }

    @JsonProperty("ProductClass")
    public Object getProductClass() {
        return productClass;
    }

    @JsonProperty("ProductClass")
    public void setProductClass(Object productClass) {
        this.productClass = productClass;
    }

    @JsonProperty("AddressId")
    public String getAddressId() {
        return addressId;
    }

    @JsonProperty("AddressId")
    public void setAddressId(String addressId) {
        this.addressId = addressId;
    }

    @JsonProperty("PaymentGroupId")
    public Object getPaymentGroupId() {
        return paymentGroupId;
    }

    @JsonProperty("PaymentGroupId")
    public void setPaymentGroupId(Object paymentGroupId) {
        this.paymentGroupId = paymentGroupId;
    }

    @JsonProperty("UpdatedTimestamp")
    public String getUpdatedTimestamp() {
        return updatedTimestamp;
    }

    @JsonProperty("UpdatedTimestamp")
    public void setUpdatedTimestamp(String updatedTimestamp) {
        this.updatedTimestamp = updatedTimestamp;
    }

    @JsonProperty("ShipToLocationId")
    public Object getShipToLocationId() {
        return shipToLocationId;
    }

    @JsonProperty("ShipToLocationId")
    public void setShipToLocationId(Object shipToLocationId) {
        this.shipToLocationId = shipToLocationId;
    }

    @JsonProperty("CreatedBy")
    public String getCreatedBy() {
        return createdBy;
    }

    @JsonProperty("CreatedBy")
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    @JsonProperty("ShipFromAddress")
    public Object getShipFromAddress() {
        return shipFromAddress;
    }

    @JsonProperty("ShipFromAddress")
    public void setShipFromAddress(Object shipFromAddress) {
        this.shipFromAddress = shipFromAddress;
    }

    @JsonProperty("ShipFromAddressId")
    public String getShipFromAddressId() {
        return shipFromAddressId;
    }

    @JsonProperty("ShipFromAddressId")
    public void setShipFromAddressId(String shipFromAddressId) {
        this.shipFromAddressId = shipFromAddressId;
    }

    @JsonProperty("Quantity")
    public Integer getQuantity() {
        return quantity;
    }

    @JsonProperty("Quantity")
    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    @JsonProperty("FulfillmentGroupId")
    public String getFulfillmentGroupId() {
        return fulfillmentGroupId;
    }

    @JsonProperty("FulfillmentGroupId")
    public void setFulfillmentGroupId(String fulfillmentGroupId) {
        this.fulfillmentGroupId = fulfillmentGroupId;
    }

    @JsonProperty("OrgId")
    public String getOrgId() {
        return orgId;
    }

    @JsonProperty("OrgId")
    public void setOrgId(String orgId) {
        this.orgId = orgId;
    }

    @JsonProperty("OrderedUOM")
    public String getOrderedUOM() {
        return orderedUOM;
    }

    @JsonProperty("OrderedUOM")
    public void setOrderedUOM(String orderedUOM) {
        this.orderedUOM = orderedUOM;
    }

    @JsonProperty("UOM")
    public String getUOM() {
        return uOM;
    }

    @JsonProperty("UOM")
    public void setUOM(String uOM) {
        this.uOM = uOM;
    }

    @JsonProperty("UnitPrice")
    public Double getUnitPrice() {
        return unitPrice;
    }

    @JsonProperty("UnitPrice")
    public void setUnitPrice(Double unitPrice) {
        this.unitPrice = unitPrice;
    }

    @JsonProperty("InvoiceLineChargeDetail")
    public List<Object> getInvoiceLineChargeDetail() {
        return invoiceLineChargeDetail;
    }

    @JsonProperty("InvoiceLineChargeDetail")
    public void setInvoiceLineChargeDetail(List<Object> invoiceLineChargeDetail) {
        this.invoiceLineChargeDetail = invoiceLineChargeDetail;
    }

    @JsonProperty("OrderedQuantity")
    public Integer getOrderedQuantity() {
        return orderedQuantity;
    }

    @JsonProperty("OrderedQuantity")
    public void setOrderedQuantity(Integer orderedQuantity) {
        this.orderedQuantity = orderedQuantity;
    }

    @JsonProperty("OrderLineId")
    public String getOrderLineId() {
        return orderLineId;
    }

    @JsonProperty("OrderLineId")
    public void setOrderLineId(String orderLineId) {
        this.orderLineId = orderLineId;
    }

    @JsonProperty("TotalTaxes")
    public Double getTotalTaxes() {
        return totalTaxes;
    }

    @JsonProperty("TotalTaxes")
    public void setTotalTaxes(Double totalTaxes) {
        this.totalTaxes = totalTaxes;
    }

    @JsonProperty("ContextId")
    public String getContextId() {
        return contextId;
    }

    @JsonProperty("ContextId")
    public void setContextId(String contextId) {
        this.contextId = contextId;
    }

    @JsonProperty("PK")
    public String getPK() {
        return pK;
    }

    @JsonProperty("PK")
    public void setPK(String pK) {
        this.pK = pK;
    }

    @JsonProperty("TotalDiscounts")
    public Integer getTotalDiscounts() {
        return totalDiscounts;
    }

    @JsonProperty("TotalDiscounts")
    public void setTotalDiscounts(Integer totalDiscounts) {
        this.totalDiscounts = totalDiscounts;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
