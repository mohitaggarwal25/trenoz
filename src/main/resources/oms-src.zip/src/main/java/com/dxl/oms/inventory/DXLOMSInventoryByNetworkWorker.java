package com.dxl.oms.inventory;

import java.io.IOException;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.ParseException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;

import com.dxl.oms.bean.OMSAuthTokenResponseBean;
import com.dxl.oms.bean.inventory.network.InventoryResponseForNetwork;
import com.dxl.oms.bean.inventory.network.RetrieveInventoryReqForNetwork;
import com.dxl.oms.bean.inventory.network.RetrieveInventoryResponseForNetwork;
import com.dxl.oms.connection.OMSWorkerInfo;
import com.fasterxml.jackson.databind.ObjectMapper;

import atg.nucleus.GenericService;

/**
 * Worker thread used to handle the thread request to the OMS Gateway Service.
 *
 * @author TAISTech
 */
public class DXLOMSInventoryByNetworkWorker extends GenericService implements Runnable {
	private Thread mWorkerThread = null;

	public static final int RETRY_COUNT = 1;
	private RetrieveInventoryResponseForNetwork mRetrieveInventoryResponseForNetwork;
	private RetrieveInventoryReqForNetwork request;
	private static final String AUTHORIZATION = "Authorization";
	private static final String CONTENT_TYPE = "Content-Type";
	private static final String APPLCN_URL_ENCODED = "application/json";
	private OMSWorkerInfo omsWorkerInfo;

	/**
	 * constructor
	 *
	 * @param omsResponse
	 *
	 */
	public DXLOMSInventoryByNetworkWorker(RetrieveInventoryResponseForNetwork omsResponse, RetrieveInventoryReqForNetwork request, OMSWorkerInfo omsWorkerInfo) {
		this.mRetrieveInventoryResponseForNetwork = omsResponse;
		this.request = request;
		this.omsWorkerInfo = omsWorkerInfo;

		if (mWorkerThread == null) {
			mWorkerThread = new Thread(this, "OMS Inventory Availability For Network Thread");
			// start thread
			mWorkerThread.start();
		}
	}

	/**
	 * sends the Inventory Request to the OMS Service.
	 */
	public void run() {

		if (isLoggingDebug()) {
			logDebug("OMS Inventory availability for network Service is available");
		}
		String responseJSON = null;
		ObjectMapper objectMapper = null;
		HttpResponse response = null;
		if (isLoggingDebug()) {
			logDebug("connectionURL:" + omsWorkerInfo.getOmsInventoryByNetworkEndPointURL());
		}
		HttpClient httpclient = HttpClientBuilder.create().build();
		HttpPost post = new HttpPost(omsWorkerInfo.getOmsInventoryByNetworkEndPointURL());

		String accessToken = getAccessToken(false);
		if (accessToken != null) {
			objectMapper = new ObjectMapper();
			String requestJSON;
			StringEntity params = null;
			try {
				requestJSON = objectMapper.writeValueAsString(request.getRequest());
				params = new StringEntity(requestJSON);
			} catch (IOException e) {
				if (isLoggingError()) {
					logError("IOException caught: ", e);
				}
			}
			post.setEntity(params);
			post.setHeader(CONTENT_TYPE, APPLCN_URL_ENCODED);

			response = getOMSResponse(httpclient, post, accessToken);
			if (response != null && response.getStatusLine().getStatusCode() != 200) {
				HttpEntity entity = response.getEntity();
				try {
					responseJSON = EntityUtils.toString(entity, "UTF-8");
				} catch (ParseException | IOException e) {
					if (isLoggingError()) {
						logError("ParseException | IOException caught: ", e);
					}
				}
				if (isLoggingDebug()) {
					logDebug("omsResponseJSON From DXLOMSInventoryByNetworkWorker=" + responseJSON);
				}
				if (responseJSON != null && responseJSON.contains("invalid_token")) {
					accessToken = getAccessToken(true);
					if (accessToken != null) {
						response = getOMSResponse(httpclient, post, accessToken);
					}
				}
			}
		}
		if (response != null && response.getStatusLine().getStatusCode() == 200) {
			synchronized (mRetrieveInventoryResponseForNetwork) {
				try {
					InventoryResponseForNetwork omsResponse = objectMapper.readValue(response.getEntity().getContent(), InventoryResponseForNetwork.class);
					if (omsResponse != null) {
						mRetrieveInventoryResponseForNetwork.setInventoryResponseForNetwork(omsResponse);
						mRetrieveInventoryResponseForNetwork.setSuccess(true);
					}
				} catch (IllegalStateException | IOException e) {
					if (isLoggingError()) {
						logError("IllegalStateException | IOException caught: ", e);
					}
				}
			}
		}
		if (isLoggingDebug()) {
			logDebug("Done Worker");
		}
		// Release the connection.
		if (post != null) {
			post.releaseConnection();
		}
		if (isLoggingDebug()) {
			logDebug("communication completed");
		}
	}

	private HttpResponse getOMSResponse(HttpClient httpclient, HttpPost post, String accessToken) {

		String authorizationHeader = omsWorkerInfo.getAuthorizationHeader() + accessToken;
		post.setHeader(AUTHORIZATION, authorizationHeader);
		HttpResponse response = null;
		try {
			response = httpclient.execute(post);
		} catch (IOException e) {
			if (isLoggingError()) {
				logError("IOException caught: ", e);
			}
		}
		return response;
	}

	private String getAccessToken(boolean newToken) {
		String accessToken = null;
		OMSAuthTokenResponseBean tokenBean = omsWorkerInfo.getOmsManager().getOmsAuthTokenBean();
		if (newToken || tokenBean == null) {
			tokenBean = omsWorkerInfo.getOmsManager().genereateOMSAccessToken();
		}
		if (tokenBean != null) {
			accessToken = tokenBean.getAccessToken();
		}
		return accessToken;
	}
}
