
package com.dxl.oms.bean.inventory.location;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "Items",
    "ViewName",
    "Locations"
})
public class InventoryReqForLocation {

    @JsonProperty("Items")
    private List<String> items = null;
    @JsonProperty("ViewName")
    private String viewName;
    @JsonProperty("Locations")
    private List<String> locations = null;

    @JsonProperty("Items")
    public List<String> getItems() {
        return items;
    }

    @JsonProperty("Items")
    public void setItems(List<String> items) {
        this.items = items;
    }

    @JsonProperty("ViewName")
    public String getViewName() {
        return viewName;
    }

    @JsonProperty("ViewName")
    public void setViewName(String viewName) {
        this.viewName = viewName;
    }

    @JsonProperty("Locations")
    public List<String> getLocations() {
        return locations;
    }

    @JsonProperty("Locations")
    public void setLocations(List<String> locations) {
        this.locations = locations;
    }

}
