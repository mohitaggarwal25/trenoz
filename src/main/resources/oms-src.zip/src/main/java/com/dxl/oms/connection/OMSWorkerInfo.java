package com.dxl.oms.connection;

import com.dxl.oms.DXLSQSClient;
import com.dxl.oms.OMSManager;

import atg.nucleus.GenericService;

/**
 * OMS Worker Info holds all properties that are used in the OMS Integration
 * Service.
 *
 * @author TAISTech
 */
public class OMSWorkerInfo extends GenericService {
	private String authorizationHeader;
	private String omsOrderHistoryEndPointURL;
	private String omsOrderSearchEndPointURL;
	private String omsInventoryByLocationEndPointURL;
	private String omsInventoryByNetworkEndPointURL;
	private OMSManager omsManager;
	private DXLSQSClient sqsClient;

	public String getAuthorizationHeader() {
		return authorizationHeader;
	}

	public void setAuthorizationHeader(String authorizationHeader) {
		this.authorizationHeader = authorizationHeader;
	}

	public String getOmsOrderHistoryEndPointURL() {
		return omsOrderHistoryEndPointURL;
	}

	public void setOmsOrderHistoryEndPointURL(String omsOrderHistoryEndPointURL) {
		this.omsOrderHistoryEndPointURL = omsOrderHistoryEndPointURL;
	}

	public OMSManager getOmsManager() {
		return omsManager;
	}

	public void setOmsManager(OMSManager omsManager) {
		this.omsManager = omsManager;
	}

	public String getOmsOrderSearchEndPointURL() {
		return omsOrderSearchEndPointURL;
	}

	public void setOmsOrderSearchEndPointURL(String omsOrderSearchEndPointURL) {
		this.omsOrderSearchEndPointURL = omsOrderSearchEndPointURL;
	}

	/**
	 * @return the omsInventoryByLocationEndPointURL
	 */
	public String getOmsInventoryByLocationEndPointURL() {
		return omsInventoryByLocationEndPointURL;
	}

	/**
	 * @param omsInventoryByLocationEndPointURL the omsInventoryByLocationEndPointURL to set
	 */
	public void setOmsInventoryByLocationEndPointURL(String omsInventoryByLocationEndPointURL) {
		this.omsInventoryByLocationEndPointURL = omsInventoryByLocationEndPointURL;
	}

	public DXLSQSClient getSqsClient() {
		return sqsClient;
	}

	public void setSqsClient(DXLSQSClient sqsClient) {
		this.sqsClient = sqsClient;
	}

	/**
	 * @return the omsInventoryByNetworkEndPointURL
	 */
	public String getOmsInventoryByNetworkEndPointURL() {
		return omsInventoryByNetworkEndPointURL;
	}

	/**
	 * @param omsInventoryByNetworkEndPointURL the omsInventoryByNetworkEndPointURL to set
	 */
	public void setOmsInventoryByNetworkEndPointURL(String omsInventoryByNetworkEndPointURL) {
		this.omsInventoryByNetworkEndPointURL = omsInventoryByNetworkEndPointURL;
	}
}
