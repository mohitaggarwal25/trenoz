package com.dxl.oms;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicNameValuePair;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

import com.dxl.oms.bean.OMSAuthTokenResponseBean;

import atg.nucleus.GenericService;

public class DXLOMSAccessTokenGenerator extends GenericService {

	
	private String grantType;
	private String userName;
	private String password;
	private String authorizationHeader;
	private String omsAuthEndPointURL;
	
	private static final String AUTHORIZATION = "Authorization";
	private static final String CONTENT_TYPE = "Content-Type";
	private static final String GRANT_TYPE = "grant_type";
	private static final String USER_NAME = "username";
	private static final String PASSWORD = "password";
	private static final String APPLCN_URL_ENCODED = "application/x-www-form-urlencoded";
	
	
	/**
	 * This method generates the access token from OMS and return the response bean. Throws exception when something is wrong.
	 * 
	 * @return
	 * @throws JsonParseException
	 * @throws JsonMappingException
	 * @throws IllegalStateException
	 * @throws IOException
	 */
	public OMSAuthTokenResponseBean generateOMSAccessToken() throws JsonParseException, JsonMappingException, IllegalStateException, IOException {
		
		HttpClient httpclient = HttpClientBuilder.create().build();
		ObjectMapper objectMapper=new ObjectMapper();
		HttpPost post = new HttpPost(getOmsAuthEndPointURL());		
		post.setHeader(AUTHORIZATION,getAuthorizationHeader());
		post.setHeader(CONTENT_TYPE,APPLCN_URL_ENCODED);
		List<NameValuePair> urlParameters = new ArrayList<NameValuePair>();
		urlParameters.add(new BasicNameValuePair(GRANT_TYPE, getGrantType()));
		urlParameters.add(new BasicNameValuePair(USER_NAME, getUserName()));
		urlParameters.add(new BasicNameValuePair(PASSWORD, getPassword()));
		post.setEntity(new UrlEncodedFormEntity(urlParameters));
		HttpResponse response = httpclient.execute(post);
		
		OMSAuthTokenResponseBean omsAuthTokenBean = objectMapper.readValue(response.getEntity().getContent(), OMSAuthTokenResponseBean.class);
		
		return omsAuthTokenBean;
	}
	
	public String getGrantType() {
		return grantType;
	}
	public void setGrantType(String grantType) {
		this.grantType = grantType;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getAuthorizationHeader() {
		return authorizationHeader;
	}
	public void setAuthorizationHeader(String authorizationHeader) {
		this.authorizationHeader = authorizationHeader;
	}
	public String getOmsAuthEndPointURL() {
		return omsAuthEndPointURL;
	}
	public void setOmsAuthEndPointURL(String omsAuthEndPointURL) {
		this.omsAuthEndPointURL = omsAuthEndPointURL;
	}
	
	
}
