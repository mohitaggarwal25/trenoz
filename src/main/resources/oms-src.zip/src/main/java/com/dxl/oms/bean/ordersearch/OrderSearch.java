
package com.dxl.oms.bean.ordersearch;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "success",
    "header",
    "data",
    "messageKey",
    "message",
    "errors",
    "exceptions",
    "messages",
    "rootCause",
    "cloudComponent",
    "cloudComponentHostName",
    "requestUri",
    "statusCode"
})
public class OrderSearch {

    @JsonProperty("success")
    private Boolean success;
    @JsonProperty("header")
    private Object header;
    @JsonProperty("data")
    private Data data;
    @JsonProperty("messageKey")
    private Object messageKey;
    @JsonProperty("message")
    private Object message;
    @JsonProperty("errors")
    private List<Object> errors = null;
    @JsonProperty("exceptions")
    private List<Object> exceptions = null;
    @JsonProperty("messages")
    private Messages messages;
    @JsonProperty("rootCause")
    private Object rootCause;
    @JsonProperty("cloudComponent")
    private String cloudComponent;
    @JsonProperty("cloudComponentHostName")
    private String cloudComponentHostName;
    @JsonProperty("requestUri")
    private Object requestUri;
    @JsonProperty("statusCode")
    private String statusCode;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("success")
    public Boolean getSuccess() {
        return success;
    }

    @JsonProperty("success")
    public void setSuccess(Boolean success) {
        this.success = success;
    }

    @JsonProperty("header")
    public Object getHeader() {
        return header;
    }

    @JsonProperty("header")
    public void setHeader(Object header) {
        this.header = header;
    }

    @JsonProperty("data")
    public Data getData() {
        return data;
    }

    @JsonProperty("data")
    public void setData(Data data) {
        this.data = data;
    }

    @JsonProperty("messageKey")
    public Object getMessageKey() {
        return messageKey;
    }

    @JsonProperty("messageKey")
    public void setMessageKey(Object messageKey) {
        this.messageKey = messageKey;
    }

    @JsonProperty("message")
    public Object getMessage() {
        return message;
    }

    @JsonProperty("message")
    public void setMessage(Object message) {
        this.message = message;
    }

    @JsonProperty("errors")
    public List<Object> getErrors() {
        return errors;
    }

    @JsonProperty("errors")
    public void setErrors(List<Object> errors) {
        this.errors = errors;
    }

    @JsonProperty("exceptions")
    public List<Object> getExceptions() {
        return exceptions;
    }

    @JsonProperty("exceptions")
    public void setExceptions(List<Object> exceptions) {
        this.exceptions = exceptions;
    }

    @JsonProperty("messages")
    public Messages getMessages() {
        return messages;
    }

    @JsonProperty("messages")
    public void setMessages(Messages messages) {
        this.messages = messages;
    }

    @JsonProperty("rootCause")
    public Object getRootCause() {
        return rootCause;
    }

    @JsonProperty("rootCause")
    public void setRootCause(Object rootCause) {
        this.rootCause = rootCause;
    }

    @JsonProperty("cloudComponent")
    public String getCloudComponent() {
        return cloudComponent;
    }

    @JsonProperty("cloudComponent")
    public void setCloudComponent(String cloudComponent) {
        this.cloudComponent = cloudComponent;
    }

    @JsonProperty("cloudComponentHostName")
    public String getCloudComponentHostName() {
        return cloudComponentHostName;
    }

    @JsonProperty("cloudComponentHostName")
    public void setCloudComponentHostName(String cloudComponentHostName) {
        this.cloudComponentHostName = cloudComponentHostName;
    }

    @JsonProperty("requestUri")
    public Object getRequestUri() {
        return requestUri;
    }

    @JsonProperty("requestUri")
    public void setRequestUri(Object requestUri) {
        this.requestUri = requestUri;
    }

    @JsonProperty("statusCode")
    public String getStatusCode() {
        return statusCode;
    }

    @JsonProperty("statusCode")
    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
