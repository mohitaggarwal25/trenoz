
package com.dxl.oms.bean.ordersearch;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "CreatedTimestamp",
    "IsTaxIncluded",
    "RelatedChargeType",
    "Process",
    "ChargeReferenceId",
    "Reason",
    "IsProrated",
    "OriginalChargeAmount",
    "UpdatedBy",
    "TaxCode",
    "IsReturnCharge",
    "ChargeDetailId",
    "ParentChargeDetailId",
    "RelatedChargeDetailId",
    "IsProratedAtSameLevel",
    "UpdatedTimestamp",
    "ChargePercent",
    "CreatedBy",
    "ChargeTotal",
    "Comments",
    "TaxableAmount",
    "RequestedAmount",
    "IsOverridden",
    "IsPostReturn",
    "IsOrderDiscount",
    "FulfillmentGroupId",
    "OrgId",
    "ChargeSequence",
    "IsInformational",
    "DiscountOn",
    "ChargeType",
    "ChargeDisplayName",
    "ContextId",
    "PK",
    "ChangeLog"
})
public class OrderChargeDetail_ {

    @JsonProperty("CreatedTimestamp")
    private String createdTimestamp;
    @JsonProperty("IsTaxIncluded")
    private Boolean isTaxIncluded;
    @JsonProperty("RelatedChargeType")
    private Object relatedChargeType;
    @JsonProperty("Process")
    private Object process;
    @JsonProperty("ChargeReferenceId")
    private Object chargeReferenceId;
    @JsonProperty("Reason")
    private Object reason;
    @JsonProperty("IsProrated")
    private Boolean isProrated;
    @JsonProperty("OriginalChargeAmount")
    private Integer originalChargeAmount;
    @JsonProperty("UpdatedBy")
    private String updatedBy;
    @JsonProperty("TaxCode")
    private String taxCode;
    @JsonProperty("IsReturnCharge")
    private Boolean isReturnCharge;
    @JsonProperty("ChargeDetailId")
    private String chargeDetailId;
    @JsonProperty("ParentChargeDetailId")
    private Object parentChargeDetailId;
    @JsonProperty("RelatedChargeDetailId")
    private Object relatedChargeDetailId;
    @JsonProperty("IsProratedAtSameLevel")
    private Boolean isProratedAtSameLevel;
    @JsonProperty("UpdatedTimestamp")
    private String updatedTimestamp;
    @JsonProperty("ChargePercent")
    private Object chargePercent;
    @JsonProperty("CreatedBy")
    private String createdBy;
    @JsonProperty("ChargeTotal")
    private Double chargeTotal;
    @JsonProperty("Comments")
    private Object comments;
    @JsonProperty("TaxableAmount")
    private Object taxableAmount;
    @JsonProperty("RequestedAmount")
    private Object requestedAmount;
    @JsonProperty("IsOverridden")
    private Boolean isOverridden;
    @JsonProperty("IsPostReturn")
    private Boolean isPostReturn;
    @JsonProperty("IsOrderDiscount")
    private Boolean isOrderDiscount;
    @JsonProperty("FulfillmentGroupId")
    private String fulfillmentGroupId;
    @JsonProperty("OrgId")
    private String orgId;
    @JsonProperty("ChargeSequence")
    private Integer chargeSequence;
    @JsonProperty("IsInformational")
    private Boolean isInformational;
    @JsonProperty("DiscountOn")
    private Object discountOn;
    @JsonProperty("ChargeType")
    private ChargeType chargeType;
    @JsonProperty("ChargeDisplayName")
    private Object chargeDisplayName;
    @JsonProperty("ContextId")
    private String contextId;
    @JsonProperty("PK")
    private String pK;
    @JsonProperty("ChangeLog")
    private Object changeLog;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("CreatedTimestamp")
    public String getCreatedTimestamp() {
        return createdTimestamp;
    }

    @JsonProperty("CreatedTimestamp")
    public void setCreatedTimestamp(String createdTimestamp) {
        this.createdTimestamp = createdTimestamp;
    }

    @JsonProperty("IsTaxIncluded")
    public Boolean getIsTaxIncluded() {
        return isTaxIncluded;
    }

    @JsonProperty("IsTaxIncluded")
    public void setIsTaxIncluded(Boolean isTaxIncluded) {
        this.isTaxIncluded = isTaxIncluded;
    }

    @JsonProperty("RelatedChargeType")
    public Object getRelatedChargeType() {
        return relatedChargeType;
    }

    @JsonProperty("RelatedChargeType")
    public void setRelatedChargeType(Object relatedChargeType) {
        this.relatedChargeType = relatedChargeType;
    }

    @JsonProperty("Process")
    public Object getProcess() {
        return process;
    }

    @JsonProperty("Process")
    public void setProcess(Object process) {
        this.process = process;
    }

    @JsonProperty("ChargeReferenceId")
    public Object getChargeReferenceId() {
        return chargeReferenceId;
    }

    @JsonProperty("ChargeReferenceId")
    public void setChargeReferenceId(Object chargeReferenceId) {
        this.chargeReferenceId = chargeReferenceId;
    }

    @JsonProperty("Reason")
    public Object getReason() {
        return reason;
    }

    @JsonProperty("Reason")
    public void setReason(Object reason) {
        this.reason = reason;
    }

    @JsonProperty("IsProrated")
    public Boolean getIsProrated() {
        return isProrated;
    }

    @JsonProperty("IsProrated")
    public void setIsProrated(Boolean isProrated) {
        this.isProrated = isProrated;
    }

    @JsonProperty("OriginalChargeAmount")
    public Integer getOriginalChargeAmount() {
        return originalChargeAmount;
    }

    @JsonProperty("OriginalChargeAmount")
    public void setOriginalChargeAmount(Integer originalChargeAmount) {
        this.originalChargeAmount = originalChargeAmount;
    }

    @JsonProperty("UpdatedBy")
    public String getUpdatedBy() {
        return updatedBy;
    }

    @JsonProperty("UpdatedBy")
    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    @JsonProperty("TaxCode")
    public String getTaxCode() {
        return taxCode;
    }

    @JsonProperty("TaxCode")
    public void setTaxCode(String taxCode) {
        this.taxCode = taxCode;
    }

    @JsonProperty("IsReturnCharge")
    public Boolean getIsReturnCharge() {
        return isReturnCharge;
    }

    @JsonProperty("IsReturnCharge")
    public void setIsReturnCharge(Boolean isReturnCharge) {
        this.isReturnCharge = isReturnCharge;
    }

    @JsonProperty("ChargeDetailId")
    public String getChargeDetailId() {
        return chargeDetailId;
    }

    @JsonProperty("ChargeDetailId")
    public void setChargeDetailId(String chargeDetailId) {
        this.chargeDetailId = chargeDetailId;
    }

    @JsonProperty("ParentChargeDetailId")
    public Object getParentChargeDetailId() {
        return parentChargeDetailId;
    }

    @JsonProperty("ParentChargeDetailId")
    public void setParentChargeDetailId(Object parentChargeDetailId) {
        this.parentChargeDetailId = parentChargeDetailId;
    }

    @JsonProperty("RelatedChargeDetailId")
    public Object getRelatedChargeDetailId() {
        return relatedChargeDetailId;
    }

    @JsonProperty("RelatedChargeDetailId")
    public void setRelatedChargeDetailId(Object relatedChargeDetailId) {
        this.relatedChargeDetailId = relatedChargeDetailId;
    }

    @JsonProperty("IsProratedAtSameLevel")
    public Boolean getIsProratedAtSameLevel() {
        return isProratedAtSameLevel;
    }

    @JsonProperty("IsProratedAtSameLevel")
    public void setIsProratedAtSameLevel(Boolean isProratedAtSameLevel) {
        this.isProratedAtSameLevel = isProratedAtSameLevel;
    }

    @JsonProperty("UpdatedTimestamp")
    public String getUpdatedTimestamp() {
        return updatedTimestamp;
    }

    @JsonProperty("UpdatedTimestamp")
    public void setUpdatedTimestamp(String updatedTimestamp) {
        this.updatedTimestamp = updatedTimestamp;
    }

    @JsonProperty("ChargePercent")
    public Object getChargePercent() {
        return chargePercent;
    }

    @JsonProperty("ChargePercent")
    public void setChargePercent(Object chargePercent) {
        this.chargePercent = chargePercent;
    }

    @JsonProperty("CreatedBy")
    public String getCreatedBy() {
        return createdBy;
    }

    @JsonProperty("CreatedBy")
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    @JsonProperty("ChargeTotal")
    public Double getChargeTotal() {
        return chargeTotal;
    }

    @JsonProperty("ChargeTotal")
    public void setChargeTotal(Double chargeTotal) {
        this.chargeTotal = chargeTotal;
    }

    @JsonProperty("Comments")
    public Object getComments() {
        return comments;
    }

    @JsonProperty("Comments")
    public void setComments(Object comments) {
        this.comments = comments;
    }

    @JsonProperty("TaxableAmount")
    public Object getTaxableAmount() {
        return taxableAmount;
    }

    @JsonProperty("TaxableAmount")
    public void setTaxableAmount(Object taxableAmount) {
        this.taxableAmount = taxableAmount;
    }

    @JsonProperty("RequestedAmount")
    public Object getRequestedAmount() {
        return requestedAmount;
    }

    @JsonProperty("RequestedAmount")
    public void setRequestedAmount(Object requestedAmount) {
        this.requestedAmount = requestedAmount;
    }

    @JsonProperty("IsOverridden")
    public Boolean getIsOverridden() {
        return isOverridden;
    }

    @JsonProperty("IsOverridden")
    public void setIsOverridden(Boolean isOverridden) {
        this.isOverridden = isOverridden;
    }

    @JsonProperty("IsPostReturn")
    public Boolean getIsPostReturn() {
        return isPostReturn;
    }

    @JsonProperty("IsPostReturn")
    public void setIsPostReturn(Boolean isPostReturn) {
        this.isPostReturn = isPostReturn;
    }

    @JsonProperty("IsOrderDiscount")
    public Boolean getIsOrderDiscount() {
        return isOrderDiscount;
    }

    @JsonProperty("IsOrderDiscount")
    public void setIsOrderDiscount(Boolean isOrderDiscount) {
        this.isOrderDiscount = isOrderDiscount;
    }

    @JsonProperty("FulfillmentGroupId")
    public String getFulfillmentGroupId() {
        return fulfillmentGroupId;
    }

    @JsonProperty("FulfillmentGroupId")
    public void setFulfillmentGroupId(String fulfillmentGroupId) {
        this.fulfillmentGroupId = fulfillmentGroupId;
    }

    @JsonProperty("OrgId")
    public String getOrgId() {
        return orgId;
    }

    @JsonProperty("OrgId")
    public void setOrgId(String orgId) {
        this.orgId = orgId;
    }

    @JsonProperty("ChargeSequence")
    public Integer getChargeSequence() {
        return chargeSequence;
    }

    @JsonProperty("ChargeSequence")
    public void setChargeSequence(Integer chargeSequence) {
        this.chargeSequence = chargeSequence;
    }

    @JsonProperty("IsInformational")
    public Boolean getIsInformational() {
        return isInformational;
    }

    @JsonProperty("IsInformational")
    public void setIsInformational(Boolean isInformational) {
        this.isInformational = isInformational;
    }

    @JsonProperty("DiscountOn")
    public Object getDiscountOn() {
        return discountOn;
    }

    @JsonProperty("DiscountOn")
    public void setDiscountOn(Object discountOn) {
        this.discountOn = discountOn;
    }

    @JsonProperty("ChargeType")
    public ChargeType getChargeType() {
        return chargeType;
    }

    @JsonProperty("ChargeType")
    public void setChargeType(ChargeType chargeType) {
        this.chargeType = chargeType;
    }

    @JsonProperty("ChargeDisplayName")
    public Object getChargeDisplayName() {
        return chargeDisplayName;
    }

    @JsonProperty("ChargeDisplayName")
    public void setChargeDisplayName(Object chargeDisplayName) {
        this.chargeDisplayName = chargeDisplayName;
    }

    @JsonProperty("ContextId")
    public String getContextId() {
        return contextId;
    }

    @JsonProperty("ContextId")
    public void setContextId(String contextId) {
        this.contextId = contextId;
    }

    @JsonProperty("PK")
    public String getPK() {
        return pK;
    }

    @JsonProperty("PK")
    public void setPK(String pK) {
        this.pK = pK;
    }

    @JsonProperty("ChangeLog")
    public Object getChangeLog() {
        return changeLog;
    }

    @JsonProperty("ChangeLog")
    public void setChangeLog(Object changeLog) {
        this.changeLog = changeLog;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
