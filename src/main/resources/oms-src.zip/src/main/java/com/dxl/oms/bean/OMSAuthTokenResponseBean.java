package com.dxl.oms.bean;

import java.io.Serializable;
import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.annotate.JsonPropertyOrder;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonPropertyOrder({
"access_token",
"token_type",
"refresh_token",
"expires_in",
"scope",
"userOrgs",
"organization",
"userLocations",
"locale",
"userTimeZone",
"jti"
})
public class OMSAuthTokenResponseBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@JsonProperty("access_token")
	private String accessToken;
	
	@JsonProperty("token_type")
	private String tokenType;
	
	@JsonProperty("refresh_token")
	private String refreshToken;
	
	@JsonProperty("expires_in")
	private Integer expiresIn;
	
	@JsonProperty("scope")
	private String scope;
	
	@JsonProperty("userOrgs")
	private List<String> userOrgs = null;
	
	@JsonProperty("organization")
	private String organization;
	
	@JsonProperty("userLocations")
	private List<Object> userLocations = null;
	
	@JsonProperty("locale")
	private String locale;
	
	@JsonProperty("userTimeZone")
	private String userTimeZone;
	
	@JsonProperty("jti")
	private String jti;

	@JsonProperty("access_token")
	public String getAccessToken() {
	return accessToken;
	}
	
	@JsonProperty("access_token")
	public void setAccessToken(String accessToken) {
	this.accessToken = accessToken;
	}
	
	@JsonProperty("token_type")
	public String getTokenType() {
	return tokenType;
	}
	
	@JsonProperty("token_type")
	public void setTokenType(String tokenType) {
	this.tokenType = tokenType;
	}
	
	@JsonProperty("refresh_token")
	public String getRefreshToken() {
	return refreshToken;
	}
	
	@JsonProperty("refresh_token")
	public void setRefreshToken(String refreshToken) {
	this.refreshToken = refreshToken;
	}
	
	@JsonProperty("expires_in")
	public Integer getExpiresIn() {
	return expiresIn;
	}
	
	@JsonProperty("expires_in")
	public void setExpiresIn(Integer expiresIn) {
	this.expiresIn = expiresIn;
	}
	
	@JsonProperty("scope")
	public String getScope() {
	return scope;
	}
	
	@JsonProperty("scope")
	public void setScope(String scope) {
	this.scope = scope;
	}
	
	@JsonProperty("userOrgs")
	public List<String> getUserOrgs() {
	return userOrgs;
	}
	
	@JsonProperty("userOrgs")
	public void setUserOrgs(List<String> userOrgs) {
	this.userOrgs = userOrgs;
	}
	
	@JsonProperty("organization")
	public String getOrganization() {
	return organization;
	}
	
	@JsonProperty("organization")
	public void setOrganization(String organization) {
	this.organization = organization;
	}
	
	@JsonProperty("userLocations")
	public List<Object> getUserLocations() {
	return userLocations;
	}
	
	@JsonProperty("userLocations")
	public void setUserLocations(List<Object> userLocations) {
	this.userLocations = userLocations;
	}
	
	@JsonProperty("locale")
	public String getLocale() {
	return locale;
	}
	
	@JsonProperty("locale")
	public void setLocale(String locale) {
	this.locale = locale;
	}
	
	@JsonProperty("userTimeZone")
	public String getUserTimeZone() {
	return userTimeZone;
	}
	
	@JsonProperty("userTimeZone")
	public void setUserTimeZone(String userTimeZone) {
	this.userTimeZone = userTimeZone;
	}
	
	@JsonProperty("jti")
	public String getJti() {
	return jti;
	}
	
	@JsonProperty("jti")
	public void setJti(String jti) {
	this.jti = jti;
	}


}
