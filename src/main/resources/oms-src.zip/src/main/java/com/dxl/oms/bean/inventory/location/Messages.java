
package com.dxl.oms.bean.inventory.location;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "Message",
    "Size"
})
public class Messages {

    @JsonProperty("Message")
    private List<Object> message = null;
    @JsonProperty("Size")
    private Integer size;

    @JsonProperty("Message")
    public List<Object> getMessage() {
        return message;
    }

    @JsonProperty("Message")
    public void setMessage(List<Object> message) {
        this.message = message;
    }

    @JsonProperty("Size")
    public Integer getSize() {
        return size;
    }

    @JsonProperty("Size")
    public void setSize(Integer size) {
        this.size = size;
    }

}
