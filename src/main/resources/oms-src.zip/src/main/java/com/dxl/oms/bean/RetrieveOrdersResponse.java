
package com.dxl.oms.bean;

import com.dxl.oms.bean.orderhistory.OrderHistory;

public class RetrieveOrdersResponse {
	private OrderHistory omsResponse;
	private boolean success = false;

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

	public OrderHistory getOmsResponse() {
		return omsResponse;
	}

	public void setOmsResponse(OrderHistory omsResponse) {
		this.omsResponse = omsResponse;
	}
}
