
package com.dxl.oms.bean.ordersearch;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "Actions",
    "PK",
    "CreatedBy",
    "CreatedTimestamp",
    "UpdatedBy",
    "UpdatedTimestamp",
    "Translations",
    "Messages",
    "OrgId",
    "OrderId",
    "PaymentGroupId",
    "CustomerId",
    "IsCancelled",
    "PaymentMethod",
    "Status",
    "Extended"
})
public class Payment {

    @JsonProperty("Actions")
    private Actions actions;
    @JsonProperty("PK")
    private String pK;
    @JsonProperty("CreatedBy")
    private String createdBy;
    @JsonProperty("CreatedTimestamp")
    private String createdTimestamp;
    @JsonProperty("UpdatedBy")
    private String updatedBy;
    @JsonProperty("UpdatedTimestamp")
    private String updatedTimestamp;
    @JsonProperty("Translations")
    private Object translations;
    @JsonProperty("Messages")
    private Object messages;
    @JsonProperty("OrgId")
    private String orgId;
    @JsonProperty("OrderId")
    private String orderId;
    @JsonProperty("PaymentGroupId")
    private Object paymentGroupId;
    @JsonProperty("CustomerId")
    private Object customerId;
    @JsonProperty("IsCancelled")
    private Boolean isCancelled;
    @JsonProperty("PaymentMethod")
    private List<PaymentMethod> paymentMethod = null;
    @JsonProperty("Status")
    private Status status;
    @JsonProperty("Extended")
    private Extended___ extended;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("Actions")
    public Actions getActions() {
        return actions;
    }

    @JsonProperty("Actions")
    public void setActions(Actions actions) {
        this.actions = actions;
    }

    @JsonProperty("PK")
    public String getPK() {
        return pK;
    }

    @JsonProperty("PK")
    public void setPK(String pK) {
        this.pK = pK;
    }

    @JsonProperty("CreatedBy")
    public String getCreatedBy() {
        return createdBy;
    }

    @JsonProperty("CreatedBy")
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    @JsonProperty("CreatedTimestamp")
    public String getCreatedTimestamp() {
        return createdTimestamp;
    }

    @JsonProperty("CreatedTimestamp")
    public void setCreatedTimestamp(String createdTimestamp) {
        this.createdTimestamp = createdTimestamp;
    }

    @JsonProperty("UpdatedBy")
    public String getUpdatedBy() {
        return updatedBy;
    }

    @JsonProperty("UpdatedBy")
    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    @JsonProperty("UpdatedTimestamp")
    public String getUpdatedTimestamp() {
        return updatedTimestamp;
    }

    @JsonProperty("UpdatedTimestamp")
    public void setUpdatedTimestamp(String updatedTimestamp) {
        this.updatedTimestamp = updatedTimestamp;
    }

    @JsonProperty("Translations")
    public Object getTranslations() {
        return translations;
    }

    @JsonProperty("Translations")
    public void setTranslations(Object translations) {
        this.translations = translations;
    }

    @JsonProperty("Messages")
    public Object getMessages() {
        return messages;
    }

    @JsonProperty("Messages")
    public void setMessages(Object messages) {
        this.messages = messages;
    }

    @JsonProperty("OrgId")
    public String getOrgId() {
        return orgId;
    }

    @JsonProperty("OrgId")
    public void setOrgId(String orgId) {
        this.orgId = orgId;
    }

    @JsonProperty("OrderId")
    public String getOrderId() {
        return orderId;
    }

    @JsonProperty("OrderId")
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    @JsonProperty("PaymentGroupId")
    public Object getPaymentGroupId() {
        return paymentGroupId;
    }

    @JsonProperty("PaymentGroupId")
    public void setPaymentGroupId(Object paymentGroupId) {
        this.paymentGroupId = paymentGroupId;
    }

    @JsonProperty("CustomerId")
    public Object getCustomerId() {
        return customerId;
    }

    @JsonProperty("CustomerId")
    public void setCustomerId(Object customerId) {
        this.customerId = customerId;
    }

    @JsonProperty("IsCancelled")
    public Boolean getIsCancelled() {
        return isCancelled;
    }

    @JsonProperty("IsCancelled")
    public void setIsCancelled(Boolean isCancelled) {
        this.isCancelled = isCancelled;
    }

    @JsonProperty("PaymentMethod")
    public List<PaymentMethod> getPaymentMethod() {
        return paymentMethod;
    }

    @JsonProperty("PaymentMethod")
    public void setPaymentMethod(List<PaymentMethod> paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    @JsonProperty("Status")
    public Status getStatus() {
        return status;
    }

    @JsonProperty("Status")
    public void setStatus(Status status) {
        this.status = status;
    }

    @JsonProperty("Extended")
    public Extended___ getExtended() {
        return extended;
    }

    @JsonProperty("Extended")
    public void setExtended(Extended___ extended) {
        this.extended = extended;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
