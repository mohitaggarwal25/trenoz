package com.dxl.order;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.dxl.bean.DXLContactInfo;
import com.dxl.bean.DXLOrderHistoryItemDetail;
import com.dxl.commerce.catalog.DXLCatalogTools;
import com.dxl.commerce.inventory.DXLInventoryManager;
import com.dxl.commerce.order.payment.bean.PaymentGroupData;
import com.dxl.commerce.order.payment.bean.PaymentTypeEnum;
import com.dxl.commerce.order.shipping.bean.ShippingGroupData;
import com.dxl.commerce.order.shipping.bean.ShippingMethodData;
import com.dxl.commerce.order.shipping.bean.TrackingNumberData;
import com.dxl.common.GlobalApplicationConfiguration;
import com.dxl.constants.DXLConstants;
import com.dxl.oms.bean.orderhistory.Datum;
import com.dxl.oms.bean.orderhistory.OrderHistory;
import com.dxl.oms.bean.ordersearch.Address;
import com.dxl.oms.bean.ordersearch.Data;
import com.dxl.oms.bean.ordersearch.OrderChargeDetail_;
import com.dxl.oms.bean.ordersearch.OrderLine;
import com.dxl.oms.bean.ordersearch.OrderSearch;
import com.dxl.oms.bean.ordersearch.Payment;
import com.dxl.oms.bean.ordersearch.PaymentMethod;
import com.dxl.oms.bean.ordersearch.ShipToAddress_;
import com.dxl.order.data.DXLTrackOrderData;
import com.dxl.order.data.OrderData;
import com.dxl.order.data.OrderItemData;
import com.dxl.order.data.OrderPriceData;
import com.dxl.order.data.OrderStatusEnum;
import com.dxl.seo.DXLSeoTools;
import com.dxl.shipping.ShippingMethodTools;
import com.dxl.utils.DateUtil;
import com.dxl.utils.StringUtil;

import atg.commerce.inventory.InventoryException;
import atg.core.util.Range;
import atg.nucleus.GenericService;
import atg.repository.RepositoryException;
import atg.repository.RepositoryItem;

public class OMSOrderDataPopulator extends GenericService {

	private String urlWhenNumberStartsWith1z;
	private String urlWhenNumberStartsWith9Or0;
	private ShippingMethodTools shippingMethodTools;
	private DXLCatalogTools catalogTools;
	private DXLInventoryManager inventoryManager;
	private GlobalApplicationConfiguration globalAppConfig;
	private DXLSeoTools seoTools;
	private Map<String, String> omsStatusMap;

	public static final String SHIPPING_METHOD_CODE_PROPERTY_NAME = "shipMethodCode";
	public static final String SHIPPING_STATUS_BACK_ORDERED = "Back Ordered";

	public List<DXLOrderHistoryItemDetail> populate(OrderHistory omsResponse) {
		List<DXLOrderHistoryItemDetail> ordersList = populateOrderHistory(omsResponse.getData());
		return ordersList;
	}

	public List<DXLOrderHistoryItemDetail> populateOrderHistory(List<Datum> omsOrders) {
		List<DXLOrderHistoryItemDetail> ordersList = new ArrayList<>();
		if (omsOrders != null && !omsOrders.isEmpty()) {
			for (Datum omsOrder : omsOrders) {
				DXLOrderHistoryItemDetail order = new DXLOrderHistoryItemDetail();
				order.setOrderId(omsOrder.getOrderId());
				order.setOrderNumber(omsOrder.getOrderId());
				order.setOrderStatus(omsStatusMap.get(omsOrder.getFulfillmentStatus()));
				order.setSubmitDate(getSubmitDate(omsOrder.getCreatedTimestamp()));
				ordersList.add(order);
			}
		}
		return ordersList;
	}

	public OrderData populate(OrderSearch order) {
		DXLTrackOrderData orderData = new DXLTrackOrderData();
		populateOrderDetails(order.getData(), orderData);
		return orderData;
	}

	public void populateOrderDetails(Data omsOrderData, DXLTrackOrderData orderData) {
		if (omsOrderData != null) {
			orderData.setId(omsOrderData.getOrderId());
			orderData.setOrderNumber(omsOrderData.getOrderId());
			orderData.setSubmitDate(getSubmitDate(omsOrderData.getCreatedTimestamp()));
			orderData.setStatusMessage(omsStatusMap.get(omsOrderData.getFulfillmentStatus()));
			orderData.setStatus(OrderStatusEnum.toEnum(omsStatusMap.get(omsOrderData.getFulfillmentStatus())));
			setShippingGroups(omsOrderData, orderData);
			orderData.setTotals(populateOrderPriceData(omsOrderData));
			orderData.setPaymentGroups(populatePaymentGroup(omsOrderData));
			orderData.setEcometry(false);
		}
	}

	private List<PaymentGroupData> populatePaymentGroup(Data omsOrderData) {
		List<PaymentGroupData> paymentGroups = null;
		if (omsOrderData.getPayment() != null && !omsOrderData.getPayment().isEmpty()) {
			paymentGroups = new ArrayList<PaymentGroupData>();
			for (Payment paymentData : omsOrderData.getPayment()) {
				if (paymentData.getPaymentMethod() != null && !paymentData.getPaymentMethod().isEmpty()) {
					for (PaymentMethod paymentMethod : paymentData.getPaymentMethod()) {
						PaymentGroupData paymentGroup = new PaymentGroupData();
						if (paymentMethod.getBillingAddress() != null && paymentMethod.getBillingAddress().getAddress() != null) {
							Address billAddress = paymentMethod.getBillingAddress().getAddress();
							paymentGroup.setBillingAddress(setAddress(billAddress, paymentMethod.getBillingAddress().getOrgId()));
						}
						if(paymentMethod.getAmount() > 0.0) {
							paymentGroup.setAmount(paymentMethod.getAmount());
						} else if (paymentMethod.getCurrentAuthAmount() > 0.0) {
							paymentGroup.setAmount(paymentMethod.getCurrentAuthAmount());
						}
						String paymentType = paymentMethod.getPaymentType().getPaymentTypeId();
						paymentGroup.setType(PaymentTypeEnum.toEnum(paymentType));
						paymentGroup.setPaymentType(PaymentTypeEnum.toEnum(paymentType).toString());
						if (paymentGroup.getType() == PaymentTypeEnum.CREDITCARD && paymentMethod.getCardType() != null) {
							paymentGroup.setCardType(paymentMethod.getCardType().getCardTypeId());
						}
						paymentGroups.add(paymentGroup);
					}
				}
			}
		}
		return paymentGroups;
	}

	public Date getSubmitDate(String orderDate) {

		DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");
		Date submitDate = null;
		try {
			submitDate = df.parse(orderDate);
		} catch (ParseException e) {
			if (isLoggingError()) {
				logError("ParseException for: ", e);
			}
		}
		return submitDate;
	}

	private void populateShippingMethod(Data omsOrderData, OrderLine lineItem, ShippingGroupData shippingGroupData) {
		if (lineItem.getShippingMethodId() != null) {
			String shippingMethodCode = lineItem.getShippingMethodId();
			Address shipTo = lineItem.getShipToAddress().getAddress();
			ShippingMethodData shippingMethodData = new ShippingMethodData();
			shippingMethodData = populateShippingMethodData(shippingMethodCode, getSubmitDate(omsOrderData.getCreatedTimestamp()), shipTo.getPostalCode());
			shippingGroupData.setShippingMethod(shippingMethodData);
		}
	}

	private void setBackOrderShippingDate(ShippingGroupData shippingGroupData, String productId) {
		Date availableDate = null;
		String estimateShipping = null;
		try {
			availableDate = (Date) getInventoryManager().queryAvailabilityDate(productId);
		} catch (InventoryException e) {
			if (isLoggingError()) {
				vlogError(e, "error while fetching AvailabilityDate for product: {0} ", productId);
			}
		}
		Set<Date> holidays = getGlobalAppConfig().getHolidays();
		if (null != availableDate) {
			estimateShipping = DateUtil.addedBoundDateForEstimatedShipping(5, availableDate, holidays);
		}
		shippingGroupData.setBackOrderShippingDate(estimateShipping);
	}

	private OrderItemData setItems(ShippingGroupData shippingGroupData, OrderLine lineItem) {
		OrderItemData orderItemData = new OrderItemData();
		populateProductData(shippingGroupData, orderItemData, lineItem);
		orderItemData.setQuantity(lineItem.getQuantity());
		orderItemData.setLineItemId(lineItem.getItemId());
		orderItemData.setTotalPrice(lineItem.getUnitPrice());
		orderItemData.setItemStatus(omsStatusMap.get(lineItem.getFulfillmentStatus()));
		return orderItemData;
	}

	private void getTrackingDetails(ShippingGroupData shippingGroupData, OrderLine lineItem) {
		TrackingNumberData trackingNumberData = new TrackingNumberData();
		if (lineItem.getFulfillmentDetail() != null && !lineItem.getFulfillmentDetail().isEmpty()) {
			String trackingNo = lineItem.getFulfillmentDetail().get(0).getTrackingNumber();
			trackingNumberData.setTrackingNumber(trackingNo);
			trackingNumberData.setTrackingUrl(getTrackingUrlForTrackingNumber(trackingNo));
		}
		shippingGroupData.setTrackingNumberData(trackingNumberData);
	}

	private String getTrackingUrlForTrackingNumber(String trackingNumber) {
		String trackingUrl = null;
		if (StringUtil.isNotEmpty(trackingNumber)) {
			if (trackingNumber.startsWith("1Z") || trackingNumber.startsWith("1z")) {
				trackingUrl = getUrlWhenNumberStartsWith1z().concat(trackingNumber);
			} else if (trackingNumber.startsWith("9") || trackingNumber.startsWith("0")) {
				trackingUrl = getUrlWhenNumberStartsWith9Or0().concat(trackingNumber);
			}
		}
		return trackingUrl;
	}

	private DXLContactInfo setAddress(Address address, String orgId) {
		DXLContactInfo domesticAddress = new DXLContactInfo();

		domesticAddress.setFirstName(address.getFirstName());
		domesticAddress.setLastName(address.getLastName());
		// TODO domesticAddress.setMiddleName(shipTo.getMiddleInitial());
		domesticAddress.setCompanyName(orgId);
		domesticAddress.setCountry(address.getCountry());
		domesticAddress.setPhoneNumber(address.getPhone());
		domesticAddress.setAddress3(address.getAddress3());
		domesticAddress.setAddress2(address.getAddress2());
		domesticAddress.setAddress1(address.getAddress1());
		domesticAddress.setCity(address.getCity());
		domesticAddress.setState(address.getState());
		domesticAddress.setPostalCode(address.getPostalCode());
		domesticAddress.setEmail(address.getEmail());
		return domesticAddress;
	}

	private void populateProductData(ShippingGroupData shippingGroupData, OrderItemData orderItemData, OrderLine lineItem) {

		if (orderItemData != null) {
			try {
				RepositoryItem skuItem = getCatalogTools().findSKUByEdpNo(lineItem.getItemId());
				if (skuItem != null) {
					orderItemData.setSkuId(skuItem.getRepositoryId());
					orderItemData.setSkuDescription((String) skuItem.getPropertyValue(DXLConstants.SKU_DESCRIPTION_PROPERTY_NAME));
					RepositoryItem productItem = getCatalogTools().findProductBySkuId(skuItem.getRepositoryId());
					if (productItem != null) {
						String productId = productItem.getRepositoryId();
						orderItemData.setProductId(productId);
						orderItemData.setProductDescription((String) productItem.getPropertyValue(DXLConstants.PRODUCT_DESCRIPTION_PROPERTY_NAME));
						if (lineItem.getFulfillmentStatus().equalsIgnoreCase(SHIPPING_STATUS_BACK_ORDERED)) {
							setBackOrderShippingDate(shippingGroupData, productId);
						}
						orderItemData.setWebURL(getSeoTools().generateProductLink(productId));
					}
				}
			} catch (RepositoryException e) {
				if (isLoggingError()) {
					logError("Error while fetching sku/product item from catalog", e);
				}
			}
		}
	}

	private void setShippingGroups(Data omsOrderData, DXLTrackOrderData orderData) {
		List<OrderLine> orderLineList = omsOrderData.getOrderLine();
		if (orderLineList != null && !orderLineList.isEmpty()) {
			Map<String, ShippingGroupData> shippingGroupMap = new HashMap<String, ShippingGroupData>();
			orderData.setShippingGroups(new ArrayList<ShippingGroupData>());
			ShippingGroupData shippingGroupData = null;
			List<OrderItemData> orderItemDatas = new ArrayList<OrderItemData>();
			for (OrderLine lineItem : orderLineList) {
				ShipToAddress_ address = lineItem.getShipToAddress();
				if (shippingGroupMap.get(address.getAddressId()) == null) {
					shippingGroupData = new ShippingGroupData();
					shippingGroupData.setShippingAddress(setAddress(address.getAddress(), lineItem.getOrgId()));
					getTrackingDetails(shippingGroupData, lineItem);
					shippingGroupData.setItems(new ArrayList<String>());
					shippingGroupData.setDataItems(new ArrayList<OrderItemData>());
					populateShippingMethod(omsOrderData, lineItem, shippingGroupData);
					shippingGroupMap.put(address.getAddressId(), shippingGroupData);
				} else {
					shippingGroupData = shippingGroupMap.get(address.getAddressId());
				}
				if (shippingGroupData != null) {
					OrderItemData orderItemData = setItems(shippingGroupData, lineItem);
					shippingGroupData.getDataItems().add(orderItemData);
					orderItemDatas.add(orderItemData);
					orderData.setItems(orderItemDatas);
					shippingGroupData.setStatus(omsStatusMap.get(lineItem.getFulfillmentStatus()));
					shippingGroupData.getItems().add(lineItem.getItemId());
				}
			}
			orderData.getShippingGroups().add(shippingGroupData);
		}
	}

	private OrderPriceData populateOrderPriceData(Data omsOrderData) {
		if (omsOrderData != null) {
			OrderPriceData orderPriceData = new OrderPriceData();
			orderPriceData.setTaxTotal(omsOrderData.getTotalTaxes());
			orderPriceData.setShippingTotal(populateShippingTotal(omsOrderData));
			orderPriceData.setProductSubtotal(omsOrderData.getOrderSubTotal());
			orderPriceData.setOrderTotal(omsOrderData.getOrderTotal());
			return orderPriceData;
		}
		return null;
	}

	private Double populateShippingTotal(Data omsOrderData) {
		Double shippingTotal = 0.0d;
		if (omsOrderData.getOrderChargeDetail() != null && !omsOrderData.getOrderChargeDetail().isEmpty()) {
			OrderChargeDetail_ shippingCharge = omsOrderData.getOrderChargeDetail().get(0);
			if (shippingCharge.getChargeType().getChargeTypeId().equals("Shipping")) {
				shippingTotal = shippingCharge.getChargeTotal();
			}
		}
		return shippingTotal;
	}

	private ShippingMethodData populateShippingMethodData(String shippingMethodCode, Date submittedDate, String zipCode) {
		ShippingMethodData shippingMethodData = new ShippingMethodData();
		if (StringUtil.isNotEmpty(shippingMethodCode)) {
			try {
				RepositoryItem shippingMethodItem = getShippingMethodTools().getShippingMethodFromCode(shippingMethodCode);
				if (null != shippingMethodItem) {
					shippingMethodData = populateFromShippingMethod(shippingMethodItem, submittedDate, zipCode);
				}
			} catch (RepositoryException e) {
				if (isLoggingError()) {
					vlogError(e, "Error while fetching shippingMethod item: ", shippingMethodCode);
				}
			}
		}
		return shippingMethodData;
	}

	private ShippingMethodData populateFromShippingMethod(RepositoryItem shippingMethodItem, Date submittedDate, String zipCode) {
		ShippingMethodData shippingMethodData = new ShippingMethodData();

		setShippingMethodData(shippingMethodItem, shippingMethodData);

		try {
			RepositoryItem shippingDecisionItem = getShippingMethodTools().getShippingMethodDecision(shippingMethodData.getShippingMethodCode(), zipCode);
			if (null != shippingDecisionItem) {
				String days = (String) shippingDecisionItem.getPropertyValue("days");
				String shippingMethodCode = (String) shippingDecisionItem.getPropertyValue(SHIPPING_METHOD_CODE_PROPERTY_NAME);
				if (StringUtil.isNotEmpty(days)) {
					Range daysRange = getShippingMethodTools().getRangeWithShippingSlowdown(shippingMethodCode, StringUtil.toRange(days, "-"));
					Set<Date> holidays = getGlobalAppConfig().getHolidays();
					long lowBound = daysRange.getLowBound();
					if (lowBound > 0) {
						String businessDaysLowBound = DateUtil.addedBoundDateForEstimatedShipping(lowBound, submittedDate, holidays);
						shippingMethodData.setEstimatedShippingDateLowBound(businessDaysLowBound);
					}
					long highBound = daysRange.getHighBound();
					if (highBound > 0 && highBound > lowBound) {
						String businessDaysHighBound = DateUtil.addedBoundDateForEstimatedShipping(highBound, submittedDate, holidays);
						shippingMethodData.setEstimatedShippingDateHighBound(businessDaysHighBound);
					}
				}
			}
		} catch (RepositoryException e) {
			if (isLoggingError()) {
				logError("Error while fetching shippingDecisionItem", e);
			}
		}
		return shippingMethodData;
	}

	private void setShippingMethodData(RepositoryItem shippingMethodRepItem, ShippingMethodData shippingMethodData) {
		shippingMethodData.setId(shippingMethodRepItem.getRepositoryId());
		shippingMethodData.setShippingMethodCode((String) shippingMethodRepItem.getPropertyValue("shippingMethodCode"));
		shippingMethodData.setShippingCarrier((String) shippingMethodRepItem.getPropertyValue("shippingCarrier"));
		shippingMethodData.setShippingMethod((String) shippingMethodRepItem.getPropertyValue("shippingMethod"));
		shippingMethodData.setDisplayName((String) shippingMethodRepItem.getPropertyValue("displayName"));
		shippingMethodData.setExpedited((Boolean) shippingMethodRepItem.getPropertyValue("expedited"));
		shippingMethodData.setShipToStore((Boolean) shippingMethodRepItem.getPropertyValue("shipToStore"));
		shippingMethodData.setOverridePrice((Boolean) shippingMethodRepItem.getPropertyValue("overridePrice"));
		shippingMethodData.setGiftCardOnly((Boolean) shippingMethodRepItem.getPropertyValue("giftCardOnly"));
	}

	public String getUrlWhenNumberStartsWith1z() {
		return urlWhenNumberStartsWith1z;
	}

	public void setUrlWhenNumberStartsWith1z(String urlWhenNumberStartsWith1z) {
		this.urlWhenNumberStartsWith1z = urlWhenNumberStartsWith1z;
	}

	public String getUrlWhenNumberStartsWith9Or0() {
		return urlWhenNumberStartsWith9Or0;
	}

	public void setUrlWhenNumberStartsWith9Or0(String urlWhenNumberStartsWith9Or0) {
		this.urlWhenNumberStartsWith9Or0 = urlWhenNumberStartsWith9Or0;
	}

	public ShippingMethodTools getShippingMethodTools() {
		return shippingMethodTools;
	}

	public void setShippingMethodTools(ShippingMethodTools shippingMethodTools) {
		this.shippingMethodTools = shippingMethodTools;
	}

	public DXLCatalogTools getCatalogTools() {
		return catalogTools;
	}

	public void setCatalogTools(DXLCatalogTools catalogTools) {
		this.catalogTools = catalogTools;
	}

	public DXLInventoryManager getInventoryManager() {
		return inventoryManager;
	}

	public void setInventoryManager(DXLInventoryManager inventoryManager) {
		this.inventoryManager = inventoryManager;
	}

	public GlobalApplicationConfiguration getGlobalAppConfig() {
		return globalAppConfig;
	}

	public void setGlobalAppConfig(GlobalApplicationConfiguration globalAppConfig) {
		this.globalAppConfig = globalAppConfig;
	}

	public DXLSeoTools getSeoTools() {
		return seoTools;
	}

	public void setSeoTools(DXLSeoTools seoTools) {
		this.seoTools = seoTools;
	}

	public Map<String, String> getOmsStatusMap() {
		return omsStatusMap;
	}

	public void setOmsStatusMap(Map<String, String> omsStatusMap) {
		this.omsStatusMap = omsStatusMap;
	}
}