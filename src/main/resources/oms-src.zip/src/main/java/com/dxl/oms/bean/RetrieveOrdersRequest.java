
package com.dxl.oms.bean;

import com.dxl.oms.bean.orderhistory.OrderHistoryRequest;

public class RetrieveOrdersRequest {
	private OrderHistoryRequest request;

	public OrderHistoryRequest getRequest() {
		return request;
	}

	public void setRequest(OrderHistoryRequest request) {
		this.request = request;
	}
}
