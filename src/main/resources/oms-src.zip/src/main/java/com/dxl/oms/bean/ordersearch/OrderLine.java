
package com.dxl.oms.bean.ordersearch;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "ParentLineCreatedTimestamp",
    "CreatedTimestamp",
    "BusinessDate",
    "RefundPrice",
    "IsHazmat",
    "TaxOverrideValue",
    "MaxFulfillmentStatusId",
    "OrderLineCancelHistory",
    "StoreSaleEntryMethod",
    "ShippingMethodId",
    "ItemMaxDiscountPercentage",
    "UpdatedBy",
    "OrderLineSalesAssociate",
    "OrderLineSubTotal",
    "ItemStyle",
    "ParentOrderId",
    "ReturnableQuantity",
    "OrderLineHold",
    "CreatedBy",
    "SmallImageURI",
    "IsCancelled",
    "CancelledOrderLineSubTotal",
    "ItemBrand",
    "ReturnType",
    "IsPerishable",
    "GiftCardValue",
    "ContextId",
    "IsPriceOverridden",
    "IsPreSale",
    "HasComponents",
    "ItemMaxDiscountAmount",
    "ItemDepartmentName",
    "IsExchangeable",
    "ItemColorDescription",
    "OrderLineAttribute",
    "IsReturn",
    "IsTaxOverridden",
    "OrderLineNote",
    "OrderLineTagDetail",
    "OrderLinePickupDetail",
    "ProductClass",
    "MinFulfillmentStatusId",
    "PaymentGroupId",
    "MinFulfillmentStatus",
    "UpdatedTimestamp",
    "EffectiveRank",
    "DeliveryMethod",
    "TaxOverrideType",
    "TaxableAmount",
    "TotalDiscountOnItem",
    "CancelledTotalDiscounts",
    "ReturnLineTotalWithoutFees",
    "IsReturnableAtStore",
    "FulfillmentGroupId",
    "ReturnDetail",
    "OrgId",
    "UnitPrice",
    "MaxAppeasementAmount",
    "ItemShortDescription",
    "CarrierCode",
    "ItemBarcode",
    "QuantityDetail",
    "ChangeLog",
    "PromisedShipDate",
    "TotalDiscounts",
    "ShipToAddress",
    "ServiceLevelCode",
    "ItemDepartmentNumber",
    "IsReturnable",
    "IsTaxIncluded",
    "OrderLinePriceOverrideHistory",
    "IsOnHold",
    "IsReceiptExpected",
    "OrderLineComponents",
    "Process",
    "ItemId",
    "PhysicalOriginId",
    "ReturnableLineTotal",
    "SellingLocationId",
    "IsGift",
    "FulfillmentStatus",
    "ParentOrderLineId",
    "TotalCharges",
    "ParentOrderLineType",
    "AddressId",
    "ShipFromAddress",
    "VolumetricWeight",
    "Priority",
    "OrderId",
    "IsPreOrder",
    "PromisedDeliveryDate",
    "ItemTaxCode",
    "CancelReason",
    "LatestDeliveryDate",
    "StreetDate",
    "OrderLinePromotionRequest",
    "AlternateOrderLineId",
    "OrderLinePromisingInfo",
    "DoNotShipBeforeDate",
    "OrderLineTaxDetail",
    "IsItemTaxOverridable",
    "OrderLineChargeDetail",
    "ItemSeason",
    "OrderLineTotal",
    "ItemDescription",
    "IsItemTaxExemptable",
    "Allocation",
    "OrderLineVASInstructions",
    "PipelineId",
    "ItemSize",
    "IsNonMerchandise",
    "LineType",
    "ShipToLocationId",
    "ShipFromAddressId",
    "IsActivationRequired",
    "Quantity",
    "IsItemNotOnFile",
    "IsPackAndHold",
    "IsGiftCard",
    "CancelComments",
    "MaxFulfillmentStatus",
    "VolumetricWeightUOM",
    "OrderLineExtension1",
    "FulfillmentDetail",
    "OrderLineExtension2",
    "UOM",
    "OrderLineId",
    "TotalTaxes",
    "OrderLineAdditional",
    "TransactionReferenceId",
    "RequestedDeliveryDate",
    "PK",
    "OriginalUnitPrice",
    "IsEvenExchange",
    "LineProcessInfo"
})
public class OrderLine {

    @JsonProperty("ParentLineCreatedTimestamp")
    private Object parentLineCreatedTimestamp;
    @JsonProperty("CreatedTimestamp")
    private String createdTimestamp;
    @JsonProperty("BusinessDate")
    private Object businessDate;
    @JsonProperty("RefundPrice")
    private Object refundPrice;
    @JsonProperty("IsHazmat")
    private Boolean isHazmat;
    @JsonProperty("TaxOverrideValue")
    private Object taxOverrideValue;
    @JsonProperty("MaxFulfillmentStatusId")
    private String maxFulfillmentStatusId;
    @JsonProperty("OrderLineCancelHistory")
    private List<Object> orderLineCancelHistory = null;
    @JsonProperty("StoreSaleEntryMethod")
    private Object storeSaleEntryMethod;
    @JsonProperty("ShippingMethodId")
    private String shippingMethodId;
    @JsonProperty("ItemMaxDiscountPercentage")
    private Object itemMaxDiscountPercentage;
    @JsonProperty("UpdatedBy")
    private String updatedBy;
    @JsonProperty("OrderLineSalesAssociate")
    private List<Object> orderLineSalesAssociate = null;
    @JsonProperty("OrderLineSubTotal")
    private Double orderLineSubTotal;
    @JsonProperty("ItemStyle")
    private String itemStyle;
    @JsonProperty("ParentOrderId")
    private Object parentOrderId;
    @JsonProperty("ReturnableQuantity")
    private Integer returnableQuantity;
    @JsonProperty("OrderLineHold")
    private List<Object> orderLineHold = null;
    @JsonProperty("CreatedBy")
    private String createdBy;
    @JsonProperty("SmallImageURI")
    private String smallImageURI;
    @JsonProperty("IsCancelled")
    private Boolean isCancelled;
    @JsonProperty("CancelledOrderLineSubTotal")
    private Object cancelledOrderLineSubTotal;
    @JsonProperty("ItemBrand")
    private String itemBrand;
    @JsonProperty("ReturnType")
    private Object returnType;
    @JsonProperty("IsPerishable")
    private Boolean isPerishable;
    @JsonProperty("GiftCardValue")
    private Object giftCardValue;
    @JsonProperty("ContextId")
    private String contextId;
    @JsonProperty("IsPriceOverridden")
    private Boolean isPriceOverridden;
    @JsonProperty("IsPreSale")
    private Boolean isPreSale;
    @JsonProperty("HasComponents")
    private Boolean hasComponents;
    @JsonProperty("ItemMaxDiscountAmount")
    private Object itemMaxDiscountAmount;
    @JsonProperty("ItemDepartmentName")
    private Object itemDepartmentName;
    @JsonProperty("IsExchangeable")
    private Boolean isExchangeable;
    @JsonProperty("ItemColorDescription")
    private String itemColorDescription;
    @JsonProperty("OrderLineAttribute")
    private List<Object> orderLineAttribute = null;
    @JsonProperty("IsReturn")
    private Boolean isReturn;
    @JsonProperty("IsTaxOverridden")
    private Boolean isTaxOverridden;
    @JsonProperty("OrderLineNote")
    private List<Object> orderLineNote = null;
    @JsonProperty("OrderLineTagDetail")
    private List<Object> orderLineTagDetail = null;
    @JsonProperty("OrderLinePickupDetail")
    private List<Object> orderLinePickupDetail = null;
    @JsonProperty("ProductClass")
    private Object productClass;
    @JsonProperty("MinFulfillmentStatusId")
    private String minFulfillmentStatusId;
    @JsonProperty("PaymentGroupId")
    private Object paymentGroupId;
    @JsonProperty("MinFulfillmentStatus")
    private MinFulfillmentStatus minFulfillmentStatus;
    @JsonProperty("UpdatedTimestamp")
    private String updatedTimestamp;
    @JsonProperty("EffectiveRank")
    private String effectiveRank;
    @JsonProperty("DeliveryMethod")
    private DeliveryMethod deliveryMethod;
    @JsonProperty("TaxOverrideType")
    private Object taxOverrideType;
    @JsonProperty("TaxableAmount")
    private Object taxableAmount;
    @JsonProperty("TotalDiscountOnItem")
    private Integer totalDiscountOnItem;
    @JsonProperty("CancelledTotalDiscounts")
    private Object cancelledTotalDiscounts;
    @JsonProperty("ReturnLineTotalWithoutFees")
    private Integer returnLineTotalWithoutFees;
    @JsonProperty("IsReturnableAtStore")
    private Boolean isReturnableAtStore;
    @JsonProperty("FulfillmentGroupId")
    private String fulfillmentGroupId;
    @JsonProperty("ReturnDetail")
    private List<Object> returnDetail = null;
    @JsonProperty("OrgId")
    private String orgId;
    @JsonProperty("UnitPrice")
    private Double unitPrice;
    @JsonProperty("MaxAppeasementAmount")
    private Double maxAppeasementAmount;
    @JsonProperty("ItemShortDescription")
    private String itemShortDescription;
    @JsonProperty("CarrierCode")
    private Object carrierCode;
    @JsonProperty("ItemBarcode")
    private Object itemBarcode;
    @JsonProperty("QuantityDetail")
    private List<QuantityDetail> quantityDetail = null;
    @JsonProperty("ChangeLog")
    private Object changeLog;
    @JsonProperty("PromisedShipDate")
    private Object promisedShipDate;
    @JsonProperty("TotalDiscounts")
    private Object totalDiscounts;
    @JsonProperty("ShipToAddress")
    private ShipToAddress_ shipToAddress;
    @JsonProperty("ServiceLevelCode")
    private Object serviceLevelCode;
    @JsonProperty("ItemDepartmentNumber")
    private Object itemDepartmentNumber;
    @JsonProperty("IsReturnable")
    private Boolean isReturnable;
    @JsonProperty("IsTaxIncluded")
    private Boolean isTaxIncluded;
    @JsonProperty("OrderLinePriceOverrideHistory")
    private List<Object> orderLinePriceOverrideHistory = null;
    @JsonProperty("IsOnHold")
    private Boolean isOnHold;
    @JsonProperty("IsReceiptExpected")
    private Boolean isReceiptExpected;
    @JsonProperty("OrderLineComponents")
    private List<Object> orderLineComponents = null;
    @JsonProperty("Process")
    private Object process;
    @JsonProperty("ItemId")
    private String itemId;
    @JsonProperty("PhysicalOriginId")
    private String physicalOriginId;
    @JsonProperty("ReturnableLineTotal")
    private Double returnableLineTotal;
    @JsonProperty("SellingLocationId")
    private Object sellingLocationId;
    @JsonProperty("IsGift")
    private Boolean isGift;
    @JsonProperty("FulfillmentStatus")
    private String fulfillmentStatus;
    @JsonProperty("ParentOrderLineId")
    private Object parentOrderLineId;
    @JsonProperty("TotalCharges")
    private Object totalCharges;
    @JsonProperty("ParentOrderLineType")
    private Object parentOrderLineType;
    @JsonProperty("AddressId")
    private String addressId;
    @JsonProperty("ShipFromAddress")
    private Object shipFromAddress;
    @JsonProperty("VolumetricWeight")
    private Object volumetricWeight;
    @JsonProperty("Priority")
    private Object priority;
    @JsonProperty("OrderId")
    private String orderId;
    @JsonProperty("IsPreOrder")
    private Boolean isPreOrder;
    @JsonProperty("PromisedDeliveryDate")
    private Object promisedDeliveryDate;
    @JsonProperty("ItemTaxCode")
    private Object itemTaxCode;
    @JsonProperty("CancelReason")
    private Object cancelReason;
    @JsonProperty("LatestDeliveryDate")
    private Object latestDeliveryDate;
    @JsonProperty("StreetDate")
    private Object streetDate;
    @JsonProperty("OrderLinePromotionRequest")
    private List<Object> orderLinePromotionRequest = null;
    @JsonProperty("AlternateOrderLineId")
    private Object alternateOrderLineId;
    @JsonProperty("OrderLinePromisingInfo")
    private Object orderLinePromisingInfo;
    @JsonProperty("DoNotShipBeforeDate")
    private Object doNotShipBeforeDate;
    @JsonProperty("OrderLineTaxDetail")
    private List<OrderLineTaxDetail> orderLineTaxDetail = null;
    @JsonProperty("IsItemTaxOverridable")
    private Boolean isItemTaxOverridable;
    @JsonProperty("OrderLineChargeDetail")
    private List<Object> orderLineChargeDetail = null;
    @JsonProperty("ItemSeason")
    private Object itemSeason;
    @JsonProperty("OrderLineTotal")
    private Double orderLineTotal;
    @JsonProperty("ItemDescription")
    private String itemDescription;
    @JsonProperty("IsItemTaxExemptable")
    private Boolean isItemTaxExemptable;
    @JsonProperty("Allocation")
    private List<Allocation> allocation = null;
    @JsonProperty("OrderLineVASInstructions")
    private List<Object> orderLineVASInstructions = null;
    @JsonProperty("PipelineId")
    private String pipelineId;
    @JsonProperty("ItemSize")
    private String itemSize;
    @JsonProperty("IsNonMerchandise")
    private Boolean isNonMerchandise;
    @JsonProperty("LineType")
    private Object lineType;
    @JsonProperty("ShipToLocationId")
    private Object shipToLocationId;
    @JsonProperty("ShipFromAddressId")
    private Object shipFromAddressId;
    @JsonProperty("IsActivationRequired")
    private Boolean isActivationRequired;
    @JsonProperty("Quantity")
    private Integer quantity;
    @JsonProperty("IsItemNotOnFile")
    private Boolean isItemNotOnFile;
    @JsonProperty("IsPackAndHold")
    private Boolean isPackAndHold;
    @JsonProperty("IsGiftCard")
    private Boolean isGiftCard;
    @JsonProperty("CancelComments")
    private Object cancelComments;
    @JsonProperty("MaxFulfillmentStatus")
    private MaxFulfillmentStatus maxFulfillmentStatus;
    @JsonProperty("VolumetricWeightUOM")
    private Object volumetricWeightUOM;
    @JsonProperty("OrderLineExtension1")
    private Object orderLineExtension1;
    @JsonProperty("FulfillmentDetail")
    private List<FulfillmentDetail> fulfillmentDetail = null;
    @JsonProperty("OrderLineExtension2")
    private List<Object> orderLineExtension2 = null;
    @JsonProperty("UOM")
    private String uOM;
    @JsonProperty("OrderLineId")
    private String orderLineId;
    @JsonProperty("TotalTaxes")
    private Double totalTaxes;
    @JsonProperty("OrderLineAdditional")
    private Object orderLineAdditional;
    @JsonProperty("TransactionReferenceId")
    private Object transactionReferenceId;
    @JsonProperty("RequestedDeliveryDate")
    private Object requestedDeliveryDate;
    @JsonProperty("PK")
    private String pK;
    @JsonProperty("OriginalUnitPrice")
    private Object originalUnitPrice;
    @JsonProperty("IsEvenExchange")
    private Boolean isEvenExchange;
    @JsonProperty("LineProcessInfo")
    private Object lineProcessInfo;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("ParentLineCreatedTimestamp")
    public Object getParentLineCreatedTimestamp() {
        return parentLineCreatedTimestamp;
    }

    @JsonProperty("ParentLineCreatedTimestamp")
    public void setParentLineCreatedTimestamp(Object parentLineCreatedTimestamp) {
        this.parentLineCreatedTimestamp = parentLineCreatedTimestamp;
    }

    @JsonProperty("CreatedTimestamp")
    public String getCreatedTimestamp() {
        return createdTimestamp;
    }

    @JsonProperty("CreatedTimestamp")
    public void setCreatedTimestamp(String createdTimestamp) {
        this.createdTimestamp = createdTimestamp;
    }

    @JsonProperty("BusinessDate")
    public Object getBusinessDate() {
        return businessDate;
    }

    @JsonProperty("BusinessDate")
    public void setBusinessDate(Object businessDate) {
        this.businessDate = businessDate;
    }

    @JsonProperty("RefundPrice")
    public Object getRefundPrice() {
        return refundPrice;
    }

    @JsonProperty("RefundPrice")
    public void setRefundPrice(Object refundPrice) {
        this.refundPrice = refundPrice;
    }

    @JsonProperty("IsHazmat")
    public Boolean getIsHazmat() {
        return isHazmat;
    }

    @JsonProperty("IsHazmat")
    public void setIsHazmat(Boolean isHazmat) {
        this.isHazmat = isHazmat;
    }

    @JsonProperty("TaxOverrideValue")
    public Object getTaxOverrideValue() {
        return taxOverrideValue;
    }

    @JsonProperty("TaxOverrideValue")
    public void setTaxOverrideValue(Object taxOverrideValue) {
        this.taxOverrideValue = taxOverrideValue;
    }

    @JsonProperty("MaxFulfillmentStatusId")
    public String getMaxFulfillmentStatusId() {
        return maxFulfillmentStatusId;
    }

    @JsonProperty("MaxFulfillmentStatusId")
    public void setMaxFulfillmentStatusId(String maxFulfillmentStatusId) {
        this.maxFulfillmentStatusId = maxFulfillmentStatusId;
    }

    @JsonProperty("OrderLineCancelHistory")
    public List<Object> getOrderLineCancelHistory() {
        return orderLineCancelHistory;
    }

    @JsonProperty("OrderLineCancelHistory")
    public void setOrderLineCancelHistory(List<Object> orderLineCancelHistory) {
        this.orderLineCancelHistory = orderLineCancelHistory;
    }

    @JsonProperty("StoreSaleEntryMethod")
    public Object getStoreSaleEntryMethod() {
        return storeSaleEntryMethod;
    }

    @JsonProperty("StoreSaleEntryMethod")
    public void setStoreSaleEntryMethod(Object storeSaleEntryMethod) {
        this.storeSaleEntryMethod = storeSaleEntryMethod;
    }

    @JsonProperty("ShippingMethodId")
    public String getShippingMethodId() {
        return shippingMethodId;
    }

    @JsonProperty("ShippingMethodId")
    public void setShippingMethodId(String shippingMethodId) {
        this.shippingMethodId = shippingMethodId;
    }

    @JsonProperty("ItemMaxDiscountPercentage")
    public Object getItemMaxDiscountPercentage() {
        return itemMaxDiscountPercentage;
    }

    @JsonProperty("ItemMaxDiscountPercentage")
    public void setItemMaxDiscountPercentage(Object itemMaxDiscountPercentage) {
        this.itemMaxDiscountPercentage = itemMaxDiscountPercentage;
    }

    @JsonProperty("UpdatedBy")
    public String getUpdatedBy() {
        return updatedBy;
    }

    @JsonProperty("UpdatedBy")
    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    @JsonProperty("OrderLineSalesAssociate")
    public List<Object> getOrderLineSalesAssociate() {
        return orderLineSalesAssociate;
    }

    @JsonProperty("OrderLineSalesAssociate")
    public void setOrderLineSalesAssociate(List<Object> orderLineSalesAssociate) {
        this.orderLineSalesAssociate = orderLineSalesAssociate;
    }

    @JsonProperty("OrderLineSubTotal")
    public Double getOrderLineSubTotal() {
        return orderLineSubTotal;
    }

    @JsonProperty("OrderLineSubTotal")
    public void setOrderLineSubTotal(Double orderLineSubTotal) {
        this.orderLineSubTotal = orderLineSubTotal;
    }

    @JsonProperty("ItemStyle")
    public String getItemStyle() {
        return itemStyle;
    }

    @JsonProperty("ItemStyle")
    public void setItemStyle(String itemStyle) {
        this.itemStyle = itemStyle;
    }

    @JsonProperty("ParentOrderId")
    public Object getParentOrderId() {
        return parentOrderId;
    }

    @JsonProperty("ParentOrderId")
    public void setParentOrderId(Object parentOrderId) {
        this.parentOrderId = parentOrderId;
    }

    @JsonProperty("ReturnableQuantity")
    public Integer getReturnableQuantity() {
        return returnableQuantity;
    }

    @JsonProperty("ReturnableQuantity")
    public void setReturnableQuantity(Integer returnableQuantity) {
        this.returnableQuantity = returnableQuantity;
    }

    @JsonProperty("OrderLineHold")
    public List<Object> getOrderLineHold() {
        return orderLineHold;
    }

    @JsonProperty("OrderLineHold")
    public void setOrderLineHold(List<Object> orderLineHold) {
        this.orderLineHold = orderLineHold;
    }

    @JsonProperty("CreatedBy")
    public String getCreatedBy() {
        return createdBy;
    }

    @JsonProperty("CreatedBy")
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    @JsonProperty("SmallImageURI")
    public String getSmallImageURI() {
        return smallImageURI;
    }

    @JsonProperty("SmallImageURI")
    public void setSmallImageURI(String smallImageURI) {
        this.smallImageURI = smallImageURI;
    }

    @JsonProperty("IsCancelled")
    public Boolean getIsCancelled() {
        return isCancelled;
    }

    @JsonProperty("IsCancelled")
    public void setIsCancelled(Boolean isCancelled) {
        this.isCancelled = isCancelled;
    }

    @JsonProperty("CancelledOrderLineSubTotal")
    public Object getCancelledOrderLineSubTotal() {
        return cancelledOrderLineSubTotal;
    }

    @JsonProperty("CancelledOrderLineSubTotal")
    public void setCancelledOrderLineSubTotal(Object cancelledOrderLineSubTotal) {
        this.cancelledOrderLineSubTotal = cancelledOrderLineSubTotal;
    }

    @JsonProperty("ItemBrand")
    public String getItemBrand() {
        return itemBrand;
    }

    @JsonProperty("ItemBrand")
    public void setItemBrand(String itemBrand) {
        this.itemBrand = itemBrand;
    }

    @JsonProperty("ReturnType")
    public Object getReturnType() {
        return returnType;
    }

    @JsonProperty("ReturnType")
    public void setReturnType(Object returnType) {
        this.returnType = returnType;
    }

    @JsonProperty("IsPerishable")
    public Boolean getIsPerishable() {
        return isPerishable;
    }

    @JsonProperty("IsPerishable")
    public void setIsPerishable(Boolean isPerishable) {
        this.isPerishable = isPerishable;
    }

    @JsonProperty("GiftCardValue")
    public Object getGiftCardValue() {
        return giftCardValue;
    }

    @JsonProperty("GiftCardValue")
    public void setGiftCardValue(Object giftCardValue) {
        this.giftCardValue = giftCardValue;
    }

    @JsonProperty("ContextId")
    public String getContextId() {
        return contextId;
    }

    @JsonProperty("ContextId")
    public void setContextId(String contextId) {
        this.contextId = contextId;
    }

    @JsonProperty("IsPriceOverridden")
    public Boolean getIsPriceOverridden() {
        return isPriceOverridden;
    }

    @JsonProperty("IsPriceOverridden")
    public void setIsPriceOverridden(Boolean isPriceOverridden) {
        this.isPriceOverridden = isPriceOverridden;
    }

    @JsonProperty("IsPreSale")
    public Boolean getIsPreSale() {
        return isPreSale;
    }

    @JsonProperty("IsPreSale")
    public void setIsPreSale(Boolean isPreSale) {
        this.isPreSale = isPreSale;
    }

    @JsonProperty("HasComponents")
    public Boolean getHasComponents() {
        return hasComponents;
    }

    @JsonProperty("HasComponents")
    public void setHasComponents(Boolean hasComponents) {
        this.hasComponents = hasComponents;
    }

    @JsonProperty("ItemMaxDiscountAmount")
    public Object getItemMaxDiscountAmount() {
        return itemMaxDiscountAmount;
    }

    @JsonProperty("ItemMaxDiscountAmount")
    public void setItemMaxDiscountAmount(Object itemMaxDiscountAmount) {
        this.itemMaxDiscountAmount = itemMaxDiscountAmount;
    }

    @JsonProperty("ItemDepartmentName")
    public Object getItemDepartmentName() {
        return itemDepartmentName;
    }

    @JsonProperty("ItemDepartmentName")
    public void setItemDepartmentName(Object itemDepartmentName) {
        this.itemDepartmentName = itemDepartmentName;
    }

    @JsonProperty("IsExchangeable")
    public Boolean getIsExchangeable() {
        return isExchangeable;
    }

    @JsonProperty("IsExchangeable")
    public void setIsExchangeable(Boolean isExchangeable) {
        this.isExchangeable = isExchangeable;
    }

    @JsonProperty("ItemColorDescription")
    public String getItemColorDescription() {
        return itemColorDescription;
    }

    @JsonProperty("ItemColorDescription")
    public void setItemColorDescription(String itemColorDescription) {
        this.itemColorDescription = itemColorDescription;
    }

    @JsonProperty("OrderLineAttribute")
    public List<Object> getOrderLineAttribute() {
        return orderLineAttribute;
    }

    @JsonProperty("OrderLineAttribute")
    public void setOrderLineAttribute(List<Object> orderLineAttribute) {
        this.orderLineAttribute = orderLineAttribute;
    }

    @JsonProperty("IsReturn")
    public Boolean getIsReturn() {
        return isReturn;
    }

    @JsonProperty("IsReturn")
    public void setIsReturn(Boolean isReturn) {
        this.isReturn = isReturn;
    }

    @JsonProperty("IsTaxOverridden")
    public Boolean getIsTaxOverridden() {
        return isTaxOverridden;
    }

    @JsonProperty("IsTaxOverridden")
    public void setIsTaxOverridden(Boolean isTaxOverridden) {
        this.isTaxOverridden = isTaxOverridden;
    }

    @JsonProperty("OrderLineNote")
    public List<Object> getOrderLineNote() {
        return orderLineNote;
    }

    @JsonProperty("OrderLineNote")
    public void setOrderLineNote(List<Object> orderLineNote) {
        this.orderLineNote = orderLineNote;
    }

    @JsonProperty("OrderLineTagDetail")
    public List<Object> getOrderLineTagDetail() {
        return orderLineTagDetail;
    }

    @JsonProperty("OrderLineTagDetail")
    public void setOrderLineTagDetail(List<Object> orderLineTagDetail) {
        this.orderLineTagDetail = orderLineTagDetail;
    }

    @JsonProperty("OrderLinePickupDetail")
    public List<Object> getOrderLinePickupDetail() {
        return orderLinePickupDetail;
    }

    @JsonProperty("OrderLinePickupDetail")
    public void setOrderLinePickupDetail(List<Object> orderLinePickupDetail) {
        this.orderLinePickupDetail = orderLinePickupDetail;
    }

    @JsonProperty("ProductClass")
    public Object getProductClass() {
        return productClass;
    }

    @JsonProperty("ProductClass")
    public void setProductClass(Object productClass) {
        this.productClass = productClass;
    }

    @JsonProperty("MinFulfillmentStatusId")
    public String getMinFulfillmentStatusId() {
        return minFulfillmentStatusId;
    }

    @JsonProperty("MinFulfillmentStatusId")
    public void setMinFulfillmentStatusId(String minFulfillmentStatusId) {
        this.minFulfillmentStatusId = minFulfillmentStatusId;
    }

    @JsonProperty("PaymentGroupId")
    public Object getPaymentGroupId() {
        return paymentGroupId;
    }

    @JsonProperty("PaymentGroupId")
    public void setPaymentGroupId(Object paymentGroupId) {
        this.paymentGroupId = paymentGroupId;
    }

    @JsonProperty("MinFulfillmentStatus")
    public MinFulfillmentStatus getMinFulfillmentStatus() {
        return minFulfillmentStatus;
    }

    @JsonProperty("MinFulfillmentStatus")
    public void setMinFulfillmentStatus(MinFulfillmentStatus minFulfillmentStatus) {
        this.minFulfillmentStatus = minFulfillmentStatus;
    }

    @JsonProperty("UpdatedTimestamp")
    public String getUpdatedTimestamp() {
        return updatedTimestamp;
    }

    @JsonProperty("UpdatedTimestamp")
    public void setUpdatedTimestamp(String updatedTimestamp) {
        this.updatedTimestamp = updatedTimestamp;
    }

    @JsonProperty("EffectiveRank")
    public String getEffectiveRank() {
        return effectiveRank;
    }

    @JsonProperty("EffectiveRank")
    public void setEffectiveRank(String effectiveRank) {
        this.effectiveRank = effectiveRank;
    }

    @JsonProperty("DeliveryMethod")
    public DeliveryMethod getDeliveryMethod() {
        return deliveryMethod;
    }

    @JsonProperty("DeliveryMethod")
    public void setDeliveryMethod(DeliveryMethod deliveryMethod) {
        this.deliveryMethod = deliveryMethod;
    }

    @JsonProperty("TaxOverrideType")
    public Object getTaxOverrideType() {
        return taxOverrideType;
    }

    @JsonProperty("TaxOverrideType")
    public void setTaxOverrideType(Object taxOverrideType) {
        this.taxOverrideType = taxOverrideType;
    }

    @JsonProperty("TaxableAmount")
    public Object getTaxableAmount() {
        return taxableAmount;
    }

    @JsonProperty("TaxableAmount")
    public void setTaxableAmount(Object taxableAmount) {
        this.taxableAmount = taxableAmount;
    }

    @JsonProperty("TotalDiscountOnItem")
    public Integer getTotalDiscountOnItem() {
        return totalDiscountOnItem;
    }

    @JsonProperty("TotalDiscountOnItem")
    public void setTotalDiscountOnItem(Integer totalDiscountOnItem) {
        this.totalDiscountOnItem = totalDiscountOnItem;
    }

    @JsonProperty("CancelledTotalDiscounts")
    public Object getCancelledTotalDiscounts() {
        return cancelledTotalDiscounts;
    }

    @JsonProperty("CancelledTotalDiscounts")
    public void setCancelledTotalDiscounts(Object cancelledTotalDiscounts) {
        this.cancelledTotalDiscounts = cancelledTotalDiscounts;
    }

    @JsonProperty("ReturnLineTotalWithoutFees")
    public Integer getReturnLineTotalWithoutFees() {
        return returnLineTotalWithoutFees;
    }

    @JsonProperty("ReturnLineTotalWithoutFees")
    public void setReturnLineTotalWithoutFees(Integer returnLineTotalWithoutFees) {
        this.returnLineTotalWithoutFees = returnLineTotalWithoutFees;
    }

    @JsonProperty("IsReturnableAtStore")
    public Boolean getIsReturnableAtStore() {
        return isReturnableAtStore;
    }

    @JsonProperty("IsReturnableAtStore")
    public void setIsReturnableAtStore(Boolean isReturnableAtStore) {
        this.isReturnableAtStore = isReturnableAtStore;
    }

    @JsonProperty("FulfillmentGroupId")
    public String getFulfillmentGroupId() {
        return fulfillmentGroupId;
    }

    @JsonProperty("FulfillmentGroupId")
    public void setFulfillmentGroupId(String fulfillmentGroupId) {
        this.fulfillmentGroupId = fulfillmentGroupId;
    }

    @JsonProperty("ReturnDetail")
    public List<Object> getReturnDetail() {
        return returnDetail;
    }

    @JsonProperty("ReturnDetail")
    public void setReturnDetail(List<Object> returnDetail) {
        this.returnDetail = returnDetail;
    }

    @JsonProperty("OrgId")
    public String getOrgId() {
        return orgId;
    }

    @JsonProperty("OrgId")
    public void setOrgId(String orgId) {
        this.orgId = orgId;
    }

    @JsonProperty("UnitPrice")
    public Double getUnitPrice() {
        return unitPrice;
    }

    @JsonProperty("UnitPrice")
    public void setUnitPrice(Double unitPrice) {
        this.unitPrice = unitPrice;
    }

    @JsonProperty("MaxAppeasementAmount")
    public Double getMaxAppeasementAmount() {
        return maxAppeasementAmount;
    }

    @JsonProperty("MaxAppeasementAmount")
    public void setMaxAppeasementAmount(Double maxAppeasementAmount) {
        this.maxAppeasementAmount = maxAppeasementAmount;
    }

    @JsonProperty("ItemShortDescription")
    public String getItemShortDescription() {
        return itemShortDescription;
    }

    @JsonProperty("ItemShortDescription")
    public void setItemShortDescription(String itemShortDescription) {
        this.itemShortDescription = itemShortDescription;
    }

    @JsonProperty("CarrierCode")
    public Object getCarrierCode() {
        return carrierCode;
    }

    @JsonProperty("CarrierCode")
    public void setCarrierCode(Object carrierCode) {
        this.carrierCode = carrierCode;
    }

    @JsonProperty("ItemBarcode")
    public Object getItemBarcode() {
        return itemBarcode;
    }

    @JsonProperty("ItemBarcode")
    public void setItemBarcode(Object itemBarcode) {
        this.itemBarcode = itemBarcode;
    }

    @JsonProperty("QuantityDetail")
    public List<QuantityDetail> getQuantityDetail() {
        return quantityDetail;
    }

    @JsonProperty("QuantityDetail")
    public void setQuantityDetail(List<QuantityDetail> quantityDetail) {
        this.quantityDetail = quantityDetail;
    }

    @JsonProperty("ChangeLog")
    public Object getChangeLog() {
        return changeLog;
    }

    @JsonProperty("ChangeLog")
    public void setChangeLog(Object changeLog) {
        this.changeLog = changeLog;
    }

    @JsonProperty("PromisedShipDate")
    public Object getPromisedShipDate() {
        return promisedShipDate;
    }

    @JsonProperty("PromisedShipDate")
    public void setPromisedShipDate(Object promisedShipDate) {
        this.promisedShipDate = promisedShipDate;
    }

    @JsonProperty("TotalDiscounts")
    public Object getTotalDiscounts() {
        return totalDiscounts;
    }

    @JsonProperty("TotalDiscounts")
    public void setTotalDiscounts(Object totalDiscounts) {
        this.totalDiscounts = totalDiscounts;
    }

    @JsonProperty("ShipToAddress")
    public ShipToAddress_ getShipToAddress() {
        return shipToAddress;
    }

    @JsonProperty("ShipToAddress")
    public void setShipToAddress(ShipToAddress_ shipToAddress) {
        this.shipToAddress = shipToAddress;
    }

    @JsonProperty("ServiceLevelCode")
    public Object getServiceLevelCode() {
        return serviceLevelCode;
    }

    @JsonProperty("ServiceLevelCode")
    public void setServiceLevelCode(Object serviceLevelCode) {
        this.serviceLevelCode = serviceLevelCode;
    }

    @JsonProperty("ItemDepartmentNumber")
    public Object getItemDepartmentNumber() {
        return itemDepartmentNumber;
    }

    @JsonProperty("ItemDepartmentNumber")
    public void setItemDepartmentNumber(Object itemDepartmentNumber) {
        this.itemDepartmentNumber = itemDepartmentNumber;
    }

    @JsonProperty("IsReturnable")
    public Boolean getIsReturnable() {
        return isReturnable;
    }

    @JsonProperty("IsReturnable")
    public void setIsReturnable(Boolean isReturnable) {
        this.isReturnable = isReturnable;
    }

    @JsonProperty("IsTaxIncluded")
    public Boolean getIsTaxIncluded() {
        return isTaxIncluded;
    }

    @JsonProperty("IsTaxIncluded")
    public void setIsTaxIncluded(Boolean isTaxIncluded) {
        this.isTaxIncluded = isTaxIncluded;
    }

    @JsonProperty("OrderLinePriceOverrideHistory")
    public List<Object> getOrderLinePriceOverrideHistory() {
        return orderLinePriceOverrideHistory;
    }

    @JsonProperty("OrderLinePriceOverrideHistory")
    public void setOrderLinePriceOverrideHistory(List<Object> orderLinePriceOverrideHistory) {
        this.orderLinePriceOverrideHistory = orderLinePriceOverrideHistory;
    }

    @JsonProperty("IsOnHold")
    public Boolean getIsOnHold() {
        return isOnHold;
    }

    @JsonProperty("IsOnHold")
    public void setIsOnHold(Boolean isOnHold) {
        this.isOnHold = isOnHold;
    }

    @JsonProperty("IsReceiptExpected")
    public Boolean getIsReceiptExpected() {
        return isReceiptExpected;
    }

    @JsonProperty("IsReceiptExpected")
    public void setIsReceiptExpected(Boolean isReceiptExpected) {
        this.isReceiptExpected = isReceiptExpected;
    }

    @JsonProperty("OrderLineComponents")
    public List<Object> getOrderLineComponents() {
        return orderLineComponents;
    }

    @JsonProperty("OrderLineComponents")
    public void setOrderLineComponents(List<Object> orderLineComponents) {
        this.orderLineComponents = orderLineComponents;
    }

    @JsonProperty("Process")
    public Object getProcess() {
        return process;
    }

    @JsonProperty("Process")
    public void setProcess(Object process) {
        this.process = process;
    }

    @JsonProperty("ItemId")
    public String getItemId() {
        return itemId;
    }

    @JsonProperty("ItemId")
    public void setItemId(String itemId) {
        this.itemId = itemId;
    }

    @JsonProperty("PhysicalOriginId")
    public String getPhysicalOriginId() {
        return physicalOriginId;
    }

    @JsonProperty("PhysicalOriginId")
    public void setPhysicalOriginId(String physicalOriginId) {
        this.physicalOriginId = physicalOriginId;
    }

    @JsonProperty("ReturnableLineTotal")
    public Double getReturnableLineTotal() {
        return returnableLineTotal;
    }

    @JsonProperty("ReturnableLineTotal")
    public void setReturnableLineTotal(Double returnableLineTotal) {
        this.returnableLineTotal = returnableLineTotal;
    }

    @JsonProperty("SellingLocationId")
    public Object getSellingLocationId() {
        return sellingLocationId;
    }

    @JsonProperty("SellingLocationId")
    public void setSellingLocationId(Object sellingLocationId) {
        this.sellingLocationId = sellingLocationId;
    }

    @JsonProperty("IsGift")
    public Boolean getIsGift() {
        return isGift;
    }

    @JsonProperty("IsGift")
    public void setIsGift(Boolean isGift) {
        this.isGift = isGift;
    }

    @JsonProperty("FulfillmentStatus")
    public String getFulfillmentStatus() {
        return fulfillmentStatus;
    }

    @JsonProperty("FulfillmentStatus")
    public void setFulfillmentStatus(String fulfillmentStatus) {
        this.fulfillmentStatus = fulfillmentStatus;
    }

    @JsonProperty("ParentOrderLineId")
    public Object getParentOrderLineId() {
        return parentOrderLineId;
    }

    @JsonProperty("ParentOrderLineId")
    public void setParentOrderLineId(Object parentOrderLineId) {
        this.parentOrderLineId = parentOrderLineId;
    }

    @JsonProperty("TotalCharges")
    public Object getTotalCharges() {
        return totalCharges;
    }

    @JsonProperty("TotalCharges")
    public void setTotalCharges(Object totalCharges) {
        this.totalCharges = totalCharges;
    }

    @JsonProperty("ParentOrderLineType")
    public Object getParentOrderLineType() {
        return parentOrderLineType;
    }

    @JsonProperty("ParentOrderLineType")
    public void setParentOrderLineType(Object parentOrderLineType) {
        this.parentOrderLineType = parentOrderLineType;
    }

    @JsonProperty("AddressId")
    public String getAddressId() {
        return addressId;
    }

    @JsonProperty("AddressId")
    public void setAddressId(String addressId) {
        this.addressId = addressId;
    }

    @JsonProperty("ShipFromAddress")
    public Object getShipFromAddress() {
        return shipFromAddress;
    }

    @JsonProperty("ShipFromAddress")
    public void setShipFromAddress(Object shipFromAddress) {
        this.shipFromAddress = shipFromAddress;
    }

    @JsonProperty("VolumetricWeight")
    public Object getVolumetricWeight() {
        return volumetricWeight;
    }

    @JsonProperty("VolumetricWeight")
    public void setVolumetricWeight(Object volumetricWeight) {
        this.volumetricWeight = volumetricWeight;
    }

    @JsonProperty("Priority")
    public Object getPriority() {
        return priority;
    }

    @JsonProperty("Priority")
    public void setPriority(Object priority) {
        this.priority = priority;
    }

    @JsonProperty("OrderId")
    public String getOrderId() {
        return orderId;
    }

    @JsonProperty("OrderId")
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    @JsonProperty("IsPreOrder")
    public Boolean getIsPreOrder() {
        return isPreOrder;
    }

    @JsonProperty("IsPreOrder")
    public void setIsPreOrder(Boolean isPreOrder) {
        this.isPreOrder = isPreOrder;
    }

    @JsonProperty("PromisedDeliveryDate")
    public Object getPromisedDeliveryDate() {
        return promisedDeliveryDate;
    }

    @JsonProperty("PromisedDeliveryDate")
    public void setPromisedDeliveryDate(Object promisedDeliveryDate) {
        this.promisedDeliveryDate = promisedDeliveryDate;
    }

    @JsonProperty("ItemTaxCode")
    public Object getItemTaxCode() {
        return itemTaxCode;
    }

    @JsonProperty("ItemTaxCode")
    public void setItemTaxCode(Object itemTaxCode) {
        this.itemTaxCode = itemTaxCode;
    }

    @JsonProperty("CancelReason")
    public Object getCancelReason() {
        return cancelReason;
    }

    @JsonProperty("CancelReason")
    public void setCancelReason(Object cancelReason) {
        this.cancelReason = cancelReason;
    }

    @JsonProperty("LatestDeliveryDate")
    public Object getLatestDeliveryDate() {
        return latestDeliveryDate;
    }

    @JsonProperty("LatestDeliveryDate")
    public void setLatestDeliveryDate(Object latestDeliveryDate) {
        this.latestDeliveryDate = latestDeliveryDate;
    }

    @JsonProperty("StreetDate")
    public Object getStreetDate() {
        return streetDate;
    }

    @JsonProperty("StreetDate")
    public void setStreetDate(Object streetDate) {
        this.streetDate = streetDate;
    }

    @JsonProperty("OrderLinePromotionRequest")
    public List<Object> getOrderLinePromotionRequest() {
        return orderLinePromotionRequest;
    }

    @JsonProperty("OrderLinePromotionRequest")
    public void setOrderLinePromotionRequest(List<Object> orderLinePromotionRequest) {
        this.orderLinePromotionRequest = orderLinePromotionRequest;
    }

    @JsonProperty("AlternateOrderLineId")
    public Object getAlternateOrderLineId() {
        return alternateOrderLineId;
    }

    @JsonProperty("AlternateOrderLineId")
    public void setAlternateOrderLineId(Object alternateOrderLineId) {
        this.alternateOrderLineId = alternateOrderLineId;
    }

    @JsonProperty("OrderLinePromisingInfo")
    public Object getOrderLinePromisingInfo() {
        return orderLinePromisingInfo;
    }

    @JsonProperty("OrderLinePromisingInfo")
    public void setOrderLinePromisingInfo(Object orderLinePromisingInfo) {
        this.orderLinePromisingInfo = orderLinePromisingInfo;
    }

    @JsonProperty("DoNotShipBeforeDate")
    public Object getDoNotShipBeforeDate() {
        return doNotShipBeforeDate;
    }

    @JsonProperty("DoNotShipBeforeDate")
    public void setDoNotShipBeforeDate(Object doNotShipBeforeDate) {
        this.doNotShipBeforeDate = doNotShipBeforeDate;
    }

    @JsonProperty("OrderLineTaxDetail")
    public List<OrderLineTaxDetail> getOrderLineTaxDetail() {
        return orderLineTaxDetail;
    }

    @JsonProperty("OrderLineTaxDetail")
    public void setOrderLineTaxDetail(List<OrderLineTaxDetail> orderLineTaxDetail) {
        this.orderLineTaxDetail = orderLineTaxDetail;
    }

    @JsonProperty("IsItemTaxOverridable")
    public Boolean getIsItemTaxOverridable() {
        return isItemTaxOverridable;
    }

    @JsonProperty("IsItemTaxOverridable")
    public void setIsItemTaxOverridable(Boolean isItemTaxOverridable) {
        this.isItemTaxOverridable = isItemTaxOverridable;
    }

    @JsonProperty("OrderLineChargeDetail")
    public List<Object> getOrderLineChargeDetail() {
        return orderLineChargeDetail;
    }

    @JsonProperty("OrderLineChargeDetail")
    public void setOrderLineChargeDetail(List<Object> orderLineChargeDetail) {
        this.orderLineChargeDetail = orderLineChargeDetail;
    }

    @JsonProperty("ItemSeason")
    public Object getItemSeason() {
        return itemSeason;
    }

    @JsonProperty("ItemSeason")
    public void setItemSeason(Object itemSeason) {
        this.itemSeason = itemSeason;
    }

    @JsonProperty("OrderLineTotal")
    public Double getOrderLineTotal() {
        return orderLineTotal;
    }

    @JsonProperty("OrderLineTotal")
    public void setOrderLineTotal(Double orderLineTotal) {
        this.orderLineTotal = orderLineTotal;
    }

    @JsonProperty("ItemDescription")
    public String getItemDescription() {
        return itemDescription;
    }

    @JsonProperty("ItemDescription")
    public void setItemDescription(String itemDescription) {
        this.itemDescription = itemDescription;
    }

    @JsonProperty("IsItemTaxExemptable")
    public Boolean getIsItemTaxExemptable() {
        return isItemTaxExemptable;
    }

    @JsonProperty("IsItemTaxExemptable")
    public void setIsItemTaxExemptable(Boolean isItemTaxExemptable) {
        this.isItemTaxExemptable = isItemTaxExemptable;
    }

    @JsonProperty("Allocation")
    public List<Allocation> getAllocation() {
        return allocation;
    }

    @JsonProperty("Allocation")
    public void setAllocation(List<Allocation> allocation) {
        this.allocation = allocation;
    }

    @JsonProperty("OrderLineVASInstructions")
    public List<Object> getOrderLineVASInstructions() {
        return orderLineVASInstructions;
    }

    @JsonProperty("OrderLineVASInstructions")
    public void setOrderLineVASInstructions(List<Object> orderLineVASInstructions) {
        this.orderLineVASInstructions = orderLineVASInstructions;
    }

    @JsonProperty("PipelineId")
    public String getPipelineId() {
        return pipelineId;
    }

    @JsonProperty("PipelineId")
    public void setPipelineId(String pipelineId) {
        this.pipelineId = pipelineId;
    }

    @JsonProperty("ItemSize")
    public String getItemSize() {
        return itemSize;
    }

    @JsonProperty("ItemSize")
    public void setItemSize(String itemSize) {
        this.itemSize = itemSize;
    }

    @JsonProperty("IsNonMerchandise")
    public Boolean getIsNonMerchandise() {
        return isNonMerchandise;
    }

    @JsonProperty("IsNonMerchandise")
    public void setIsNonMerchandise(Boolean isNonMerchandise) {
        this.isNonMerchandise = isNonMerchandise;
    }

    @JsonProperty("LineType")
    public Object getLineType() {
        return lineType;
    }

    @JsonProperty("LineType")
    public void setLineType(Object lineType) {
        this.lineType = lineType;
    }

    @JsonProperty("ShipToLocationId")
    public Object getShipToLocationId() {
        return shipToLocationId;
    }

    @JsonProperty("ShipToLocationId")
    public void setShipToLocationId(Object shipToLocationId) {
        this.shipToLocationId = shipToLocationId;
    }

    @JsonProperty("ShipFromAddressId")
    public Object getShipFromAddressId() {
        return shipFromAddressId;
    }

    @JsonProperty("ShipFromAddressId")
    public void setShipFromAddressId(Object shipFromAddressId) {
        this.shipFromAddressId = shipFromAddressId;
    }

    @JsonProperty("IsActivationRequired")
    public Boolean getIsActivationRequired() {
        return isActivationRequired;
    }

    @JsonProperty("IsActivationRequired")
    public void setIsActivationRequired(Boolean isActivationRequired) {
        this.isActivationRequired = isActivationRequired;
    }

    @JsonProperty("Quantity")
    public Integer getQuantity() {
        return quantity;
    }

    @JsonProperty("Quantity")
    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    @JsonProperty("IsItemNotOnFile")
    public Boolean getIsItemNotOnFile() {
        return isItemNotOnFile;
    }

    @JsonProperty("IsItemNotOnFile")
    public void setIsItemNotOnFile(Boolean isItemNotOnFile) {
        this.isItemNotOnFile = isItemNotOnFile;
    }

    @JsonProperty("IsPackAndHold")
    public Boolean getIsPackAndHold() {
        return isPackAndHold;
    }

    @JsonProperty("IsPackAndHold")
    public void setIsPackAndHold(Boolean isPackAndHold) {
        this.isPackAndHold = isPackAndHold;
    }

    @JsonProperty("IsGiftCard")
    public Boolean getIsGiftCard() {
        return isGiftCard;
    }

    @JsonProperty("IsGiftCard")
    public void setIsGiftCard(Boolean isGiftCard) {
        this.isGiftCard = isGiftCard;
    }

    @JsonProperty("CancelComments")
    public Object getCancelComments() {
        return cancelComments;
    }

    @JsonProperty("CancelComments")
    public void setCancelComments(Object cancelComments) {
        this.cancelComments = cancelComments;
    }

    @JsonProperty("MaxFulfillmentStatus")
    public MaxFulfillmentStatus getMaxFulfillmentStatus() {
        return maxFulfillmentStatus;
    }

    @JsonProperty("MaxFulfillmentStatus")
    public void setMaxFulfillmentStatus(MaxFulfillmentStatus maxFulfillmentStatus) {
        this.maxFulfillmentStatus = maxFulfillmentStatus;
    }

    @JsonProperty("VolumetricWeightUOM")
    public Object getVolumetricWeightUOM() {
        return volumetricWeightUOM;
    }

    @JsonProperty("VolumetricWeightUOM")
    public void setVolumetricWeightUOM(Object volumetricWeightUOM) {
        this.volumetricWeightUOM = volumetricWeightUOM;
    }

    @JsonProperty("OrderLineExtension1")
    public Object getOrderLineExtension1() {
        return orderLineExtension1;
    }

    @JsonProperty("OrderLineExtension1")
    public void setOrderLineExtension1(Object orderLineExtension1) {
        this.orderLineExtension1 = orderLineExtension1;
    }

    @JsonProperty("FulfillmentDetail")
    public List<FulfillmentDetail> getFulfillmentDetail() {
        return fulfillmentDetail;
    }

    @JsonProperty("FulfillmentDetail")
    public void setFulfillmentDetail(List<FulfillmentDetail> fulfillmentDetail) {
        this.fulfillmentDetail = fulfillmentDetail;
    }

    @JsonProperty("OrderLineExtension2")
    public List<Object> getOrderLineExtension2() {
        return orderLineExtension2;
    }

    @JsonProperty("OrderLineExtension2")
    public void setOrderLineExtension2(List<Object> orderLineExtension2) {
        this.orderLineExtension2 = orderLineExtension2;
    }

    @JsonProperty("UOM")
    public String getUOM() {
        return uOM;
    }

    @JsonProperty("UOM")
    public void setUOM(String uOM) {
        this.uOM = uOM;
    }

    @JsonProperty("OrderLineId")
    public String getOrderLineId() {
        return orderLineId;
    }

    @JsonProperty("OrderLineId")
    public void setOrderLineId(String orderLineId) {
        this.orderLineId = orderLineId;
    }

    @JsonProperty("TotalTaxes")
    public Double getTotalTaxes() {
        return totalTaxes;
    }

    @JsonProperty("TotalTaxes")
    public void setTotalTaxes(Double totalTaxes) {
        this.totalTaxes = totalTaxes;
    }

    @JsonProperty("OrderLineAdditional")
    public Object getOrderLineAdditional() {
        return orderLineAdditional;
    }

    @JsonProperty("OrderLineAdditional")
    public void setOrderLineAdditional(Object orderLineAdditional) {
        this.orderLineAdditional = orderLineAdditional;
    }

    @JsonProperty("TransactionReferenceId")
    public Object getTransactionReferenceId() {
        return transactionReferenceId;
    }

    @JsonProperty("TransactionReferenceId")
    public void setTransactionReferenceId(Object transactionReferenceId) {
        this.transactionReferenceId = transactionReferenceId;
    }

    @JsonProperty("RequestedDeliveryDate")
    public Object getRequestedDeliveryDate() {
        return requestedDeliveryDate;
    }

    @JsonProperty("RequestedDeliveryDate")
    public void setRequestedDeliveryDate(Object requestedDeliveryDate) {
        this.requestedDeliveryDate = requestedDeliveryDate;
    }

    @JsonProperty("PK")
    public String getPK() {
        return pK;
    }

    @JsonProperty("PK")
    public void setPK(String pK) {
        this.pK = pK;
    }

    @JsonProperty("OriginalUnitPrice")
    public Object getOriginalUnitPrice() {
        return originalUnitPrice;
    }

    @JsonProperty("OriginalUnitPrice")
    public void setOriginalUnitPrice(Object originalUnitPrice) {
        this.originalUnitPrice = originalUnitPrice;
    }

    @JsonProperty("IsEvenExchange")
    public Boolean getIsEvenExchange() {
        return isEvenExchange;
    }

    @JsonProperty("IsEvenExchange")
    public void setIsEvenExchange(Boolean isEvenExchange) {
        this.isEvenExchange = isEvenExchange;
    }

    @JsonProperty("LineProcessInfo")
    public Object getLineProcessInfo() {
        return lineProcessInfo;
    }

    @JsonProperty("LineProcessInfo")
    public void setLineProcessInfo(Object lineProcessInfo) {
        this.lineProcessInfo = lineProcessInfo;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
