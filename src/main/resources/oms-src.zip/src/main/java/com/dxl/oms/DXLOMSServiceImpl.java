package com.dxl.oms;

import java.util.List;

import com.dxl.bean.DXLOrderHistoryItemDetail;
import com.dxl.bean.storeLocator.InventoryData;
import com.dxl.order.DXLOMSService;
import com.dxl.order.data.OrderData;

import atg.nucleus.GenericService;

/**
 *
 * @author TAISTech
 */
public class DXLOMSServiceImpl extends GenericService implements DXLOMSService {
	private OMSManager omsManager;

	@Override
	public OrderData lookupOrder(String orderNumber, String email) {
		OrderData orderData = getOmsManager().lookupOrder(orderNumber, email);
		return orderData;
	}

	@Override
	public List<DXLOrderHistoryItemDetail> retrieveOrders(String pEmail) {
		List<DXLOrderHistoryItemDetail> ordersList = getOmsManager().retrieveOrders(pEmail);
		return ordersList;
	}
	
	@Override
	public List<InventoryData> getInventoryAvailabilityForLocation(List<String> edpNo, List<String> stores) {
		List<InventoryData> inventoryData = getOmsManager().getInventoryAvailabilityForLocation(edpNo, stores);
		return inventoryData;
	}

	public OMSManager getOmsManager() {
		return omsManager;
	}

	public void setOmsManager(OMSManager omsManager) {
		this.omsManager = omsManager;
	}

	@Override
	public List<InventoryData> getInventoryAvailabilityForNetwork(List<String> itemIds, String viewName) {
		List<InventoryData> inventoryData = getOmsManager().getInventoryAvailabilityForNetwork(itemIds, viewName);
		return inventoryData;
	}
}