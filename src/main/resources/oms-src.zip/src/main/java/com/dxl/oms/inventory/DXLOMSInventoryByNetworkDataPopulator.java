package com.dxl.oms.inventory;

import java.util.ArrayList;
import java.util.List;

import com.dxl.bean.storeLocator.InventoryData;
import com.dxl.oms.bean.inventory.network.Datum;
import com.dxl.oms.bean.inventory.network.InventoryResponseForNetwork;

import atg.nucleus.GenericService;

public class DXLOMSInventoryByNetworkDataPopulator extends GenericService {
	
	public List<InventoryData> populateData(InventoryResponseForNetwork invResponse){
		List<InventoryData> inventoryDataList = new ArrayList<InventoryData>();
		if(invResponse!=null){
			List<Datum> data = invResponse.getData();
			for (Datum datum : data) {
				InventoryData inventoryData = new InventoryData();
				inventoryData.setItemId(datum.getItemId());
				inventoryData.setStatus(datum.getStatus());
				inventoryData.setQuantity(datum.getTotalQuantity());
				inventoryDataList.add(inventoryData);
			}
		}else{
			vlogError("InventoryForLocation is null : {0}",invResponse);
		}
		return inventoryDataList;
	}
}
