
package com.dxl.oms.bean.orderhistory;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "Messages",
    "FulfillmentStatus",
    "CreatedTimestamp",
    "CustomerId",
    "OrderId",
    "OrderTotal",
    "IsConfirmed"
})
public class Datum {

    @JsonProperty("Messages")
    private Object messages;
    @JsonProperty("FulfillmentStatus")
    private String fulfillmentStatus;
    @JsonProperty("CreatedTimestamp")
    private String createdTimestamp;
    @JsonProperty("CustomerId")
    private String customerId;
    @JsonProperty("OrderId")
    private String orderId;
    @JsonProperty("OrderTotal")
    private Double orderTotal;
    @JsonProperty("IsConfirmed")
    private Boolean isConfirmed;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("Messages")
    public Object getMessages() {
        return messages;
    }

    @JsonProperty("Messages")
    public void setMessages(Object messages) {
        this.messages = messages;
    }

    @JsonProperty("FulfillmentStatus")
    public String getFulfillmentStatus() {
        return fulfillmentStatus;
    }

    @JsonProperty("FulfillmentStatus")
    public void setFulfillmentStatus(String fulfillmentStatus) {
        this.fulfillmentStatus = fulfillmentStatus;
    }

    @JsonProperty("CreatedTimestamp")
    public String getCreatedTimestamp() {
        return createdTimestamp;
    }

    @JsonProperty("CreatedTimestamp")
    public void setCreatedTimestamp(String createdTimestamp) {
        this.createdTimestamp = createdTimestamp;
    }

    @JsonProperty("CustomerId")
    public String getCustomerId() {
        return customerId;
    }

    @JsonProperty("CustomerId")
    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    @JsonProperty("OrderId")
    public String getOrderId() {
        return orderId;
    }

    @JsonProperty("OrderId")
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    @JsonProperty("OrderTotal")
    public Double getOrderTotal() {
        return orderTotal;
    }

    @JsonProperty("OrderTotal")
    public void setOrderTotal(Double orderTotal) {
        this.orderTotal = orderTotal;
    }

    @JsonProperty("IsConfirmed")
    public Boolean getIsConfirmed() {
        return isConfirmed;
    }

    @JsonProperty("IsConfirmed")
    public void setIsConfirmed(Boolean isConfirmed) {
        this.isConfirmed = isConfirmed;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
