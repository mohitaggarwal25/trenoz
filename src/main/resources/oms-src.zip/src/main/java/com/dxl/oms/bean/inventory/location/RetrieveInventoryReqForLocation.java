package com.dxl.oms.bean.inventory.location;

import com.dxl.oms.bean.inventory.location.InventoryReqForLocation;

public class RetrieveInventoryReqForLocation {
	
	private InventoryReqForLocation request;

	/**
	 * @return the request
	 */
	public InventoryReqForLocation getRequest() {
		return request;
	}

	/**
	 * @param request the request to set
	 */
	public void setRequest(InventoryReqForLocation request) {
		this.request = request;
	}

}
