
package com.dxl.oms.bean.ordersearch;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "CancelledQuantity",
    "UpdatedTimestamp",
    "EffectiveRank",
    "CreatedBy",
    "CreatedTimestamp",
    "FulfilledQuantity",
    "AllocationId",
    "Quantity",
    "Process",
    "ItemId",
    "ReleaseLineId",
    "OrgId",
    "UpdatedBy",
    "UOM",
    "OrderLineId",
    "ContextId",
    "PK",
    "CancelledDate"
})
public class ReleaseLine {

    @JsonProperty("CancelledQuantity")
    private Integer cancelledQuantity;
    @JsonProperty("UpdatedTimestamp")
    private String updatedTimestamp;
    @JsonProperty("EffectiveRank")
    private String effectiveRank;
    @JsonProperty("CreatedBy")
    private String createdBy;
    @JsonProperty("CreatedTimestamp")
    private String createdTimestamp;
    @JsonProperty("FulfilledQuantity")
    private Integer fulfilledQuantity;
    @JsonProperty("AllocationId")
    private String allocationId;
    @JsonProperty("Quantity")
    private Integer quantity;
    @JsonProperty("Process")
    private Object process;
    @JsonProperty("ItemId")
    private String itemId;
    @JsonProperty("ReleaseLineId")
    private String releaseLineId;
    @JsonProperty("OrgId")
    private String orgId;
    @JsonProperty("UpdatedBy")
    private String updatedBy;
    @JsonProperty("UOM")
    private String uOM;
    @JsonProperty("OrderLineId")
    private String orderLineId;
    @JsonProperty("ContextId")
    private String contextId;
    @JsonProperty("PK")
    private String pK;
    @JsonProperty("CancelledDate")
    private Object cancelledDate;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("CancelledQuantity")
    public Integer getCancelledQuantity() {
        return cancelledQuantity;
    }

    @JsonProperty("CancelledQuantity")
    public void setCancelledQuantity(Integer cancelledQuantity) {
        this.cancelledQuantity = cancelledQuantity;
    }

    @JsonProperty("UpdatedTimestamp")
    public String getUpdatedTimestamp() {
        return updatedTimestamp;
    }

    @JsonProperty("UpdatedTimestamp")
    public void setUpdatedTimestamp(String updatedTimestamp) {
        this.updatedTimestamp = updatedTimestamp;
    }

    @JsonProperty("EffectiveRank")
    public String getEffectiveRank() {
        return effectiveRank;
    }

    @JsonProperty("EffectiveRank")
    public void setEffectiveRank(String effectiveRank) {
        this.effectiveRank = effectiveRank;
    }

    @JsonProperty("CreatedBy")
    public String getCreatedBy() {
        return createdBy;
    }

    @JsonProperty("CreatedBy")
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    @JsonProperty("CreatedTimestamp")
    public String getCreatedTimestamp() {
        return createdTimestamp;
    }

    @JsonProperty("CreatedTimestamp")
    public void setCreatedTimestamp(String createdTimestamp) {
        this.createdTimestamp = createdTimestamp;
    }

    @JsonProperty("FulfilledQuantity")
    public Integer getFulfilledQuantity() {
        return fulfilledQuantity;
    }

    @JsonProperty("FulfilledQuantity")
    public void setFulfilledQuantity(Integer fulfilledQuantity) {
        this.fulfilledQuantity = fulfilledQuantity;
    }

    @JsonProperty("AllocationId")
    public String getAllocationId() {
        return allocationId;
    }

    @JsonProperty("AllocationId")
    public void setAllocationId(String allocationId) {
        this.allocationId = allocationId;
    }

    @JsonProperty("Quantity")
    public Integer getQuantity() {
        return quantity;
    }

    @JsonProperty("Quantity")
    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    @JsonProperty("Process")
    public Object getProcess() {
        return process;
    }

    @JsonProperty("Process")
    public void setProcess(Object process) {
        this.process = process;
    }

    @JsonProperty("ItemId")
    public String getItemId() {
        return itemId;
    }

    @JsonProperty("ItemId")
    public void setItemId(String itemId) {
        this.itemId = itemId;
    }

    @JsonProperty("ReleaseLineId")
    public String getReleaseLineId() {
        return releaseLineId;
    }

    @JsonProperty("ReleaseLineId")
    public void setReleaseLineId(String releaseLineId) {
        this.releaseLineId = releaseLineId;
    }

    @JsonProperty("OrgId")
    public String getOrgId() {
        return orgId;
    }

    @JsonProperty("OrgId")
    public void setOrgId(String orgId) {
        this.orgId = orgId;
    }

    @JsonProperty("UpdatedBy")
    public String getUpdatedBy() {
        return updatedBy;
    }

    @JsonProperty("UpdatedBy")
    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    @JsonProperty("UOM")
    public String getUOM() {
        return uOM;
    }

    @JsonProperty("UOM")
    public void setUOM(String uOM) {
        this.uOM = uOM;
    }

    @JsonProperty("OrderLineId")
    public String getOrderLineId() {
        return orderLineId;
    }

    @JsonProperty("OrderLineId")
    public void setOrderLineId(String orderLineId) {
        this.orderLineId = orderLineId;
    }

    @JsonProperty("ContextId")
    public String getContextId() {
        return contextId;
    }

    @JsonProperty("ContextId")
    public void setContextId(String contextId) {
        this.contextId = contextId;
    }

    @JsonProperty("PK")
    public String getPK() {
        return pK;
    }

    @JsonProperty("PK")
    public void setPK(String pK) {
        this.pK = pK;
    }

    @JsonProperty("CancelledDate")
    public Object getCancelledDate() {
        return cancelledDate;
    }

    @JsonProperty("CancelledDate")
    public void setCancelledDate(Object cancelledDate) {
        this.cancelledDate = cancelledDate;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
