package com.dxl.oms;

import com.dxl.oms.connection.OMSWorkerInfo;

import atg.nucleus.GenericService;

/**
 * Worker thread used to handle the thread request to the OMS Gateway Service.
 *
 * @author TAISTech
 */
public class DXLCatalogFeedSQSWorker extends GenericService implements Runnable {
	private String queueName;
	private String jsonMsg;
	private OMSWorkerInfo omsWorkerInfo;

	/**
	 * constructor
	 *
	 * @param omsResponse
	 *
	 */
	public DXLCatalogFeedSQSWorker(String queueName, String jsonMsg, OMSWorkerInfo omsWorkerInfo) {
		this.queueName = queueName;
		this.jsonMsg = jsonMsg;
		this.omsWorkerInfo = omsWorkerInfo;
	}

	/**
	 * sends the Order Search Request to the OMS Service.
	 */
	public void run() {

		if (isLoggingDebug()) {
			logDebug("CatalogFeed Worker Starts");
		}
		if (isLoggingDebug()) {
			vlogDebug("sendMessageToSQS :: jsonMsg= {0}", jsonMsg);
		}
		try {
			omsWorkerInfo.getSqsClient().sendMessageToQueue(queueName, jsonMsg);
			if (isLoggingDebug()) {
				logDebug("Message sent for the jsonMsg");
			}
		} catch (Exception e) {
			if (isLoggingError()) {
				logError("Exception occured while sending message to SQS client: " + e);
			}
		}
		if (isLoggingDebug()) {
			logDebug("Worker communication completed");
		}
	}

	public OMSWorkerInfo getOmsWorkerInfo() {
		return omsWorkerInfo;
	}

	public void setOmsWorkerInfo(OMSWorkerInfo omsWorkerInfo) {
		this.omsWorkerInfo = omsWorkerInfo;
	}

}
