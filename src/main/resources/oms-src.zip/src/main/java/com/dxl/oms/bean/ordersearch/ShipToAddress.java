
package com.dxl.oms.bean.ordersearch;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "AddressName",
    "AvsReason",
    "Address",
    "IsAddressVerified",
    "AddressId"
})
public class ShipToAddress {

    @JsonProperty("AddressName")
    private Object addressName;
    @JsonProperty("AvsReason")
    private Object avsReason;
    @JsonProperty("Address")
    private Address address;
    @JsonProperty("IsAddressVerified")
    private Boolean isAddressVerified;
    @JsonProperty("AddressId")
    private String addressId;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("AddressName")
    public Object getAddressName() {
        return addressName;
    }

    @JsonProperty("AddressName")
    public void setAddressName(Object addressName) {
        this.addressName = addressName;
    }

    @JsonProperty("AvsReason")
    public Object getAvsReason() {
        return avsReason;
    }

    @JsonProperty("AvsReason")
    public void setAvsReason(Object avsReason) {
        this.avsReason = avsReason;
    }

    @JsonProperty("Address")
    public Address getAddress() {
        return address;
    }

    @JsonProperty("Address")
    public void setAddress(Address address) {
        this.address = address;
    }

    @JsonProperty("IsAddressVerified")
    public Boolean getIsAddressVerified() {
        return isAddressVerified;
    }

    @JsonProperty("IsAddressVerified")
    public void setIsAddressVerified(Boolean isAddressVerified) {
        this.isAddressVerified = isAddressVerified;
    }

    @JsonProperty("AddressId")
    public String getAddressId() {
        return addressId;
    }

    @JsonProperty("AddressId")
    public void setAddressId(String addressId) {
        this.addressId = addressId;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
