
package com.dxl.oms.bean.ordersearch;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "Actions",
    "PK",
    "CreatedBy",
    "CreatedTimestamp",
    "UpdatedBy",
    "UpdatedTimestamp",
    "Translations",
    "Messages",
    "OrgId",
    "PaymentTransactionId",
    "RequestedAmount",
    "RequestId",
    "RequestToken",
    "RequestedDate",
    "FollowOnId",
    "FollowOnToken",
    "TransactionDate",
    "TransactionExpiryDate",
    "ProcessedAmount",
    "FollowOnProcessedAmount",
    "RemainingAttempts",
    "FollowOnCount",
    "ReconciliationId",
    "ExternalResponseId",
    "ReasonId",
    "IsValidForRefund",
    "ReAuthOnSettlementFailure",
    "IsActive",
    "RemainingBalance",
    "IsCopied",
    "ScheduledTimestamp",
    "OrderId",
    "PaymentGroupId",
    "StoreAndForwardNumber",
    "IsActivation",
    "PaymentTransAttribute",
    "PaymentTransEncrAttribute",
    "PaymentTransactionDetail",
    "PaymentTransactionEMVTags",
    "TransactionType",
    "Status",
    "ProcessingMode",
    "PaymentResponseStatus",
    "TransmissionStatus",
    "InteractionMode",
    "Extended"
})
public class PaymentTransaction {

    @JsonProperty("Actions")
    private Actions___ actions;
    @JsonProperty("PK")
    private String pK;
    @JsonProperty("CreatedBy")
    private String createdBy;
    @JsonProperty("CreatedTimestamp")
    private String createdTimestamp;
    @JsonProperty("UpdatedBy")
    private String updatedBy;
    @JsonProperty("UpdatedTimestamp")
    private String updatedTimestamp;
    @JsonProperty("Translations")
    private Object translations;
    @JsonProperty("Messages")
    private Object messages;
    @JsonProperty("OrgId")
    private String orgId;
    @JsonProperty("PaymentTransactionId")
    private String paymentTransactionId;
    @JsonProperty("RequestedAmount")
    private Double requestedAmount;
    @JsonProperty("RequestId")
    private Object requestId;
    @JsonProperty("RequestToken")
    private Object requestToken;
    @JsonProperty("RequestedDate")
    private Object requestedDate;
    @JsonProperty("FollowOnId")
    private String followOnId;
    @JsonProperty("FollowOnToken")
    private String followOnToken;
    @JsonProperty("TransactionDate")
    private Object transactionDate;
    @JsonProperty("TransactionExpiryDate")
    private Object transactionExpiryDate;
    @JsonProperty("ProcessedAmount")
    private Object processedAmount;
    @JsonProperty("FollowOnProcessedAmount")
    private Object followOnProcessedAmount;
    @JsonProperty("RemainingAttempts")
    private Integer remainingAttempts;
    @JsonProperty("FollowOnCount")
    private Object followOnCount;
    @JsonProperty("ReconciliationId")
    private Object reconciliationId;
    @JsonProperty("ExternalResponseId")
    private Object externalResponseId;
    @JsonProperty("ReasonId")
    private Object reasonId;
    @JsonProperty("IsValidForRefund")
    private Boolean isValidForRefund;
    @JsonProperty("ReAuthOnSettlementFailure")
    private Boolean reAuthOnSettlementFailure;
    @JsonProperty("IsActive")
    private Boolean isActive;
    @JsonProperty("RemainingBalance")
    private Object remainingBalance;
    @JsonProperty("IsCopied")
    private Boolean isCopied;
    @JsonProperty("ScheduledTimestamp")
    private Object scheduledTimestamp;
    @JsonProperty("OrderId")
    private String orderId;
    @JsonProperty("PaymentGroupId")
    private Object paymentGroupId;
    @JsonProperty("StoreAndForwardNumber")
    private Object storeAndForwardNumber;
    @JsonProperty("IsActivation")
    private Boolean isActivation;
    @JsonProperty("PaymentTransAttribute")
    private List<Object> paymentTransAttribute = null;
    @JsonProperty("PaymentTransEncrAttribute")
    private List<Object> paymentTransEncrAttribute = null;
    @JsonProperty("PaymentTransactionDetail")
    private List<Object> paymentTransactionDetail = null;
    @JsonProperty("PaymentTransactionEMVTags")
    private Object paymentTransactionEMVTags;
    @JsonProperty("TransactionType")
    private TransactionType transactionType;
    @JsonProperty("Status")
    private Status_ status;
    @JsonProperty("ProcessingMode")
    private ProcessingMode processingMode;
    @JsonProperty("PaymentResponseStatus")
    private Object paymentResponseStatus;
    @JsonProperty("TransmissionStatus")
    private Object transmissionStatus;
    @JsonProperty("InteractionMode")
    private Object interactionMode;
    @JsonProperty("Extended")
    private Extended_ extended;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("Actions")
    public Actions___ getActions() {
        return actions;
    }

    @JsonProperty("Actions")
    public void setActions(Actions___ actions) {
        this.actions = actions;
    }

    @JsonProperty("PK")
    public String getPK() {
        return pK;
    }

    @JsonProperty("PK")
    public void setPK(String pK) {
        this.pK = pK;
    }

    @JsonProperty("CreatedBy")
    public String getCreatedBy() {
        return createdBy;
    }

    @JsonProperty("CreatedBy")
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    @JsonProperty("CreatedTimestamp")
    public String getCreatedTimestamp() {
        return createdTimestamp;
    }

    @JsonProperty("CreatedTimestamp")
    public void setCreatedTimestamp(String createdTimestamp) {
        this.createdTimestamp = createdTimestamp;
    }

    @JsonProperty("UpdatedBy")
    public String getUpdatedBy() {
        return updatedBy;
    }

    @JsonProperty("UpdatedBy")
    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    @JsonProperty("UpdatedTimestamp")
    public String getUpdatedTimestamp() {
        return updatedTimestamp;
    }

    @JsonProperty("UpdatedTimestamp")
    public void setUpdatedTimestamp(String updatedTimestamp) {
        this.updatedTimestamp = updatedTimestamp;
    }

    @JsonProperty("Translations")
    public Object getTranslations() {
        return translations;
    }

    @JsonProperty("Translations")
    public void setTranslations(Object translations) {
        this.translations = translations;
    }

    @JsonProperty("Messages")
    public Object getMessages() {
        return messages;
    }

    @JsonProperty("Messages")
    public void setMessages(Object messages) {
        this.messages = messages;
    }

    @JsonProperty("OrgId")
    public String getOrgId() {
        return orgId;
    }

    @JsonProperty("OrgId")
    public void setOrgId(String orgId) {
        this.orgId = orgId;
    }

    @JsonProperty("PaymentTransactionId")
    public String getPaymentTransactionId() {
        return paymentTransactionId;
    }

    @JsonProperty("PaymentTransactionId")
    public void setPaymentTransactionId(String paymentTransactionId) {
        this.paymentTransactionId = paymentTransactionId;
    }

    @JsonProperty("RequestedAmount")
    public Double getRequestedAmount() {
        return requestedAmount;
    }

    @JsonProperty("RequestedAmount")
    public void setRequestedAmount(Double requestedAmount) {
        this.requestedAmount = requestedAmount;
    }

    @JsonProperty("RequestId")
    public Object getRequestId() {
        return requestId;
    }

    @JsonProperty("RequestId")
    public void setRequestId(Object requestId) {
        this.requestId = requestId;
    }

    @JsonProperty("RequestToken")
    public Object getRequestToken() {
        return requestToken;
    }

    @JsonProperty("RequestToken")
    public void setRequestToken(Object requestToken) {
        this.requestToken = requestToken;
    }

    @JsonProperty("RequestedDate")
    public Object getRequestedDate() {
        return requestedDate;
    }

    @JsonProperty("RequestedDate")
    public void setRequestedDate(Object requestedDate) {
        this.requestedDate = requestedDate;
    }

    @JsonProperty("FollowOnId")
    public String getFollowOnId() {
        return followOnId;
    }

    @JsonProperty("FollowOnId")
    public void setFollowOnId(String followOnId) {
        this.followOnId = followOnId;
    }

    @JsonProperty("FollowOnToken")
    public String getFollowOnToken() {
        return followOnToken;
    }

    @JsonProperty("FollowOnToken")
    public void setFollowOnToken(String followOnToken) {
        this.followOnToken = followOnToken;
    }

    @JsonProperty("TransactionDate")
    public Object getTransactionDate() {
        return transactionDate;
    }

    @JsonProperty("TransactionDate")
    public void setTransactionDate(Object transactionDate) {
        this.transactionDate = transactionDate;
    }

    @JsonProperty("TransactionExpiryDate")
    public Object getTransactionExpiryDate() {
        return transactionExpiryDate;
    }

    @JsonProperty("TransactionExpiryDate")
    public void setTransactionExpiryDate(Object transactionExpiryDate) {
        this.transactionExpiryDate = transactionExpiryDate;
    }

    @JsonProperty("ProcessedAmount")
    public Object getProcessedAmount() {
        return processedAmount;
    }

    @JsonProperty("ProcessedAmount")
    public void setProcessedAmount(Object processedAmount) {
        this.processedAmount = processedAmount;
    }

    @JsonProperty("FollowOnProcessedAmount")
    public Object getFollowOnProcessedAmount() {
        return followOnProcessedAmount;
    }

    @JsonProperty("FollowOnProcessedAmount")
    public void setFollowOnProcessedAmount(Object followOnProcessedAmount) {
        this.followOnProcessedAmount = followOnProcessedAmount;
    }

    @JsonProperty("RemainingAttempts")
    public Integer getRemainingAttempts() {
        return remainingAttempts;
    }

    @JsonProperty("RemainingAttempts")
    public void setRemainingAttempts(Integer remainingAttempts) {
        this.remainingAttempts = remainingAttempts;
    }

    @JsonProperty("FollowOnCount")
    public Object getFollowOnCount() {
        return followOnCount;
    }

    @JsonProperty("FollowOnCount")
    public void setFollowOnCount(Object followOnCount) {
        this.followOnCount = followOnCount;
    }

    @JsonProperty("ReconciliationId")
    public Object getReconciliationId() {
        return reconciliationId;
    }

    @JsonProperty("ReconciliationId")
    public void setReconciliationId(Object reconciliationId) {
        this.reconciliationId = reconciliationId;
    }

    @JsonProperty("ExternalResponseId")
    public Object getExternalResponseId() {
        return externalResponseId;
    }

    @JsonProperty("ExternalResponseId")
    public void setExternalResponseId(Object externalResponseId) {
        this.externalResponseId = externalResponseId;
    }

    @JsonProperty("ReasonId")
    public Object getReasonId() {
        return reasonId;
    }

    @JsonProperty("ReasonId")
    public void setReasonId(Object reasonId) {
        this.reasonId = reasonId;
    }

    @JsonProperty("IsValidForRefund")
    public Boolean getIsValidForRefund() {
        return isValidForRefund;
    }

    @JsonProperty("IsValidForRefund")
    public void setIsValidForRefund(Boolean isValidForRefund) {
        this.isValidForRefund = isValidForRefund;
    }

    @JsonProperty("ReAuthOnSettlementFailure")
    public Boolean getReAuthOnSettlementFailure() {
        return reAuthOnSettlementFailure;
    }

    @JsonProperty("ReAuthOnSettlementFailure")
    public void setReAuthOnSettlementFailure(Boolean reAuthOnSettlementFailure) {
        this.reAuthOnSettlementFailure = reAuthOnSettlementFailure;
    }

    @JsonProperty("IsActive")
    public Boolean getIsActive() {
        return isActive;
    }

    @JsonProperty("IsActive")
    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }

    @JsonProperty("RemainingBalance")
    public Object getRemainingBalance() {
        return remainingBalance;
    }

    @JsonProperty("RemainingBalance")
    public void setRemainingBalance(Object remainingBalance) {
        this.remainingBalance = remainingBalance;
    }

    @JsonProperty("IsCopied")
    public Boolean getIsCopied() {
        return isCopied;
    }

    @JsonProperty("IsCopied")
    public void setIsCopied(Boolean isCopied) {
        this.isCopied = isCopied;
    }

    @JsonProperty("ScheduledTimestamp")
    public Object getScheduledTimestamp() {
        return scheduledTimestamp;
    }

    @JsonProperty("ScheduledTimestamp")
    public void setScheduledTimestamp(Object scheduledTimestamp) {
        this.scheduledTimestamp = scheduledTimestamp;
    }

    @JsonProperty("OrderId")
    public String getOrderId() {
        return orderId;
    }

    @JsonProperty("OrderId")
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    @JsonProperty("PaymentGroupId")
    public Object getPaymentGroupId() {
        return paymentGroupId;
    }

    @JsonProperty("PaymentGroupId")
    public void setPaymentGroupId(Object paymentGroupId) {
        this.paymentGroupId = paymentGroupId;
    }

    @JsonProperty("StoreAndForwardNumber")
    public Object getStoreAndForwardNumber() {
        return storeAndForwardNumber;
    }

    @JsonProperty("StoreAndForwardNumber")
    public void setStoreAndForwardNumber(Object storeAndForwardNumber) {
        this.storeAndForwardNumber = storeAndForwardNumber;
    }

    @JsonProperty("IsActivation")
    public Boolean getIsActivation() {
        return isActivation;
    }

    @JsonProperty("IsActivation")
    public void setIsActivation(Boolean isActivation) {
        this.isActivation = isActivation;
    }

    @JsonProperty("PaymentTransAttribute")
    public List<Object> getPaymentTransAttribute() {
        return paymentTransAttribute;
    }

    @JsonProperty("PaymentTransAttribute")
    public void setPaymentTransAttribute(List<Object> paymentTransAttribute) {
        this.paymentTransAttribute = paymentTransAttribute;
    }

    @JsonProperty("PaymentTransEncrAttribute")
    public List<Object> getPaymentTransEncrAttribute() {
        return paymentTransEncrAttribute;
    }

    @JsonProperty("PaymentTransEncrAttribute")
    public void setPaymentTransEncrAttribute(List<Object> paymentTransEncrAttribute) {
        this.paymentTransEncrAttribute = paymentTransEncrAttribute;
    }

    @JsonProperty("PaymentTransactionDetail")
    public List<Object> getPaymentTransactionDetail() {
        return paymentTransactionDetail;
    }

    @JsonProperty("PaymentTransactionDetail")
    public void setPaymentTransactionDetail(List<Object> paymentTransactionDetail) {
        this.paymentTransactionDetail = paymentTransactionDetail;
    }

    @JsonProperty("PaymentTransactionEMVTags")
    public Object getPaymentTransactionEMVTags() {
        return paymentTransactionEMVTags;
    }

    @JsonProperty("PaymentTransactionEMVTags")
    public void setPaymentTransactionEMVTags(Object paymentTransactionEMVTags) {
        this.paymentTransactionEMVTags = paymentTransactionEMVTags;
    }

    @JsonProperty("TransactionType")
    public TransactionType getTransactionType() {
        return transactionType;
    }

    @JsonProperty("TransactionType")
    public void setTransactionType(TransactionType transactionType) {
        this.transactionType = transactionType;
    }

    @JsonProperty("Status")
    public Status_ getStatus() {
        return status;
    }

    @JsonProperty("Status")
    public void setStatus(Status_ status) {
        this.status = status;
    }

    @JsonProperty("ProcessingMode")
    public ProcessingMode getProcessingMode() {
        return processingMode;
    }

    @JsonProperty("ProcessingMode")
    public void setProcessingMode(ProcessingMode processingMode) {
        this.processingMode = processingMode;
    }

    @JsonProperty("PaymentResponseStatus")
    public Object getPaymentResponseStatus() {
        return paymentResponseStatus;
    }

    @JsonProperty("PaymentResponseStatus")
    public void setPaymentResponseStatus(Object paymentResponseStatus) {
        this.paymentResponseStatus = paymentResponseStatus;
    }

    @JsonProperty("TransmissionStatus")
    public Object getTransmissionStatus() {
        return transmissionStatus;
    }

    @JsonProperty("TransmissionStatus")
    public void setTransmissionStatus(Object transmissionStatus) {
        this.transmissionStatus = transmissionStatus;
    }

    @JsonProperty("InteractionMode")
    public Object getInteractionMode() {
        return interactionMode;
    }

    @JsonProperty("InteractionMode")
    public void setInteractionMode(Object interactionMode) {
        this.interactionMode = interactionMode;
    }

    @JsonProperty("Extended")
    public Extended_ getExtended() {
        return extended;
    }

    @JsonProperty("Extended")
    public void setExtended(Extended_ extended) {
        this.extended = extended;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
