package com.dxl.order;

import atg.commerce.order.*;

import atg.nucleus.GenericService;

import atg.repository.RepositoryItem;

import atg.service.pipeline.PipelineProcessor;
import atg.service.pipeline.PipelineResult;

import com.dxl.utils.StringUtil;
import com.dxl.integrations.ecometry.EcometryXMLConstants;
import com.dxl.integrations.ecometry.xml.EcometryXMLResponse;
import com.dxl.oms.OMSManager;
import com.dxl.order.DXLOrder;
import com.dxl.order.OMSService;

import atg.servlet.DynamoHttpServletRequest;



import java.util.*;


/**
 * This Pipeline Processor is used to Submit an Order to Ecometry.
 *
 * @author TAISTech
 */
public class ProcSubmitOrderToOMS extends GenericService
    implements PipelineProcessor {
    private static final String ORDER = "order";
    private static final String PROFILE = "profile";
    private OMSService omsService;
    private OMSManager omsManager;
    //private OrderSubmissionService orderSubmissionService;

    //return codes
    private int[] mRetCodes = { 1 };

    public int runProcess(Object params, PipelineResult pipelineResult) throws Exception {
      if (isLoggingDebug()) {
          logDebug("\nIn ProcSubmitOrderToManhatten....");
      }

      HashMap map = (HashMap) params;
      RepositoryItem profile = (RepositoryItem) map.get(PipelineConstants.PROFILE);
      DXLOrder order = (DXLOrder) map.get(PipelineConstants.ORDER);
      DynamoHttpServletRequest request = (DynamoHttpServletRequest)map.get(PipelineConstants.REQUEST);
      String sessionId = request.getSession().getId();
      Locale locale = request.getLocale();

      if (isLoggingInfo()) {
        logInfo("In ProcSubmitOrderToManhatten RunProcess Order=" + order);
      }
      
      /*//need to check if this order already has been submitted/ it will have an Ecometry Order Number
      String orderNumber = order.getOrderNumber();
      if (isLoggingInfo()) {
          logInfo("In ProcSubmitToEcometry, Ecometry Order Number = " + orderNumber);
      }*/
      
      /*if(orderNumber != null && !orderNumber.trim().equals("")) {
        order.setStateDetail(EcometryXMLConstants.FAILED_ON_SUBMIT);
        getEcometryXMLBusinessDelegate().writeFailedOrder(order,"ATG order not submitted as it already contains an Ecometry order number, meaning it was previously submitted.", "Order not submitted.");
        ((HashMap) params).put("ORDER_NUMBER", order.getOrderNumber());
        ((HashMap) params).put("ORDER_PROFILE", profile);
        return 1;
      }*/

      // check gift certificate with ecometry to see validity
      //boolean mgrReview = getOmsService().verifyManagerReviewWithEcomerty(order);
      order.setManagerReview(false);

      if (isLoggingDebug()) {
        logDebug("Manager Review=" + false);
      }    // ATG order is successfully created
      
      String stateDetail = order.getStateDetail();
      /*if (StringUtil.isNotEmpty(stateDetail) && stateDetail.equalsIgnoreCase(EcometryXMLConstants.RESEND_TO_COMPASS)) {
    	  return 1;
      }*/

      // submit to manhatten by calling OMSManager class
      // no updation needs to be done here
      
      getOmsManager().submitOrder(order, profile, sessionId);
      
     /* EcometryXMLResponse response = (EcometryXMLResponse) getEcometryXMLBusinessDelegate().submitWebOrder(order, profile, sessionId);

      if (response.getStatus() == EcometryXMLConstants.FRONTEND_ERROR) {
        order.setStateDetail(EcometryXMLConstants.FAILED_ON_SUBMIT);
        getEcometryXMLBusinessDelegate().writeFailedOrder(order,response.getResponseXML(), response.getRequest());
        ((HashMap) params).put("ORDER_NUMBER", order.getOrderNumber());
        ((HashMap) params).put("ORDER_PROFILE", profile);
        return 1;
      }

  

      if ((response.getStatus() == EcometryXMLConstants.FRONTEND_TIMEOUT) ||
          (response.getStatus() == EcometryXMLConstants.BACKEND_TIMEOUT) ||
          (response.getStatus() == EcometryXMLConstants.OFFLINE) ||
          response.getIsEcometryError() ) {
        // check for manager review
        if (mgrReview) {
          order.setStateDetail(EcometryXMLConstants.RESEND_TO_ECOMETRY_REVIEW);
        } else {
          order.setStateDetail(EcometryXMLConstants.RESEND_TO_ECOMETRY_NORMAL);
        }

        if(response.getStatus() == EcometryXMLConstants.OFFLINE ||response.getStatus() == EcometryXMLConstants.SCHEDULED_MAINTENANCE || response.getIsEcometryError()) {
        	//OLD code has this condition but no action in it.
        }
        // status gets updated automatically
      }

      if (response.getStatus() == EcometryXMLConstants.FRONTEND_SUCCESS 
    		  || response.getStatus() == EcometryXMLConstants.BACKEND_SUCCESS) {
        getEcometryXMLBusinessDelegate().performPostSuccessTasks(order, response);
        // status gets updated automatically
      }

      if (isLoggingDebug()) {
        logDebug("After Update");
      }

      ((HashMap) params).put("ORDER_NUMBER", order.getOrderNumber());
      ((HashMap) params).put("ORDER_PROFILE", profile);

      //  try the no promo email 
      getEcometryXMLBusinessDelegate().sendNoPromoEmail(order);

      //return the status code
*/      return 1;
    }


    /**
     * returns the Return Codes that are available in this processor.
     *
     * @return int[]
     */
    public int[] getRetCodes() {
        return mRetCodes;
    }

	/**
	 * @return the omsService
	 */
	public OMSService getOmsService() {
		return omsService;
	}

	/**
	 * @param omsService the omsService to set
	 */
	public void setOmsService(OMSService omsService) {
		this.omsService = omsService;
	}


	/**
	 * @return the omsManager
	 */
	public OMSManager getOmsManager() {
		return omsManager;
	}


	/**
	 * @param omsManager the omsManager to set
	 */
	public void setOmsManager(OMSManager omsManager) {
		this.omsManager = omsManager;
	}
	
}
