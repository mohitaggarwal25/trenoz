package com.dxl.oms.bean.inventory.network;

public class RetrieveInventoryReqForNetwork {
	
	private InventoryReqForNetwork request;

	/**
	 * @return the request
	 */
	public InventoryReqForNetwork getRequest() {
		return request;
	}

	/**
	 * @param request the request to set
	 */
	public void setRequest(InventoryReqForNetwork request) {
		this.request = request;
	}

	
}
