
package com.dxl.oms.bean;

import com.dxl.oms.bean.ordersearch.OrderSearch;

public class OrderSearchResponse {
	private OrderSearch omsResponse;
	private boolean success = false;

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

	public OrderSearch getOmsResponse() {
		return omsResponse;
	}

	public void setOmsResponse(OrderSearch omsResponse) {
		this.omsResponse = omsResponse;
	}
}
