package com.dxl.oms;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.dxl.bean.DXLContactInfo;
import com.dxl.bean.DXLOrderHistoryItemDetail;
import com.dxl.bean.storeLocator.InventoryData;
import com.dxl.commerce.amazonpay.AmazonPayPayment;
import com.dxl.commerce.amazonpay.AmazonPayPaymentStatus;
import com.dxl.commerce.order.payment.DXLPayPalPayment;
import com.dxl.commerce.order.payment.DXLPayPalPaymentStatus;
import com.dxl.common.GeneralRepositoryTools;
import com.dxl.common.GlobalApplicationConfiguration;
import com.dxl.oms.bean.OMSAuthTokenResponseBean;
import com.dxl.oms.bean.OrderSearchResponse;
import com.dxl.oms.bean.RetrieveOrdersRequest;
import com.dxl.oms.bean.RetrieveOrdersResponse;
import com.dxl.oms.bean.inventory.location.InventoryForLocation;
import com.dxl.oms.bean.inventory.location.InventoryReqForLocation;
import com.dxl.oms.bean.inventory.location.RetrieveInventoryReqForLocation;
import com.dxl.oms.bean.inventory.location.RetrieveInventoryResponseForLocation;
import com.dxl.oms.bean.inventory.network.InventoryReqForNetwork;
import com.dxl.oms.bean.inventory.network.InventoryResponseForNetwork;
import com.dxl.oms.bean.inventory.network.RetrieveInventoryReqForNetwork;
import com.dxl.oms.bean.inventory.network.RetrieveInventoryResponseForNetwork;
import com.dxl.oms.bean.orderhistory.OrderHistoryRequest;
import com.dxl.oms.bean.orderhistory.Template;
import com.dxl.oms.connection.OMSWorkerInfo;
import com.dxl.oms.inventory.DXLOMSInventoryByLocationDataPopulator;
import com.dxl.oms.inventory.DXLOMSInventoryByLocationWorker;
import com.dxl.oms.inventory.DXLOMSInventoryByNetworkDataPopulator;
import com.dxl.oms.inventory.DXLOMSInventoryByNetworkWorker;
import com.dxl.order.DXLCommerceItem;
import com.dxl.order.DXLCustomizationCommerceItemImpl;
import com.dxl.order.DXLElectronicShippingGroup;
import com.dxl.order.DXLHardgoodShippingGroup;
import com.dxl.order.DXLInStorePickupShippingGroup;
import com.dxl.order.DXLOrder;
import com.dxl.order.DXLOrderManager;
import com.dxl.order.DXLOrderTools;
import com.dxl.order.OMSOrderDataPopulator;
import com.dxl.order.data.OrderData;
import com.dxl.order.payment.CashPayment;
import com.dxl.order.payment.DXLCreditCard;
import com.dxl.order.payment.DXLCreditCardStatus;
import com.dxl.order.payment.DXLGiftCard;
import com.dxl.utils.DateUtil;
import com.dxl.utils.StringUtil;

import atg.commerce.CommerceException;
import atg.commerce.claimable.ClaimableException;
import atg.commerce.claimable.ClaimableTools;
import atg.commerce.order.PaymentGroup;
import atg.commerce.order.Relationship;
import atg.commerce.order.ShippingGroup;
import atg.commerce.order.ShippingGroupCommerceItemRelationship;
import atg.commerce.pricing.ItemPriceInfo;
import atg.commerce.pricing.PricingAdjustment;
import atg.nucleus.GenericService;
import atg.payment.creditcard.CreditCardTools;
import atg.repository.RepositoryItem;

/**
 *
 * @author TAISTech
 */
public class OMSManager extends GenericService {
	public DXLSQSClient submitToSQSClient;
	public String queueName;
	public GlobalApplicationConfiguration globalAppConfig;
	private Map<String, String> merchantIdMap;
	private GeneralRepositoryTools generalRepositoryTools;
	private CreditCardTools creditCardTools;
	private DXLOrderTools orderTools;
	private DXLOrderManager orderManager;
	private DXLOrder orderObject;
	private ClaimableTools claimableTools;
	private OMSAuthTokenResponseBean omsAuthTokenBean;
	private DXLOMSAccessTokenGenerator omsAccessTokenGenerator;
	private OMSOrderDataPopulator orderDataPopulator;
    private long omsTimeout;
    private Integer orderHistorySize;
	private OMSWorkerInfo omsWorkerInfo;
	private DXLOMSInventoryByLocationDataPopulator inventoryByLocationDataPopulator;
	private DXLOMSInventoryByNetworkDataPopulator inventoryByNetworkDataPopulator;

	public String getOrderCreatedBy() {
		if(this.orderObject.isInStoreOrder()) {
			return "store";
		} else {
			return "web";
		}
	}
	
	public boolean isValidOrderLineCharge(String description) {
		String[] excludedLineCharge = {"List price","Sale price"};
		List<String> descriptions = new ArrayList<String>(Arrays.asList(excludedLineCharge));
		if(descriptions.contains(description)) {
			return false;
		}
		return true;
	}
	
	public Date getOrderTaxCalculatedDate() {
		return this.orderObject.getTaxDate() !=null ? this.orderObject.getTaxDate(): null;
	}
	public String getOrderCurrencyCode() {
		return this.orderObject.getPriceInfo().getCurrencyCode();
	}
	
	public void submitOrder(DXLOrder order, RepositoryItem profile, String sessionId) {
		this.orderObject = order;
		if(isLoggingDebug()) {
			logDebug(getClass().getName()+" Method submitOrder() starts::");
		}
		JSONObject finalJSON;
		try {
			long startTime = System.currentTimeMillis();
			
			finalJSON = buildJsonToSubmitOrder(order, profile, sessionId);
			getSubmitToSQSClient().sendMessageToQueue(getQueueName(),finalJSON.toString());
			
			long endTime = System.currentTimeMillis();
			vlogInfo("Time taken to submit order to SQS::",endTime-startTime);
			
			if(isLoggingDebug()) {
				logDebug(getClass().getName()+" Method submitOrder() ends::");
			}
		} catch (JSONException e) {
			if(isLoggingError()) {
				logError(e);
			}
		} catch (CommerceException e) {
			if(isLoggingError()) {
				logError(e);
			}
		} catch (Exception e) {
			if(isLoggingError()) {
				logError(e);
			}
		}
	}

	private JSONObject buildJsonToSubmitOrder(DXLOrder order, RepositoryItem profile, String sessionId) throws CommerceException, JSONException {
		if(isLoggingDebug()) {
			logDebug(getClass().getName()+" Method buildJsonToSubmitOrder() starts::");
		}
		JSONObject rootObject = new JSONObject();
		rootObject.put("AlternateOrderId", order.getId());
		rootObject.put("CapturedDate", DateUtil.getISO8601StringForDate(order.getSubmittedDate()));
		rootObject.put("Created By", getOrderCreatedBy());
		rootObject.put("CreatedTimestamp", DateUtil.getISO8601StringForDate(order.getSubmittedDate()));
		rootObject.put("CustomerEmail", StringUtil.isEmpty(order.getEmail()) ? (String) profile.getPropertyValue("email") : order.getEmail());
		rootObject.put("DocType", new JSONObject().put("DocTypeId", "CustomerOrder"));
		
		rootObject.put("IsConfirmed", true);
		rootObject.put("OrderId", order.getId());
		rootObject.put("OrderLineCount", order.getCommerceItemCount());
		
		buildCustomerDetailsJson(rootObject,profile,order);
		buildPaymentInfoJson(rootObject,profile,order);
		buildOrderLineJson(rootObject,profile, order);
		
		rootObject.put("CurrencyCode", getOrderCurrencyCode());
		rootObject.put("OrderType", new JSONObject().put("OrderTypeId", getOrderCreatedBy()));
		rootObject.put("OrgId", getGlobalAppConfig().getCompanyId());
		
		// need to create orderNote json
		buildOrderNoteDetailJSON(rootObject,order);
		
		buildOrderTaxDetailJSON(rootObject,order);
		buildOrderChargeDetailJson(rootObject,order);
		
		rootObject.put("OrderTotal", order.getPriceInfo().getTotal());
		rootObject.put("SellingChannel", new JSONObject().put("SellingChannelId", getOrderCreatedBy()));

		buildOrderAttributeJSON(rootObject,order); 
		buildOrderActionsJSON(rootObject); 
		
		if(isLoggingDebug()) {
			logDebug(getClass().getName()+" Method buildJsonToSubmitOrder() ends::");
		}
		return rootObject;
		
	}

	private void buildOrderNoteDetailJSON(JSONObject rootObject, DXLOrder order) {
		if(isLoggingDebug()) {
			logDebug(getClass().getName()+" Method buildOrderNoteDetailJSON() starts::");
		}
		if(order.isSTSOrder()) {
			JSONArray orderNote = new JSONArray();
			JSONObject orderNoteObject = new JSONObject();
			try {
				orderNoteObject.put("NoteId", "store,associate");
				orderNoteObject.put("NoteText", order.getAgentId());
				orderNote.put(orderNoteObject);
				rootObject.put("OrderNote", orderNoteObject);
			} catch (JSONException e) {
				if(isLoggingError()) {
					logError("Error occured buildOrderNoteDetailJSON(). "+e);
				}
			}
		}
		if(isLoggingDebug()) {
			logDebug(getClass().getName()+" Method buildOrderNoteDetailJSON() ends::");
		}
	}

	private void buildOrderChargeDetailJson(JSONObject rootObject, DXLOrder order) {
		if(isLoggingDebug()) {
			logDebug(getClass().getName()+" Method buildOrderChargeDetailJson() starts::");
		}
		JSONArray orderCharge = new JSONArray();
		Iterator<ShippingGroup> itr = order.getShippingGroups().iterator();
		Double totalShipPingPrice = 0.0;
		int chargeSeq = 0;
		while (itr.hasNext()) {
			ShippingGroup sg = itr.next();
			totalShipPingPrice = totalShipPingPrice + sg.getPriceInfo().getAmount();
		}

		JSONObject shippingChargeObject = new JSONObject();
		try {
			shippingChargeObject.put("ChargeDetailId", String.valueOf(++chargeSeq));
			shippingChargeObject.put("ChargeDisplayName", "Shipping");
			shippingChargeObject.put("ChargeTotal", String.valueOf(totalShipPingPrice));
			shippingChargeObject.put("ChargeType", new JSONObject().put("ChargeTypeId", "Shipping"));
			orderCharge.put(shippingChargeObject);
			rootObject.put("OrderChargeDetail", orderCharge);
			if(isLoggingDebug()) {
				logDebug(getClass().getName()+" Method buildOrderChargeDetailJson() ends::");
			}
		} catch (JSONException e) {
			if(isLoggingError()) {
				logError("Error occured buildOrderChargeDetailJson(). "+e);
			}
		}
	}

	private void buildOrderActionsJSON(JSONObject rootObject) {
		if(isLoggingDebug()) {
			logDebug(getClass().getName()+" Method buildOrderActionsJSON() starts::");
		}
		JSONObject orderActObject = new JSONObject();
		try {
			orderActObject.put("IsAlreadyPriced",true);
			orderActObject.put("IsAlreadyCharged",true);
			orderActObject.put("IsAlreadyTaxed",true);
			rootObject.put("OrderActions",orderActObject);
			if(isLoggingDebug()) {
				logDebug(getClass().getName()+" Method buildOrderActionsJSON() starts::");
			}
		} catch (JSONException e) {
			if(isLoggingError()) {
				logError("Error occured while executing buildOrderActionsJSON(). "+e);
			}
		}
	}

	private void buildOrderAttributeJSON(JSONObject rootObject, DXLOrder order) {
		if(isLoggingDebug()) {
			logDebug(getClass().getName()+" Method buildOrderAttributeJSON() starts::");
		}
		JSONArray orderAttrArray = new JSONArray();
		try {
			if (!StringUtil.isEmpty(order.getLinkshareSiteId())) {
				JSONObject orderAttrObject = new JSONObject();
				orderAttrObject.put("LinkShareSiteId", order.getLinkshareSiteId());
				orderAttrArray.put(orderAttrObject);
				orderAttrObject.put("LinkShareDate", DateUtil.getISO8601StringForDate(order.getLinkshareTimeArrived()));
				orderAttrArray.put(orderAttrObject);
			}
			
			if (!StringUtil.isEmpty(order.getLinkshareBrandId())) {
				JSONObject orderAttrObject = new JSONObject();
				orderAttrObject.put("LinkShareBrandId", order.getLinkshareBrandId());
				orderAttrArray.put(orderAttrObject);
			}
			
			if(orderAttrArray.length() > 0) {
				rootObject.put("OrderAttribute",orderAttrArray);
			}
			
			if(isLoggingDebug()) {
				logDebug(getClass().getName()+" Method buildOrderAttributeJSON() ends::");
			}
		} catch (JSONException e) {
			if(isLoggingError()) {
				logError("Error occured while building order action json. "+e);
			}
		}
		
		
	}

	private void buildOrderTaxDetailJSON(JSONObject rootObject, DXLOrder order)  {
		if(isLoggingDebug()) {
			logDebug(getClass().getName()+" Method buildOrderTaxDetailJSON() starts::");
		}
		JSONArray orderTaxDetail = new JSONArray();

		Iterator<ShippingGroup> itr = order.getShippingGroups().iterator();
		while (itr.hasNext()) {
			ShippingGroup sg = itr.next();
			if (sg instanceof DXLHardgoodShippingGroup) {
				RepositoryItem vertexItem = ((DXLHardgoodShippingGroup)sg).getVertexTaxInfo();
				if(vertexItem != null) {
					if((RepositoryItem)vertexItem.getPropertyValue("stateTax") != null) {
						orderTaxDetail.put(getTaxDetailObject((RepositoryItem)vertexItem.getPropertyValue("stateTax")));
					}
					if((RepositoryItem)vertexItem.getPropertyValue("cityTax") != null) {
						orderTaxDetail.put(getTaxDetailObject((RepositoryItem)vertexItem.getPropertyValue("cityTax")));
					}
					if((RepositoryItem)vertexItem.getPropertyValue("districtTax") != null) {
						orderTaxDetail.put(getTaxDetailObject((RepositoryItem)vertexItem.getPropertyValue("districtTax")));
					}
				}
			}
		}
		try {
			rootObject.put("OrderTaxDetail",orderTaxDetail);
			if(isLoggingDebug()) {
				logDebug(getClass().getName()+" Method buildOrderTaxDetailJSON() ends::");
			}
		} catch (JSONException e) {
			if(isLoggingError()) {
				logError("Error occured OrderTaxDetail()."+e);
			}
		}
	}

	private void buildOrderLineJson(JSONObject rootObject, RepositoryItem profile, DXLOrder order) throws CommerceException {
		if(isLoggingDebug()) {
			logDebug(getClass().getName()+" Method buildOrderLineJson() starts::");
		}
		JSONArray orderLineArray = new JSONArray();
		
		List<Relationship> rels = order.getRelationships();
		if (rels != null && rels.size() > 0) {
			try {
				Iterator<Relationship> it = rels.iterator();
				int orderLineItemCount = 1;
				while (it.hasNext()) {
					JSONObject orderLineObject = new JSONObject();
					Relationship rel = it.next();
					if (rel instanceof ShippingGroupCommerceItemRelationship) {
						
						ShippingGroupCommerceItemRelationship sgcir = (ShippingGroupCommerceItemRelationship) rel;
						ShippingGroup ciShippingGroup = sgcir.getShippingGroup();
						DXLCommerceItem ci = (DXLCommerceItem) sgcir.getCommerceItem();
						
						if(ciShippingGroup != null && ci != null) {
							orderLineObject.put("DeliveryMethod", new JSONObject().put("DeliveryMethodId", "ShiptoAddress"));
						    orderLineObject.put("Extended", new JSONObject().put("AVSCommercial", true));
							if (ci.getVertexTaxInfo() != null) {
								orderLineObject.put("UOM",(String) ci.getVertexTaxInfo().getPropertyValue("unitOfMeasure"));
							} else {
								orderLineObject.put("UOM","EA");
							}
						    orderLineObject.put("ShipToLocationId",""); // get it from ship group ????
						    orderLineObject.put("ShippingMethodId",ciShippingGroup.getShippingMethod());
						    
						    /*JSONArray orderLineAllocation = getOrderLineAllocationDetails(ciShippingGroup);
						    orderLineObject.put("Allocation", orderLineAllocation);*/
						    
						    if (ciShippingGroup instanceof DXLHardgoodShippingGroup) {
						    	JSONObject shipToAddressObj = new JSONObject();
						    	JSONObject shipToAddress = buildAddressJson((DXLContactInfo)((DXLHardgoodShippingGroup)ciShippingGroup).getShippingAddress());
						    	shipToAddressObj.put("Address", shipToAddress);
						    	shipToAddressObj.put("AddressTypeId", "Shipping");
						    	shipToAddressObj.put("IsAddressVerified", true);
						    	orderLineObject.put("ShipToAddress", shipToAddressObj);
						    	String deliveryDatebyShippingMethod = getDevliveryDate(((DXLHardgoodShippingGroup) ciShippingGroup).getShippingMethodItem());
						    	orderLineObject.put("PromisedDeliveryDate", deliveryDatebyShippingMethod);
							    
						    }else if (ciShippingGroup instanceof DXLInStorePickupShippingGroup) {
						    	JSONObject shipToAddressObj = new JSONObject();
						    	JSONObject shipToAddress = buildAddressJson((DXLContactInfo)((DXLHardgoodShippingGroup)ciShippingGroup).getShippingAddress());
						    	shipToAddressObj.put("Address", shipToAddress);
						    	shipToAddressObj.put("AddressTypeId", "Shipping");
						    	shipToAddressObj.put("IsAddressVerified", true);
						    	orderLineObject.put("ShipToAddress", shipToAddressObj);
						    	String deliveryDatebyShippingMethod = getDevliveryDate(((DXLHardgoodShippingGroup) ciShippingGroup).getShippingMethodItem());
						    	orderLineObject.put("PromisedDeliveryDate", deliveryDatebyShippingMethod);
						    }
						    else if(ciShippingGroup instanceof DXLElectronicShippingGroup) {
						    	
						    }
						    
						    String skuEDPNumber = ci.getCatalogRefId();
							orderLineObject.put("ItemId",skuEDPNumber);
							
							boolean isGiftCard = ((DXLOrderTools) getOrderTools()).isSkuGiftCard(skuEDPNumber);
	
							orderLineObject.put("IsGift", isGiftCard ? true : false );
						    orderLineObject.put("IsGiftCard", isGiftCard ? true : false );
						    orderLineObject.put("GiftCardValue", isGiftCard ? ci.getPriceInfo().getAmount() : null );
						    orderLineObject.put("IsActivationRequired",isGiftCard ? true : false );
						    
						    orderLineObject.put("Quantity", String.valueOf(ci.getQuantity()));
						    Double unitPrice = ci.getPriceInfo().isOnSale() ? ci.getPriceInfo().getSalePrice() : ci.getPriceInfo().getListPrice();
						    orderLineObject.put("UnitPrice", String.valueOf(unitPrice));
						    orderLineObject.put("OrderLineId", "OLI"+orderLineItemCount);
						    
						    JSONArray orderLineChargeDetail = getOrderLineChargeDetailJSON(ciShippingGroup, ci, orderLineObject);
						    orderLineObject.put("OrderLineChargeDetail", orderLineChargeDetail);
						    
						    JSONArray orderLineTaxDetail = getOrderLineTaxDetailJSON(ci);
						    orderLineObject.put("OrderLineTaxDetail", orderLineTaxDetail);
						    
						}
						orderLineArray.put(orderLineObject);
					}
					orderLineItemCount++;
				}
				rootObject.put("OrderLine", orderLineArray);
				if(isLoggingDebug()) {
					logDebug(getClass().getName()+" Method buildOrderLineJson() ends::");
				}
			} catch(JSONException exe) {
				if(isLoggingError()) {
					logError("buildOrderLineJson(): "+exe);
				}
			} catch (ParseException exe) {
				if(isLoggingError()) {
					logError("buildOrderLineJson(): "+exe);
				}
			}
		}
		
		
	}

	private String getDevliveryDate(RepositoryItem shippingMethodItem) throws ParseException {
		String date = "";
		if (shippingMethodItem.getPropertyValue("estimatedShippingDateHighBound") != null) {
			date = (String) shippingMethodItem.getPropertyValue("estimatedShippingDateHighBound");
		} else if (shippingMethodItem.getPropertyValue("estimatedShippingDateLowBound") != null) {
			date = (String) shippingMethodItem.getPropertyValue("estimatedShippingDateLowBound");
		}
		
		if(date.length() > 0) {
			int year = Calendar.getInstance().get(Calendar.YEAR);
			String finalDate = date + "/" + String.valueOf(year);
			Date deliveryDate=new SimpleDateFormat("MM/dd/yyyy").parse(finalDate);
			date = DateUtil.getISO8601StringForDate(deliveryDate);
		}
		return date;
	}

	private JSONArray getOrderLineTaxDetailJSON(DXLCommerceItem ci) {
		JSONArray orderLineTaxArray = new JSONArray();
		
		if(ci.getVertexTaxInfo() !=  null) {

			if((RepositoryItem)ci.getVertexTaxInfo().getPropertyValue("stateTax") != null) {
				orderLineTaxArray.put(getTaxDetailObject((RepositoryItem)ci.getVertexTaxInfo().getPropertyValue("stateTax")));
			}
			if((RepositoryItem)ci.getVertexTaxInfo().getPropertyValue("cityTax") != null) {
				orderLineTaxArray.put(getTaxDetailObject((RepositoryItem)ci.getVertexTaxInfo().getPropertyValue("cityTax")));
			}
			if((RepositoryItem)ci.getVertexTaxInfo().getPropertyValue("districtTax") != null) {
				orderLineTaxArray.put(getTaxDetailObject((RepositoryItem)ci.getVertexTaxInfo().getPropertyValue("districtTax")));
			}
		}
		
		return orderLineTaxArray;
	}

	private JSONObject getTaxDetailObject(RepositoryItem vertexItem) {

		JSONObject taxDetail = new JSONObject();
		try {
			taxDetail.put("IsInvoiceTax",false);
			taxDetail.put("TaxDetailId",(String)vertexItem.getPropertyValue("taxRuleId"));
			taxDetail.put("TaxTypeId",(String)vertexItem.getPropertyValue("taxType"));
			taxDetail.put("TaxableAmount",(Double)vertexItem.getPropertyValue("taxable"));
			taxDetail.put("JurisdictionTypeId",(String)vertexItem.getPropertyValue("jurisdictionLevel"));
			taxDetail.put("Jurisdiction",(String)vertexItem.getPropertyValue("jurisdiction"));
			taxDetail.put("TaxAmount",(Double)vertexItem.getPropertyValue("calculatedTax"));
			taxDetail.put("TaxDate",DateUtil.getISO8601StringForDate(getOrderTaxCalculatedDate()));
			taxDetail.put("TaxRate",(Double)vertexItem.getPropertyValue("effectiveRate"));
		} catch (JSONException e) {
			if(isLoggingError()){
				vlogError(e, "Exception occured in getTaxDetailObject().");
			}
		}
		return taxDetail;
		
	}

	private JSONArray getOrderLineChargeDetailJSON(ShippingGroup ciShippingGroup, DXLCommerceItem ci, JSONObject orderLineObject) throws ClaimableException {
		if(isLoggingDebug()) {
			logDebug(getClass().getName()+" Method getOrderLineChargeDetailJSON() starts::");
		}
		JSONArray orderLineChargeArray = new JSONArray();
		JSONArray orderLineVASInstructionsArray = new JSONArray();
		
		ItemPriceInfo ipi = ci.getPriceInfo();
		Iterator iterator = ci.getPriceInfo().getAdjustments().iterator();
		int i = 1;
		boolean isVasAvailable = false;
		while(iterator.hasNext()) {
			try {
				JSONObject orderLineChargeObject = new JSONObject();
				PricingAdjustment ciAdjustment = (PricingAdjustment) iterator.next();
				
				if (ciAdjustment.getPricingModel() != null) {
					orderLineChargeObject.put("ChargeType" , new JSONObject().put("ChargeTypeId", "Coupon"));
					RepositoryItem[] couponItems = getClaimableTools().getCouponsForPromotion(ciAdjustment.getPricingModel().getRepositoryId());
					orderLineChargeObject.put("ChargeDisplayName" ,couponItems[0].getRepositoryId());
					orderLineChargeObject.put("ChargeReferenceId" ,couponItems[0].getRepositoryId());
				} else {
					if(ci instanceof DXLCustomizationCommerceItemImpl && isValidOrderLineCharge(ciAdjustment.getAdjustmentDescription())) {
						orderLineChargeObject.put("ChargeType" , new JSONObject().put("ChargeTypeId", "Value Added Services"));
						orderLineChargeObject.put("ChargeDisplayName" , ci.getCustomizationData().get("customizationRoutineCode")); // get promo code name
						
						// if any VAS(customization) available then create VAS JSON
						isVasAvailable = true;
						generateOrderLineVASInstructions(ciAdjustment, (DXLCustomizationCommerceItemImpl)ci, orderLineVASInstructionsArray);
					}
				}
				
				if (orderLineChargeObject.length() > 0) {
					orderLineChargeObject.put("ChargeDetailId" , String.valueOf(i));
					orderLineChargeObject.put("IsLineDiscount" , ipi.isDiscounted());
					orderLineChargeObject.put("ChargeTotal" , ciAdjustment.getTotalAdjustment());
					orderLineChargeObject.put("IsInformational" , false);
					orderLineChargeObject.put("IsOverridden" , false);
					orderLineChargeObject.put("IsReturnCharge" , false);
					i++;
					orderLineChargeArray.put(orderLineChargeObject);
				}
				
				if(isVasAvailable) {
					orderLineObject.put("OrderLineVASInstructions", orderLineVASInstructionsArray);
				}
			} catch(JSONException exe) {
				if(isLoggingError()) {
					logError("getOrderLineChargeDetailJSON(): "+exe);
				}
			}
		}
		return orderLineChargeArray;
	}

	private void generateOrderLineVASInstructions(PricingAdjustment ciAdjustment, DXLCustomizationCommerceItemImpl ci, JSONArray orderLineVASInstructionsArray)  {
		
		Map<String, String> dataMap = new HashMap<String, String>(ci.getCustomizationData());
		
		 if ((dataMap != null) && (dataMap.size() != 0)) {
			 String customizationRoutineCode= (String) dataMap.get("customizationRoutineCode");
	        	dataMap.remove("customizationRoutineCode");
	    		//dont wanna get customization routine
	    		//remove it??
	        	List<String> sortedKeys = new ArrayList<String>();
	        	sortedKeys.addAll(dataMap.keySet());
	        	/*Collections.sort(sortedKeys,new Comparator<String>() {
	                public int compare(String key1, String key2) {
	                	return Integer.valueOf(key1) - Integer.valueOf(key2);
	                }
	            });*/
	        	try 
	        	{
		        	if (!"HEM".equalsIgnoreCase((customizationRoutineCode))) {
		        		Iterator itr = sortedKeys.iterator();
		        		//String keys = "";
		        		//String values = "";
		        	    while (itr.hasNext()) {
		        	    	String key = (String) itr.next();
		        	    	String value = dataMap.get(key) ;
		        	        /*keys = keys + key;
		        	        value = values + value;*/
		        	    	JSONObject orderLineVASInstructionsObject = new JSONObject();
		        	        orderLineVASInstructionsObject.put("VasOptionId", key);
			        		orderLineVASInstructionsObject.put("VasTypeId", key);
			        		orderLineVASInstructionsObject.put("VasInstructions", value);
			        		orderLineVASInstructionsArray.put(orderLineVASInstructionsObject);
		        	    }
		        	    /*orderLineVASInstructionsObject.put("VasOptionId", keys);
		        		orderLineVASInstructionsObject.put("VasTypeId", keys);
		        		orderLineVASInstructionsObject.put("VasInstructions", values);*/
		        	} else {
		        		JSONObject orderLineVASInstructionsObject = new JSONObject();
		        		orderLineVASInstructionsObject.put("VasOptionId", "Hemming");
		        		orderLineVASInstructionsObject.put("VasTypeId", "HEM");
		        		orderLineVASInstructionsObject.put("VasInstructions", "Hemming");
		        		orderLineVASInstructionsArray.put(orderLineVASInstructionsObject);
		        	}
	        	} catch(JSONException exe) {
					if(isLoggingError()) {
						logError("generateOrderLineVASInstructions(): "+exe);
					}
				}
		 }
	}

	private JSONArray getOrderLineAllocationDetails(ShippingGroup ciShippingGroup)  {
		JSONArray allocation = new JSONArray();
		JSONObject allocationObject = new JSONObject();
		try {
			allocationObject.put("LatestReleaseDate", "");
			allocationObject.put("LatestShipDate", "");
		} catch(JSONException exe) {
			if(isLoggingError()) {
				logError("getOrderLineAllocationDetails(): "+exe);
			}
		}
		allocation.put(allocationObject);
		return allocation;
	}

	private void buildCustomerDetailsJson(JSONObject rootObject, RepositoryItem profile, DXLOrder order)  {
		if(isLoggingDebug()) {
			logDebug(getClass().getName()+" Method buildCustomerDetailsJson() starts::");
		}
		DXLContactInfo contactInfo = null;
		for (Object objPaymentGroup : order.getPaymentGroups()) {
			contactInfo = getContactInfoFromPaymentGroup(objPaymentGroup);
			break;
		}
		try {
			rootObject.put("CustomerFirstName", contactInfo.getFirstName());
			rootObject.put("CustomerLastName", contactInfo.getLastName());
			rootObject.put("CustomerId", profile.getRepositoryId());
			rootObject.put("CustomerPhone", contactInfo.getPhoneNumber());
			
			JSONObject custAddressDetail = buildAddressJson(contactInfo);
			rootObject.put("CustomerAddress", custAddressDetail);
		} catch(JSONException exe) {
			if(isLoggingError()) {
				logError("buildCustomerDetailsJson(): "+exe);
			}
		}
		if(isLoggingDebug()) {
			logDebug(getClass().getName()+" Method buildCustomerDetailsJson() ends::");
		}
	}

	private DXLContactInfo getContactInfoFromPaymentGroup(Object objPaymentGroup) {
		if(isLoggingDebug()) {
			logDebug("getContactInfoFromPaymentGroup() Starts::");
		}
		DXLContactInfo contactInfo = null;
		
		if (objPaymentGroup instanceof DXLCreditCard) {
			contactInfo = ((DXLCreditCard) objPaymentGroup).getBillingAddress();
		}
		
		if (objPaymentGroup instanceof DXLGiftCard) {
			contactInfo = ((DXLGiftCard) objPaymentGroup).getBillingAddress();
		}
		
		if(objPaymentGroup instanceof AmazonPayPayment) {
			contactInfo = (DXLContactInfo) ((AmazonPayPayment) objPaymentGroup).getBillingAddress();
		}
		
		if (objPaymentGroup instanceof DXLPayPalPayment) {
			contactInfo = (DXLContactInfo) ((DXLPayPalPayment) objPaymentGroup).getBillingAddress();
		}
		
		if (objPaymentGroup instanceof CashPayment) {
			contactInfo = (DXLContactInfo) ((CashPayment) objPaymentGroup).getBillingAddress();
		}
		
		if(isLoggingDebug()) {
			logDebug("getContactInfoFromPaymentGroup() Ends::");
		}
		return contactInfo;
	}

	private JSONObject buildAddressJson(DXLContactInfo contactInfo)  {
		JSONObject custAddressDetail = new JSONObject();
		try {
			custAddressDetail.put("Address1", contactInfo.getAddress1());
			custAddressDetail.put("Address2", contactInfo.getAddress2());
			custAddressDetail.put("Address3", contactInfo.getAddress3());
			custAddressDetail.put("City", contactInfo.getCity());
			custAddressDetail.put("Country", contactInfo.getCountry());
			custAddressDetail.put("Email", contactInfo.getEmail());
			custAddressDetail.put("FirstName", contactInfo.getFirstName());
			custAddressDetail.put("LastName", contactInfo.getLastName());
			custAddressDetail.put("Phone", contactInfo.getPhoneNumber());
			custAddressDetail.put("PostalCode", contactInfo.getPostalCode());
			custAddressDetail.put("State", contactInfo.getState());
		} catch(JSONException exe) {
			if(isLoggingError()) {
				logError("buildAddressJson(): "+exe);
			}
		}
		return custAddressDetail;
	}
	
	private void buildPaymentInfoJson(JSONObject rootObject, RepositoryItem profile, DXLOrder order)  {
		if(isLoggingDebug()) {
			logDebug(getClass().getName()+" Method buildPaymentInfoJson() starts::");
		}
		JSONArray paymentArray = new JSONArray();
		try {
			int seqNum = 1;
			for (Object objPaymentGroup : order.getPaymentGroups()) {
				
				JSONObject paymentGroupObject = new JSONObject();
				
				PaymentGroup pg = (PaymentGroup) objPaymentGroup;
				paymentGroupObject.put("PaymentGroupId", pg.getId());
				paymentGroupObject.put("CreatedBy", getOrderCreatedBy());
				paymentGroupObject.put("OrgId", getGlobalAppConfig().getCompanyId());
				
				JSONArray paymentMethodArray = new JSONArray(); 
				paymentGroupObject.put("PaymentMethod", getPaymentMethodArray(objPaymentGroup,paymentMethodArray,seqNum));
				seqNum++;
				paymentArray.put(paymentGroupObject);
			}
			rootObject.put("Payment", paymentArray);
		} catch(JSONException exe) {
			if(isLoggingError()) {
				logError("buildPaymentInfoJson(): "+exe);
			}
		}
		if(isLoggingDebug()) {
			logDebug(getClass().getName()+" Method buildPaymentInfoJson() ends::");
		}
	}

	private JSONArray getPaymentMethodArray(Object objPaymentGroup, JSONArray paymentMethodArray, int seqNum) throws JSONException  {
		
		PaymentGroup pg = (PaymentGroup) objPaymentGroup;
		
		JSONObject paymentMethodObject = new JSONObject();
		paymentMethodObject.put("Amount", pg.getAmountAuthorized()); //setting amount authorized
		paymentMethodObject.put("BillingAddress", new JSONObject().put("Address", buildAddressJson(getContactInfoFromPaymentGroup(objPaymentGroup))));
		
		buildCreditCardDetailsJson(paymentMethodObject,objPaymentGroup);
		
		//paymentMethodObject.put("CreatedBy",getOrderCreatedBy());
		paymentMethodObject.put("ChargeSequence",seqNum); // as of now not setting this. 
		//paymentMethodObject.put("GatewayId",""); // needs to be clarified
		
		paymentMethodArray.put(paymentMethodObject);
		
		JSONArray paymentTransactionObject= new JSONArray().put(generatePaymentTransactionJSON(pg));
		paymentMethodObject.put("PaymentTransaction", paymentTransactionObject);
		paymentMethodObject.put("PaymentMethodId", pg.getId());
		
		return paymentMethodArray;
	}

	private JSONObject generatePaymentTransactionJSON(PaymentGroup pg) throws JSONException  {
		JSONObject transactionDetails= new JSONObject();
		List authStatus = pg.getAuthorizationStatus();
		for (int i = 0; i < authStatus.size(); i++) {
			authStatus.get(i);
			if(authStatus.get(i) instanceof DXLCreditCardStatus) {
				DXLCreditCardStatus ccStatus = (DXLCreditCardStatus)authStatus.get(i);
				transactionDetails.put("PaymentTransactionId", ccStatus.getTransactionId());
				transactionDetails.put("ProcessedAmount",ccStatus.getAmount());
				transactionDetails.put("TransactionDate" , DateUtil.getISO8601StringForDate(ccStatus.getTransactionTimestamp()));
				//transactionDetails.put("TransactionExpiryDate" , DateUtil.getISO8601StringForDate(((CreditCardStatus)authStatus.get(i)).getAuthorizationExpiration()));
				transactionDetails.put("RequestedAmount",pg.getAmount());
				transactionDetails.put("RequestToken",ccStatus.getRequestToken());
				transactionDetails.put("RequestId",ccStatus.getRequestID());
				
				transactionDetails.put("PaymentResponseStatus",new JSONObject().put("PaymentResponseStatusId", ccStatus.getTransactionSuccess() ? "Success" : "Failure"));
				transactionDetails.put("TransactionType",new JSONObject().put("PaymentTransactionTypeId","Authorization"));
				transactionDetails.put("Status",new JSONObject().put("PaymentTransactionStatusId", ccStatus.getTransactionSuccess() ? "Closed" : "Open"));
			}
			if(authStatus.get(i) instanceof DXLPayPalPaymentStatus) {
				DXLPayPalPaymentStatus paypalStatus = (DXLPayPalPaymentStatus)authStatus.get(i);
				transactionDetails.put("PaymentTransactionId", paypalStatus.getTransactionId());
				transactionDetails.put("ProcessedAmount",paypalStatus.getAmount());
				transactionDetails.put("TransactionDate" , DateUtil.getISO8601StringForDate(paypalStatus.getTransactionTimestamp()));
				transactionDetails.put("RequestedAmount",pg.getAmount());
				transactionDetails.put("RequestToken",((DXLPayPalPayment)pg).getTokenId());
				//transactionDetails.put("RequestId",paypalStatus.getRequestID());
				
				transactionDetails.put("PaymentResponseStatus",new JSONObject().put("PaymentResponseStatusId", paypalStatus.getTransactionSuccess() ? "Success" : "Failure"));
				transactionDetails.put("TransactionType",new JSONObject().put("PaymentTransactionTypeId","Authorization"));
				transactionDetails.put("Status",new JSONObject().put("PaymentTransactionStatusId", paypalStatus.getTransactionSuccess() ? "Closed" : "Open"));
			}
			if(authStatus.get(i) instanceof AmazonPayPaymentStatus) {
				// need to impoelemt amazonpay
			}
		}
		transactionDetails.put("ReconciliationId", ""); // needs to be clarified
		
		return transactionDetails;
	}

	private void buildCreditCardDetailsJson(JSONObject paymentMethodObject, Object objPaymentGroup) throws JSONException  {
		
		paymentMethodObject.put("CurrencyCode", ((PaymentGroup) objPaymentGroup).getCurrencyCode());
		paymentMethodObject.put("CurrentAuthAmount", ((PaymentGroup) objPaymentGroup).getAmountAuthorized());
		
		if (objPaymentGroup instanceof DXLCreditCard) {
			DXLCreditCard payGroup = (DXLCreditCard) objPaymentGroup;
			paymentMethodObject.put("AccountDisplayNumber",payGroup.getCreditCardToken()); 
			paymentMethodObject.put("AccountNumber",payGroup.getCreditCardToken());
			paymentMethodObject.put("CardExpiryMonth",payGroup.getExpirationMonth());
			paymentMethodObject.put("CardExpiryYear",payGroup.getExpirationYear());
			paymentMethodObject.put("CardTypeId",payGroup.getCreditCardType());
			paymentMethodObject.put("NameOnCard",((DXLContactInfo)payGroup.getBillingAddress()).getFirstName()+" "+((DXLContactInfo)payGroup.getBillingAddress()).getLastName());
			paymentMethodObject.put("PaymentType", new JSONObject().put("PaymentTypeId", "Credit Card"));
		}
		
		if (objPaymentGroup instanceof DXLGiftCard) {
			DXLGiftCard payGroup = (DXLGiftCard) objPaymentGroup;
			paymentMethodObject.put("AccountNumber",payGroup.getGiftCardNumber());
			paymentMethodObject.put("GiftCardPin",payGroup.getGiftCardPin());
			paymentMethodObject.put("NameOnCard",((DXLContactInfo)payGroup.getBillingAddress()).getFirstName()+" "+((DXLContactInfo)payGroup.getBillingAddress()).getLastName());
			paymentMethodObject.put("PaymentType", new JSONObject().put("PaymentTypeId", "Gift Card"));
		}
		
		if(objPaymentGroup instanceof AmazonPayPayment) {
			AmazonPayPayment payGroup = (AmazonPayPayment) objPaymentGroup;
			paymentMethodObject.put("NameOnCard",((DXLContactInfo)payGroup.getBillingAddress()).getFirstName()+" "+((DXLContactInfo)payGroup.getBillingAddress()).getLastName());
		}
		
		if (objPaymentGroup instanceof DXLPayPalPayment) {
			DXLPayPalPayment payGroup = (DXLPayPalPayment) objPaymentGroup;
			paymentMethodObject.put("NameOnCard",((DXLContactInfo)payGroup.getBillingAddress()).getFirstName()+" "+((DXLContactInfo)payGroup.getBillingAddress()).getLastName());
			paymentMethodObject.put("AccountNumber",payGroup.getTokenId());
			paymentMethodObject.put("AccountDisplayNumber",payGroup.getPaypalUserId()); 
			paymentMethodObject.put("PaymentType", new JSONObject().put("PaymentTypeId", "PayPal"));
		}
	}

	public String getAccessToken(boolean newToken) {
		String accessToken = null;
		OMSAuthTokenResponseBean tokenBean = getOmsAuthTokenBean();
		if (newToken || tokenBean == null) {
			tokenBean = genereateOMSAccessToken();
		}
		if (tokenBean != null) {
			accessToken = tokenBean.getAccessToken();
		}
		return accessToken;
	}

	/**
	 * 
	 * @return
	 */
	public OMSAuthTokenResponseBean genereateOMSAccessToken() {
		
		OMSAuthTokenResponseBean omsAuthTokenResponseBean = null;
		try {
			omsAuthTokenResponseBean = getOmsAccessTokenGenerator().generateOMSAccessToken();
		} catch (IllegalStateException | IOException e) {
			vlogError("Exception occurred while generating OMS Auth Token::"+e);
		}
		setOmsAuthTokenBean(omsAuthTokenResponseBean);
		return omsAuthTokenResponseBean;
	}

	/**
	 * Retrieves placed orders of current user
	 * 
	 * @param orderNumber
	 * @param email
	 * @return
	 */
	public List<DXLOrderHistoryItemDetail> retrieveOrders(String email) {

		RetrieveOrdersRequest request = getOrderHostoryRequest(email);

		RetrieveOrdersResponse omsResponse = submitOrderHistoryRequest(request);
		List<DXLOrderHistoryItemDetail> ordersList = null;
		if (omsResponse.isSuccess()) {
			ordersList = getOrderDataPopulator().populate(omsResponse.getOmsResponse());
		}
		return ordersList;
	}

	private RetrieveOrdersRequest getOrderHostoryRequest(String email) {
		RetrieveOrdersRequest omsRequest = new RetrieveOrdersRequest();
		OrderHistoryRequest orderRequest = new OrderHistoryRequest();
		String query = "CustomerEmail='" + email + "'";
		orderRequest.setQuery(query);
		orderRequest.setSize(getOrderHistorySize());
		omsRequest.setRequest(orderRequest);
		Template template = new Template();
		orderRequest.setTemplate(template);
		return omsRequest;
	}

	/**
	 * Submits Order History request to OMS
	 * 
	 * @param request
	 * @return RetrieveOrdersResponse
	 */
	private RetrieveOrdersResponse submitOrderHistoryRequest(RetrieveOrdersRequest request) {
		RetrieveOrdersResponse omsResponse = new RetrieveOrdersResponse();
		try {
			DXLOMSOrderHistoryWorker worker = new DXLOMSOrderHistoryWorker(omsResponse, request, getOmsWorkerInfo());
			worker.setLoggingDebug(isLoggingDebug());
			try {
				long totalTime = 0;
				long timetoWait = 100;
				Object notifier = new Object();

				for (totalTime = 0, timetoWait = 100; totalTime <= getOmsTimeout(); totalTime += timetoWait) {
					if (isLoggingDebug() && ((totalTime % 1000) == 0)) {
						logDebug("Time=" + totalTime);
					}
					synchronized (notifier) {
						notifier.wait(timetoWait);
					}
					if (omsResponse.isSuccess()) {
						break;
					}
				}
				if (isLoggingDebug()) {
					logDebug("Total Time Waited=" + totalTime);
				}
			} catch (InterruptedException e) {
				if (isLoggingDebug()) {
					logDebug("Thread was interrupted");
				}
				// handle interrupted exception
			}
		} catch (IllegalStateException e) {
			vlogError("Exception occurred while generating OMS Auth Token::" + e);
		}
		return omsResponse;
	}

	/**
	 * Looks up order by Order Id
	 * 
	 * @param orderNumber
	 * @param email
	 * @return
	 */
	public OrderData lookupOrder(String orderNumber, String email) {

		OrderSearchResponse omsResponse = submitOrderSearchRequest(orderNumber);
		OrderData orderData = null;
		if (omsResponse.isSuccess() && orderBelongsToUser(omsResponse, email)) {
			orderData = getOrderDataPopulator().populate(omsResponse.getOmsResponse());
		}
		return orderData;
	}

	private boolean orderBelongsToUser(OrderSearchResponse omsResponse, String email) {
		if (omsResponse.getOmsResponse() != null && omsResponse.getOmsResponse().getData() != null
				&& (omsResponse.getOmsResponse().getData().getCustomerEmail() == null
						|| email.equalsIgnoreCase(omsResponse.getOmsResponse().getData().getCustomerEmail()))) {
			return true;
		}
		return false;
	}

	/**
	 * Submits request to OMS
	 * 
	 * @param orderNumber
	 * @return OrderSearchResponse
	 */
	private OrderSearchResponse submitOrderSearchRequest(String orderNumber) {
		OrderSearchResponse omsResponse = new OrderSearchResponse();
		try {
			DXLOMSOrderSearchWorker worker = new DXLOMSOrderSearchWorker(omsResponse, orderNumber, getOmsWorkerInfo());
			worker.setLoggingDebug(isLoggingDebug());
			try {
				long totalTime = 0;
				long timetoWait = 100;
				Object notifier = new Object();

				for (totalTime = 0, timetoWait = 100; totalTime <= getOmsTimeout(); totalTime += timetoWait) {
					if (isLoggingDebug() && ((totalTime % 1000) == 0)) {
						logDebug("Time=" + totalTime);
					}
					synchronized (notifier) {
						notifier.wait(timetoWait);
					}
					if (omsResponse.isSuccess()) {
						break;
					}
				}
				if (isLoggingDebug()) {
					logDebug("Total Time Waited=" + totalTime);
				}
			} catch (InterruptedException e) {
				if (isLoggingDebug()) {
					logDebug("Thread was interrupted");
				}
				// handle interrupted exception
			}
		} catch (IllegalStateException e) {
			vlogError("Exception occurred while generating OMS Auth Token::" + e);
		}
		return omsResponse;
	}
	
	/**
	 * Test method to check the OMS inventory call
	 * We need to remove it after testing
	 */
	public void testInventoryAvailability(){
		List<String> edpNo = new ArrayList<String>();
		List<String> stores = new ArrayList<String>();
		
		edpNo.add("12345");
		edpNo.add("8675309");
		edpNo.add("8273493");
		stores.add("09160");
		stores.add("9540");
		List<InventoryData> inventoryList = getInventoryAvailabilityForLocation(edpNo, stores);
		for (InventoryData inventoryData : inventoryList) {
			vlogDebug("inventoryData.getItemId() : {0}",inventoryData.getItemId());
			vlogDebug("inventoryData.getLocationId() : {0}",inventoryData.getLocationId());
			vlogDebug("inventoryData.getStatus() : {0}",inventoryData.getStatus());
			vlogDebug("inventoryData.getQuantity().toString() : {0}",inventoryData.getQuantity().toString());
		}
	}
	
	/**Gets the OMS Inventory Availability for given location and edpNo
	 * @param edpNo List<String>
	 * @param stores List<String>
	 * @return List<InventoryData>
	 */
	public List<InventoryData> getInventoryAvailabilityForLocation(List<String> edpNo, List<String> stores){
		vlogDebug("getInventoryAvailabilityForLocation() - Start");
		RetrieveInventoryReqForLocation omsRequest = getInventoryRequestForLocation(edpNo, stores);
		RetrieveInventoryResponseForLocation omsResponse = submitInventoryRequestForLocation(omsRequest);
		InventoryForLocation inventoryForLocation = null;
		List<InventoryData> inventoryList = null;
		if(omsResponse.isSuccess()){
			inventoryForLocation=omsResponse.getInventoryForLocation();
		}else{
			vlogError("getInventoryAvailabilityForLocation :: OMS Response for Inventory by Location is Failed");
		}
		if(inventoryForLocation!=null){
			inventoryList = getInventoryByLocationDataPopulator().populateData(inventoryForLocation);
			vlogDebug("getInventoryAvailabilityForLocation :: InventoryData list Size is : {0}",inventoryList.size());
		}
		vlogDebug("getInventoryAvailabilityForLocation() - End");
		return inventoryList;
	}
	
	/**Gets the Inventory Request to do the OMS inventory call
	 * @param edpNo List<String>
	 * @param stores List<String>
	 * @return RetrieveInventoryReqForLocation
	 */
	private RetrieveInventoryReqForLocation getInventoryRequestForLocation(List<String> edpNo,List<String> stores){
		RetrieveInventoryReqForLocation omsRequest = new RetrieveInventoryReqForLocation();
		InventoryReqForLocation inventoryReq = new InventoryReqForLocation();
		inventoryReq.setItems(edpNo);
		inventoryReq.setLocations(stores);
		inventoryReq.setViewName("BOPIS");
		omsRequest.setRequest(inventoryReq);
		return omsRequest;
	}
	
	/**Submits the inventory request to OMS to get the inventory availability base on location
	 * @param request RetrieveInventoryReqForLocation
	 * @return RetrieveInventoryResponseForLocation
	 */
	private RetrieveInventoryResponseForLocation submitInventoryRequestForLocation(RetrieveInventoryReqForLocation request) {
		RetrieveInventoryResponseForLocation omsResponse = new RetrieveInventoryResponseForLocation();
		try {
			DXLOMSInventoryByLocationWorker worker = new DXLOMSInventoryByLocationWorker(omsResponse, request, getOmsWorkerInfo());
			worker.setLoggingDebug(isLoggingDebug());
			try {
				long totalTime = 0;
				long timetoWait = 100;
				Object notifier = new Object();

				for (totalTime = 0, timetoWait = 100; totalTime <= getOmsTimeout(); totalTime += timetoWait) {
					if (isLoggingDebug() && ((totalTime % 1000) == 0)) {
						logDebug("Time=" + totalTime);
					}
					synchronized (notifier) {
						notifier.wait(timetoWait);
					}
					if (omsResponse.isSuccess()) {
						break;
					}
				}
				if (isLoggingDebug()) {
					logDebug("Total Time Waited=" + totalTime);
				}
			} catch (InterruptedException e) {
				if (isLoggingDebug()) {
					logDebug("Thread was interrupted");
				}
				// handle interrupted exception
			}
		} catch (IllegalStateException e) {
			vlogError("Exception occurred while generating OMS Auth Token::" + e);
		}
		return omsResponse;
	}

	/**
	 * SendSQS Message
	 * 
	 * @param executor
	 * 
	 * @param orderNumber
	 * @param string
	 * @return OrderSearchResponse
	 */
	public void sendMessageToQueue(ExecutorService executor, String queueName, String jsonMsg) {
		DXLCatalogFeedSQSWorker worker = new DXLCatalogFeedSQSWorker(queueName, jsonMsg, getOmsWorkerInfo());
		worker.setLoggingDebug(isLoggingDebug());
		executor.execute(worker);
	}

	/**
	 * @return the submitToSQSClient
	 */
	public DXLSQSClient getSubmitToSQSClient() {
		return submitToSQSClient;
	}

	/**
	 * @param submitToSQSClient the submitToSQSClient to set
	 */
	public void setSubmitToSQSClient(DXLSQSClient submitToSQSClient) {
		this.submitToSQSClient = submitToSQSClient;
	}

	/**
	 * @return the queueName
	 */
	public String getQueueName() {
		return queueName;
	}

	/**
	 * @param queueName the queueName to set
	 */
	public void setQueueName(String queueName) {
		this.queueName = queueName;
	}

	/**
	 * @return the globalAppConfig
	 */
	public GlobalApplicationConfiguration getGlobalAppConfig() {
		return globalAppConfig;
	}

	/**
	 * @param globalAppConfig the globalAppConfig to set
	 */
	public void setGlobalAppConfig(GlobalApplicationConfiguration globalAppConfig) {
		this.globalAppConfig = globalAppConfig;
	}

	/**
	 * @return the merchantIdMap
	 */
	public Map<String, String> getMerchantIdMap() {
		return merchantIdMap;
	}

	/**
	 * @param merchantIdMap the merchantIdMap to set
	 */
	public void setMerchantIdMap(Map<String, String> merchantIdMap) {
		this.merchantIdMap = merchantIdMap;
	}

	/**
	 * @return the generalRepositoryTools
	 */
	public GeneralRepositoryTools getGeneralRepositoryTools() {
		return generalRepositoryTools;
	}

	/**
	 * @param generalRepositoryTools the generalRepositoryTools to set
	 */
	public void setGeneralRepositoryTools(GeneralRepositoryTools generalRepositoryTools) {
		this.generalRepositoryTools = generalRepositoryTools;
	}

	/**
	 * @return the creditCardTools
	 */
	public CreditCardTools getCreditCardTools() {
		return creditCardTools;
	}

	/**
	 * @param creditCardTools the creditCardTools to set
	 */
	public void setCreditCardTools(CreditCardTools creditCardTools) {
		this.creditCardTools = creditCardTools;
	}

	/**
	 * @return the orderTools
	 */
	public DXLOrderTools getOrderTools() {
		return orderTools;
	}

	/**
	 * @param orderTools the orderTools to set
	 */
	public void setOrderTools(DXLOrderTools orderTools) {
		this.orderTools = orderTools;
	}

	/**
	 * @return the orderManager
	 */
	public DXLOrderManager getOrderManager() {
		return orderManager;
	}

	/**
	 * @param orderManager the orderManager to set
	 */
	public void setOrderManager(DXLOrderManager orderManager) {
		this.orderManager = orderManager;
	}

	/**
	 * @return the claimableTools
	 */
	public ClaimableTools getClaimableTools() {
		return claimableTools;
	}

	/**
	 * @param claimableTools the claimableTools to set
	 */
	public void setClaimableTools(ClaimableTools claimableTools) {
		this.claimableTools = claimableTools;
	}

	public OMSAuthTokenResponseBean getOmsAuthTokenBean() {
		return omsAuthTokenBean;
	}

	public void setOmsAuthTokenBean(OMSAuthTokenResponseBean omsAuthTokenBean) {
		this.omsAuthTokenBean = omsAuthTokenBean;
	}

	public DXLOMSAccessTokenGenerator getOmsAccessTokenGenerator() {
		return omsAccessTokenGenerator;
	}

	public void setOmsAccessTokenGenerator(DXLOMSAccessTokenGenerator omsAccessTokenGenerator) {
		this.omsAccessTokenGenerator = omsAccessTokenGenerator;
	}

	public long getOmsTimeout() {
		return omsTimeout;
	}

	public void setOmsTimeout(long omsTimeout) {
		this.omsTimeout = omsTimeout;
	}

	public OMSOrderDataPopulator getOrderDataPopulator() {
		return orderDataPopulator;
	}

	public void setOrderDataPopulator(OMSOrderDataPopulator orderDataPopulator) {
		this.orderDataPopulator = orderDataPopulator;
	}

	public Integer getOrderHistorySize() {
		return orderHistorySize;
	}

	public void setOrderHistorySize(Integer orderHistorySize) {
		this.orderHistorySize = orderHistorySize;
	}

	public OMSWorkerInfo getOmsWorkerInfo() {
		return omsWorkerInfo;
	}

	public void setOmsWorkerInfo(OMSWorkerInfo omsWorkerInfo) {
		this.omsWorkerInfo = omsWorkerInfo;
	}
	
	/**
	 * @return the inventoryByLocationDataPopulator
	 */
	public DXLOMSInventoryByLocationDataPopulator getInventoryByLocationDataPopulator() {
		return inventoryByLocationDataPopulator;
	}

	/**
	 * @param inventoryByLocationDataPopulator the inventoryByLocationDataPopulator to set
	 */
	public void setInventoryByLocationDataPopulator(
			DXLOMSInventoryByLocationDataPopulator inventoryByLocationDataPopulator) {
		this.inventoryByLocationDataPopulator = inventoryByLocationDataPopulator;
	}
	
	public List<InventoryData> getInventoryAvailabilityForNetwork(List<String> itemIds, String viewName) {
		vlogDebug("getInventoryAvailabilityForNetwork() - Start");
		
		RetrieveInventoryReqForNetwork omsRequest = getInventoryRequestForNetwork(itemIds,viewName);
		long startTime = 0;
		long endTime = 0;

		if (isLoggingInfo()) {
			startTime = System.currentTimeMillis();
		}

		RetrieveInventoryResponseForNetwork omsResponse = submitInventoryRequestForNetwork(omsRequest);
		if (isLoggingInfo()) {
			endTime = System.currentTimeMillis();
		}
		vlogInfo("Time taken for InventoryAvailabilityForNetwork response is : {0}", endTime - startTime);
		

		InventoryResponseForNetwork inventoryResponseForLocation = null;
		List<InventoryData> inventoryList = null;
		vlogDebug("Response from InventoryAvailabilityForNetwork call ::  {0}", omsResponse.isSuccess());
		if(omsResponse.isSuccess()){
			inventoryResponseForLocation=omsResponse.getInventoryResponseForNetwork();
		}else{
			vlogError("getInventoryAvailabilityForNetwork :: OMS Response for Inventory by Location is Failed");
		}
		if(inventoryResponseForLocation!=null){
			inventoryList = getInventoryByNetworkDataPopulator().populateData(inventoryResponseForLocation);
			vlogDebug("getInventoryAvailabilityForNetwork :: InventoryData list Size is : {0}",inventoryList.size());
		}
		vlogDebug("getInventoryAvailabilityForNetowrk() - End");
		return inventoryList;	
	}

	private RetrieveInventoryReqForNetwork getInventoryRequestForNetwork(List<String> items,String viewName){
		RetrieveInventoryReqForNetwork omsRequest = new RetrieveInventoryReqForNetwork();
		InventoryReqForNetwork inventoryReq = new InventoryReqForNetwork();
		inventoryReq.setItems(items);
		inventoryReq.setViewName(viewName);
		omsRequest.setRequest(inventoryReq);
		return omsRequest;
	}

	private RetrieveInventoryResponseForNetwork submitInventoryRequestForNetwork(RetrieveInventoryReqForNetwork request) {
		RetrieveInventoryResponseForNetwork omsResponse = new RetrieveInventoryResponseForNetwork();
		try {
			DXLOMSInventoryByNetworkWorker worker = new DXLOMSInventoryByNetworkWorker(omsResponse, request, getOmsWorkerInfo());
			worker.setLoggingDebug(isLoggingDebug());
			try {
				long totalTime = 0;
				long timetoWait = 100;
				Object notifier = new Object();

				for (totalTime = 0, timetoWait = 100; totalTime <= getOmsTimeout(); totalTime += timetoWait) {
					if (isLoggingDebug() && ((totalTime % 1000) == 0)) {
						logDebug("Time=" + totalTime);
					}
					synchronized (notifier) {
						notifier.wait(timetoWait);
					}
					if (omsResponse.isSuccess()) {
						break;
					}
				}
				if (isLoggingDebug()) {
					logDebug("Total Time Waited=" + totalTime);
				}
			} catch (InterruptedException e) {
				if (isLoggingDebug()) {
					logDebug("Thread was interrupted");
				}
				// handle interrupted exception
			}
		} catch (IllegalStateException e) {
			vlogError("Exception occurred while generating OMS Auth Token::" + e);
		}
		return omsResponse;
	}

	/**
	 * @return the inventoryByNetworkDataPopulator
	 */
	public DXLOMSInventoryByNetworkDataPopulator getInventoryByNetworkDataPopulator() {
		return inventoryByNetworkDataPopulator;
	}

	/**
	 * @param inventoryByNetworkDataPopulator the inventoryByNetworkDataPopulator to set
	 */
	public void setInventoryByNetworkDataPopulator(DXLOMSInventoryByNetworkDataPopulator inventoryByNetworkDataPopulator) {
		this.inventoryByNetworkDataPopulator = inventoryByNetworkDataPopulator;
	}

}
