package com.dxl.oms.bean.inventory.network;

public class RetrieveInventoryResponseForNetwork {
	
	private InventoryResponseForNetwork InventoryResponseForNetwork;
	private boolean success = false;

	/**
	 * @return the success
	 */
	public boolean isSuccess() {
		return success;
	}

	
	/**
	 * @param success the success to set
	 */
	public void setSuccess(boolean success) {
		this.success = success;
	}


	/**
	 * @return the inventoryResponseForNetwork
	 */
	public InventoryResponseForNetwork getInventoryResponseForNetwork() {
		return InventoryResponseForNetwork;
	}


	/**
	 * @param inventoryResponseForNetwork the inventoryResponseForNetwork to set
	 */
	public void setInventoryResponseForNetwork(InventoryResponseForNetwork inventoryResponseForNetwork) {
		InventoryResponseForNetwork = inventoryResponseForNetwork;
	}

}
