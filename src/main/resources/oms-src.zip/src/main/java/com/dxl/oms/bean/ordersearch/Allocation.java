
package com.dxl.oms.bean.ordersearch;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "ServiceLevelCode",
    "InventorySegmentId",
    "CreatedTimestamp",
    "AllocationId",
    "SubstitutionTypeId",
    "AllocationType",
    "CountryOfOrigin",
    "ShipFromLocationId",
    "EarliestDeliveryDate",
    "AllocatedOn",
    "EarliestShipDate",
    "Process",
    "SubstitutionRatio",
    "InventoryTypeId",
    "ItemId",
    "IsVirtual",
    "UpdatedBy",
    "CommittedDeliveryDate",
    "InventoryAttribute1",
    "InventoryAttribute2",
    "InventoryAttribute3",
    "InventoryAttribute4",
    "InventoryAttribute5",
    "AsnId",
    "AsnDetailId",
    "Status",
    "UpdatedTimestamp",
    "CreatedBy",
    "ShipToLocationId",
    "CommittedShipDate",
    "BatchNumber",
    "LatestShipDate",
    "Quantity",
    "ShipViaId",
    "AllocationDependencyId",
    "GroupId",
    "ProductStatusId",
    "OrgId",
    "UOM",
    "PoDetailId",
    "ReservationRequestDetailId",
    "ContextId",
    "CarrierCode",
    "LatestReleaseDate",
    "PK",
    "PoId",
    "ReservationRequestId"
})
public class Allocation {

    @JsonProperty("ServiceLevelCode")
    private String serviceLevelCode;
    @JsonProperty("InventorySegmentId")
    private Object inventorySegmentId;
    @JsonProperty("CreatedTimestamp")
    private String createdTimestamp;
    @JsonProperty("AllocationId")
    private String allocationId;
    @JsonProperty("SubstitutionTypeId")
    private Object substitutionTypeId;
    @JsonProperty("AllocationType")
    private String allocationType;
    @JsonProperty("CountryOfOrigin")
    private Object countryOfOrigin;
    @JsonProperty("ShipFromLocationId")
    private String shipFromLocationId;
    @JsonProperty("EarliestDeliveryDate")
    private String earliestDeliveryDate;
    @JsonProperty("AllocatedOn")
    private String allocatedOn;
    @JsonProperty("EarliestShipDate")
    private String earliestShipDate;
    @JsonProperty("Process")
    private Object process;
    @JsonProperty("SubstitutionRatio")
    private Object substitutionRatio;
    @JsonProperty("InventoryTypeId")
    private Object inventoryTypeId;
    @JsonProperty("ItemId")
    private String itemId;
    @JsonProperty("IsVirtual")
    private Boolean isVirtual;
    @JsonProperty("UpdatedBy")
    private String updatedBy;
    @JsonProperty("CommittedDeliveryDate")
    private Object committedDeliveryDate;
    @JsonProperty("InventoryAttribute1")
    private Object inventoryAttribute1;
    @JsonProperty("InventoryAttribute2")
    private Object inventoryAttribute2;
    @JsonProperty("InventoryAttribute3")
    private Object inventoryAttribute3;
    @JsonProperty("InventoryAttribute4")
    private Object inventoryAttribute4;
    @JsonProperty("InventoryAttribute5")
    private Object inventoryAttribute5;
    @JsonProperty("AsnId")
    private Object asnId;
    @JsonProperty("AsnDetailId")
    private Object asnDetailId;
    @JsonProperty("Status")
    private Status status;
    @JsonProperty("UpdatedTimestamp")
    private String updatedTimestamp;
    @JsonProperty("CreatedBy")
    private String createdBy;
    @JsonProperty("ShipToLocationId")
    private Object shipToLocationId;
    @JsonProperty("CommittedShipDate")
    private Object committedShipDate;
    @JsonProperty("BatchNumber")
    private Object batchNumber;
    @JsonProperty("LatestShipDate")
    private Object latestShipDate;
    @JsonProperty("Quantity")
    private Integer quantity;
    @JsonProperty("ShipViaId")
    private String shipViaId;
    @JsonProperty("AllocationDependencyId")
    private Object allocationDependencyId;
    @JsonProperty("GroupId")
    private Object groupId;
    @JsonProperty("ProductStatusId")
    private Object productStatusId;
    @JsonProperty("OrgId")
    private String orgId;
    @JsonProperty("UOM")
    private String uOM;
    @JsonProperty("PoDetailId")
    private Object poDetailId;
    @JsonProperty("ReservationRequestDetailId")
    private String reservationRequestDetailId;
    @JsonProperty("ContextId")
    private String contextId;
    @JsonProperty("CarrierCode")
    private String carrierCode;
    @JsonProperty("LatestReleaseDate")
    private Object latestReleaseDate;
    @JsonProperty("PK")
    private String pK;
    @JsonProperty("PoId")
    private Object poId;
    @JsonProperty("ReservationRequestId")
    private String reservationRequestId;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("ServiceLevelCode")
    public String getServiceLevelCode() {
        return serviceLevelCode;
    }

    @JsonProperty("ServiceLevelCode")
    public void setServiceLevelCode(String serviceLevelCode) {
        this.serviceLevelCode = serviceLevelCode;
    }

    @JsonProperty("InventorySegmentId")
    public Object getInventorySegmentId() {
        return inventorySegmentId;
    }

    @JsonProperty("InventorySegmentId")
    public void setInventorySegmentId(Object inventorySegmentId) {
        this.inventorySegmentId = inventorySegmentId;
    }

    @JsonProperty("CreatedTimestamp")
    public String getCreatedTimestamp() {
        return createdTimestamp;
    }

    @JsonProperty("CreatedTimestamp")
    public void setCreatedTimestamp(String createdTimestamp) {
        this.createdTimestamp = createdTimestamp;
    }

    @JsonProperty("AllocationId")
    public String getAllocationId() {
        return allocationId;
    }

    @JsonProperty("AllocationId")
    public void setAllocationId(String allocationId) {
        this.allocationId = allocationId;
    }

    @JsonProperty("SubstitutionTypeId")
    public Object getSubstitutionTypeId() {
        return substitutionTypeId;
    }

    @JsonProperty("SubstitutionTypeId")
    public void setSubstitutionTypeId(Object substitutionTypeId) {
        this.substitutionTypeId = substitutionTypeId;
    }

    @JsonProperty("AllocationType")
    public String getAllocationType() {
        return allocationType;
    }

    @JsonProperty("AllocationType")
    public void setAllocationType(String allocationType) {
        this.allocationType = allocationType;
    }

    @JsonProperty("CountryOfOrigin")
    public Object getCountryOfOrigin() {
        return countryOfOrigin;
    }

    @JsonProperty("CountryOfOrigin")
    public void setCountryOfOrigin(Object countryOfOrigin) {
        this.countryOfOrigin = countryOfOrigin;
    }

    @JsonProperty("ShipFromLocationId")
    public String getShipFromLocationId() {
        return shipFromLocationId;
    }

    @JsonProperty("ShipFromLocationId")
    public void setShipFromLocationId(String shipFromLocationId) {
        this.shipFromLocationId = shipFromLocationId;
    }

    @JsonProperty("EarliestDeliveryDate")
    public String getEarliestDeliveryDate() {
        return earliestDeliveryDate;
    }

    @JsonProperty("EarliestDeliveryDate")
    public void setEarliestDeliveryDate(String earliestDeliveryDate) {
        this.earliestDeliveryDate = earliestDeliveryDate;
    }

    @JsonProperty("AllocatedOn")
    public String getAllocatedOn() {
        return allocatedOn;
    }

    @JsonProperty("AllocatedOn")
    public void setAllocatedOn(String allocatedOn) {
        this.allocatedOn = allocatedOn;
    }

    @JsonProperty("EarliestShipDate")
    public String getEarliestShipDate() {
        return earliestShipDate;
    }

    @JsonProperty("EarliestShipDate")
    public void setEarliestShipDate(String earliestShipDate) {
        this.earliestShipDate = earliestShipDate;
    }

    @JsonProperty("Process")
    public Object getProcess() {
        return process;
    }

    @JsonProperty("Process")
    public void setProcess(Object process) {
        this.process = process;
    }

    @JsonProperty("SubstitutionRatio")
    public Object getSubstitutionRatio() {
        return substitutionRatio;
    }

    @JsonProperty("SubstitutionRatio")
    public void setSubstitutionRatio(Object substitutionRatio) {
        this.substitutionRatio = substitutionRatio;
    }

    @JsonProperty("InventoryTypeId")
    public Object getInventoryTypeId() {
        return inventoryTypeId;
    }

    @JsonProperty("InventoryTypeId")
    public void setInventoryTypeId(Object inventoryTypeId) {
        this.inventoryTypeId = inventoryTypeId;
    }

    @JsonProperty("ItemId")
    public String getItemId() {
        return itemId;
    }

    @JsonProperty("ItemId")
    public void setItemId(String itemId) {
        this.itemId = itemId;
    }

    @JsonProperty("IsVirtual")
    public Boolean getIsVirtual() {
        return isVirtual;
    }

    @JsonProperty("IsVirtual")
    public void setIsVirtual(Boolean isVirtual) {
        this.isVirtual = isVirtual;
    }

    @JsonProperty("UpdatedBy")
    public String getUpdatedBy() {
        return updatedBy;
    }

    @JsonProperty("UpdatedBy")
    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    @JsonProperty("CommittedDeliveryDate")
    public Object getCommittedDeliveryDate() {
        return committedDeliveryDate;
    }

    @JsonProperty("CommittedDeliveryDate")
    public void setCommittedDeliveryDate(Object committedDeliveryDate) {
        this.committedDeliveryDate = committedDeliveryDate;
    }

    @JsonProperty("InventoryAttribute1")
    public Object getInventoryAttribute1() {
        return inventoryAttribute1;
    }

    @JsonProperty("InventoryAttribute1")
    public void setInventoryAttribute1(Object inventoryAttribute1) {
        this.inventoryAttribute1 = inventoryAttribute1;
    }

    @JsonProperty("InventoryAttribute2")
    public Object getInventoryAttribute2() {
        return inventoryAttribute2;
    }

    @JsonProperty("InventoryAttribute2")
    public void setInventoryAttribute2(Object inventoryAttribute2) {
        this.inventoryAttribute2 = inventoryAttribute2;
    }

    @JsonProperty("InventoryAttribute3")
    public Object getInventoryAttribute3() {
        return inventoryAttribute3;
    }

    @JsonProperty("InventoryAttribute3")
    public void setInventoryAttribute3(Object inventoryAttribute3) {
        this.inventoryAttribute3 = inventoryAttribute3;
    }

    @JsonProperty("InventoryAttribute4")
    public Object getInventoryAttribute4() {
        return inventoryAttribute4;
    }

    @JsonProperty("InventoryAttribute4")
    public void setInventoryAttribute4(Object inventoryAttribute4) {
        this.inventoryAttribute4 = inventoryAttribute4;
    }

    @JsonProperty("InventoryAttribute5")
    public Object getInventoryAttribute5() {
        return inventoryAttribute5;
    }

    @JsonProperty("InventoryAttribute5")
    public void setInventoryAttribute5(Object inventoryAttribute5) {
        this.inventoryAttribute5 = inventoryAttribute5;
    }

    @JsonProperty("AsnId")
    public Object getAsnId() {
        return asnId;
    }

    @JsonProperty("AsnId")
    public void setAsnId(Object asnId) {
        this.asnId = asnId;
    }

    @JsonProperty("AsnDetailId")
    public Object getAsnDetailId() {
        return asnDetailId;
    }

    @JsonProperty("AsnDetailId")
    public void setAsnDetailId(Object asnDetailId) {
        this.asnDetailId = asnDetailId;
    }

    @JsonProperty("Status")
    public Status getStatus() {
        return status;
    }

    @JsonProperty("Status")
    public void setStatus(Status status) {
        this.status = status;
    }

    @JsonProperty("UpdatedTimestamp")
    public String getUpdatedTimestamp() {
        return updatedTimestamp;
    }

    @JsonProperty("UpdatedTimestamp")
    public void setUpdatedTimestamp(String updatedTimestamp) {
        this.updatedTimestamp = updatedTimestamp;
    }

    @JsonProperty("CreatedBy")
    public String getCreatedBy() {
        return createdBy;
    }

    @JsonProperty("CreatedBy")
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    @JsonProperty("ShipToLocationId")
    public Object getShipToLocationId() {
        return shipToLocationId;
    }

    @JsonProperty("ShipToLocationId")
    public void setShipToLocationId(Object shipToLocationId) {
        this.shipToLocationId = shipToLocationId;
    }

    @JsonProperty("CommittedShipDate")
    public Object getCommittedShipDate() {
        return committedShipDate;
    }

    @JsonProperty("CommittedShipDate")
    public void setCommittedShipDate(Object committedShipDate) {
        this.committedShipDate = committedShipDate;
    }

    @JsonProperty("BatchNumber")
    public Object getBatchNumber() {
        return batchNumber;
    }

    @JsonProperty("BatchNumber")
    public void setBatchNumber(Object batchNumber) {
        this.batchNumber = batchNumber;
    }

    @JsonProperty("LatestShipDate")
    public Object getLatestShipDate() {
        return latestShipDate;
    }

    @JsonProperty("LatestShipDate")
    public void setLatestShipDate(Object latestShipDate) {
        this.latestShipDate = latestShipDate;
    }

    @JsonProperty("Quantity")
    public Integer getQuantity() {
        return quantity;
    }

    @JsonProperty("Quantity")
    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    @JsonProperty("ShipViaId")
    public String getShipViaId() {
        return shipViaId;
    }

    @JsonProperty("ShipViaId")
    public void setShipViaId(String shipViaId) {
        this.shipViaId = shipViaId;
    }

    @JsonProperty("AllocationDependencyId")
    public Object getAllocationDependencyId() {
        return allocationDependencyId;
    }

    @JsonProperty("AllocationDependencyId")
    public void setAllocationDependencyId(Object allocationDependencyId) {
        this.allocationDependencyId = allocationDependencyId;
    }

    @JsonProperty("GroupId")
    public Object getGroupId() {
        return groupId;
    }

    @JsonProperty("GroupId")
    public void setGroupId(Object groupId) {
        this.groupId = groupId;
    }

    @JsonProperty("ProductStatusId")
    public Object getProductStatusId() {
        return productStatusId;
    }

    @JsonProperty("ProductStatusId")
    public void setProductStatusId(Object productStatusId) {
        this.productStatusId = productStatusId;
    }

    @JsonProperty("OrgId")
    public String getOrgId() {
        return orgId;
    }

    @JsonProperty("OrgId")
    public void setOrgId(String orgId) {
        this.orgId = orgId;
    }

    @JsonProperty("UOM")
    public String getUOM() {
        return uOM;
    }

    @JsonProperty("UOM")
    public void setUOM(String uOM) {
        this.uOM = uOM;
    }

    @JsonProperty("PoDetailId")
    public Object getPoDetailId() {
        return poDetailId;
    }

    @JsonProperty("PoDetailId")
    public void setPoDetailId(Object poDetailId) {
        this.poDetailId = poDetailId;
    }

    @JsonProperty("ReservationRequestDetailId")
    public String getReservationRequestDetailId() {
        return reservationRequestDetailId;
    }

    @JsonProperty("ReservationRequestDetailId")
    public void setReservationRequestDetailId(String reservationRequestDetailId) {
        this.reservationRequestDetailId = reservationRequestDetailId;
    }

    @JsonProperty("ContextId")
    public String getContextId() {
        return contextId;
    }

    @JsonProperty("ContextId")
    public void setContextId(String contextId) {
        this.contextId = contextId;
    }

    @JsonProperty("CarrierCode")
    public String getCarrierCode() {
        return carrierCode;
    }

    @JsonProperty("CarrierCode")
    public void setCarrierCode(String carrierCode) {
        this.carrierCode = carrierCode;
    }

    @JsonProperty("LatestReleaseDate")
    public Object getLatestReleaseDate() {
        return latestReleaseDate;
    }

    @JsonProperty("LatestReleaseDate")
    public void setLatestReleaseDate(Object latestReleaseDate) {
        this.latestReleaseDate = latestReleaseDate;
    }

    @JsonProperty("PK")
    public String getPK() {
        return pK;
    }

    @JsonProperty("PK")
    public void setPK(String pK) {
        this.pK = pK;
    }

    @JsonProperty("PoId")
    public Object getPoId() {
        return poId;
    }

    @JsonProperty("PoId")
    public void setPoId(Object poId) {
        this.poId = poId;
    }

    @JsonProperty("ReservationRequestId")
    public String getReservationRequestId() {
        return reservationRequestId;
    }

    @JsonProperty("ReservationRequestId")
    public void setReservationRequestId(String reservationRequestId) {
        this.reservationRequestId = reservationRequestId;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
