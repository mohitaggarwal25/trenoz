
package com.dxl.oms.bean.ordersearch;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "Messages", "PostVoidReason", "SuspendedOrderId", "Invoice", "CreatedTimestamp", "BusinessDate", "TaxOverrideValue",
		"MaxFulfillmentStatusId", "TaxExemptReason", "CurrencyCode", "CustomerPhone", "EventSubmitTime", "UpdatedBy", "CustomerFirstName", "RefundRecipient",
		"TaxExemptId", "OrderLineCount", "OrderHold", "IsArchiveInProgress", "IsCapturedOffline", "CreatedBy", "IsCancelled", "OrderExtension5", "CustomerId",
		"OrderExtension3", "OrderExtension4", "OrderExtension1", "IsTaxExempt", "OrderExtension2", "MaxReturnStatus", "ParentReservationRequestId",
		"OrderTrackingInfo", "ContextId", "ReturnLabel", "ArchiveDate", "LoyaltyNumber", "TaxOverrideReason", "StoreSaleCount", "MinReturnStatusId",
		"IsTaxOverridden", "IsPostVoided", "AlternateOrderId", "CancelledOrderSubTotal", "OrderLine", "CustomerEmail", "DoNotReleaseBefore", "OrderNote",
		"OrderAttribute", "MinFulfillmentStatusId", "DocType", "PublishStatus", "MinFulfillmentStatus", "UpdatedTimestamp", "ReturnLabelEmail",
		"ProcessReturnReason", "TaxOverrideType", "ProcessReturnComments", "CancelledTotalDiscounts", "OrderMilestoneEvent", "MerchSaleLineCount",
		"CustomerIdentityDoc", "OrgId", "MaxAppeasementAmount", "IsOrderCountable", "CustomerLastName", "ReturnStatus", "CapturedDate", "CustomerTypeId",
		"NextEventTime", "ChangeLog", "TotalDiscounts", "CancelLineCount", "ReturnTrackingDetail", "IsOnHold", "Process", "IsConfirmed", "RefundPaymentMethod",
		"SellingLocationId", "FulfillmentStatus", "OrderChargeDetail", "OrderType", "TotalReturnFees", "CountedDate", "TotalCharges", "ReturnLineCount",
		"PaymentStatus", "OrderSalesAssociate", "Priority", "StoreReturnCount", "OrderTagDetail", "OrderId", "OrderSubTotal", "OrderCaptureDetail",
		"CancelReason", "ContactPreference", "OrderPromotionRequest", "ConfirmedDate", "IsReadyForTender", "CustomerAddress", "TransactionReference",
		"TaxExemptComments", "CancelledOrderTotal", "OrderPromisingInfo", "MinReturnStatus", "OrderTaxDetail", "PackageCount", "SellingChannel", "Release",
		"ReturnTotalWithoutFees", "MaxReturnStatusId", "MerchReturnLineCount", "ProcessInfo", "CancelComments", "MaxFulfillmentStatus", "OrderMilestone",
		"TotalTaxes", "PK", "OrderTotal", "Payment" })
public class Data {

	@JsonProperty("Messages")
	private Object messages;
	@JsonProperty("PostVoidReason")
	private Object postVoidReason;
	@JsonProperty("SuspendedOrderId")
	private Object suspendedOrderId;
	@JsonProperty("Invoice")
	private List<Invoice> invoice = null;
	@JsonProperty("CreatedTimestamp")
	private String createdTimestamp;
	@JsonProperty("BusinessDate")
	private Object businessDate;
	@JsonProperty("TaxOverrideValue")
	private Object taxOverrideValue;
	@JsonProperty("MaxFulfillmentStatusId")
	private String maxFulfillmentStatusId;
	@JsonProperty("TaxExemptReason")
	private Object taxExemptReason;
	@JsonProperty("CurrencyCode")
	private String currencyCode;
	@JsonProperty("CustomerPhone")
	private String customerPhone;
	@JsonProperty("EventSubmitTime")
	private String eventSubmitTime;
	@JsonProperty("UpdatedBy")
	private String updatedBy;
	@JsonProperty("CustomerFirstName")
	private String customerFirstName;
	@JsonProperty("RefundRecipient")
	private RefundRecipient refundRecipient;
	@JsonProperty("TaxExemptId")
	private Object taxExemptId;
	@JsonProperty("OrderLineCount")
	private Integer orderLineCount;
	@JsonProperty("OrderHold")
	private List<Object> orderHold = null;
	@JsonProperty("IsArchiveInProgress")
	private Boolean isArchiveInProgress;
	@JsonProperty("IsCapturedOffline")
	private Boolean isCapturedOffline;
	@JsonProperty("CreatedBy")
	private String createdBy;
	@JsonProperty("IsCancelled")
	private Boolean isCancelled;
	@JsonProperty("OrderExtension5")
	private List<Object> orderExtension5 = null;
	@JsonProperty("CustomerId")
	private String customerId;
	@JsonProperty("OrderExtension3")
	private List<Object> orderExtension3 = null;
	@JsonProperty("OrderExtension4")
	private List<Object> orderExtension4 = null;
	@JsonProperty("OrderExtension1")
	private Object orderExtension1;
	@JsonProperty("IsTaxExempt")
	private Boolean isTaxExempt;
	@JsonProperty("OrderExtension2")
	private List<Object> orderExtension2 = null;
	@JsonProperty("MaxReturnStatus")
	private Object maxReturnStatus;
	@JsonProperty("ParentReservationRequestId")
	private Object parentReservationRequestId;
	@JsonProperty("OrderTrackingInfo")
	private List<OrderTrackingInfo> orderTrackingInfo = null;
	@JsonProperty("ContextId")
	private String contextId;
	@JsonProperty("ReturnLabel")
	private List<Object> returnLabel = null;
	@JsonProperty("ArchiveDate")
	private String archiveDate;
	@JsonProperty("LoyaltyNumber")
	private Object loyaltyNumber;
	@JsonProperty("TaxOverrideReason")
	private Object taxOverrideReason;
	@JsonProperty("StoreSaleCount")
	private Integer storeSaleCount;
	@JsonProperty("MinReturnStatusId")
	private Object minReturnStatusId;
	@JsonProperty("IsTaxOverridden")
	private Boolean isTaxOverridden;
	@JsonProperty("IsPostVoided")
	private Boolean isPostVoided;
	@JsonProperty("AlternateOrderId")
	private Object alternateOrderId;
	@JsonProperty("CancelledOrderSubTotal")
	private Object cancelledOrderSubTotal;
	@JsonProperty("OrderLine")
	private List<OrderLine> orderLine = null;
	@JsonProperty("CustomerEmail")
	private String customerEmail;
	@JsonProperty("DoNotReleaseBefore")
	private String doNotReleaseBefore;
	@JsonProperty("OrderNote")
	private List<Object> orderNote = null;
	@JsonProperty("OrderAttribute")
	private List<Object> orderAttribute = null;
	@JsonProperty("MinFulfillmentStatusId")
	private String minFulfillmentStatusId;
	@JsonProperty("DocType")
	private DocType docType;
	@JsonProperty("PublishStatus")
	private PublishStatus_ publishStatus;
	@JsonProperty("MinFulfillmentStatus")
	private MinFulfillmentStatus_ minFulfillmentStatus;
	@JsonProperty("UpdatedTimestamp")
	private String updatedTimestamp;
	@JsonProperty("ReturnLabelEmail")
	private Object returnLabelEmail;
	@JsonProperty("ProcessReturnReason")
	private Object processReturnReason;
	@JsonProperty("TaxOverrideType")
	private Object taxOverrideType;
	@JsonProperty("ProcessReturnComments")
	private Object processReturnComments;
	@JsonProperty("CancelledTotalDiscounts")
	private Object cancelledTotalDiscounts;
	@JsonProperty("OrderMilestoneEvent")
	private List<Object> orderMilestoneEvent = null;
	@JsonProperty("MerchSaleLineCount")
	private Integer merchSaleLineCount;
	@JsonProperty("CustomerIdentityDoc")
	private List<Object> customerIdentityDoc = null;
	@JsonProperty("OrgId")
	private String orgId;
	@JsonProperty("MaxAppeasementAmount")
	private Double maxAppeasementAmount;
	@JsonProperty("IsOrderCountable")
	private Boolean isOrderCountable;
	@JsonProperty("CustomerLastName")
	private String customerLastName;
	@JsonProperty("ReturnStatus")
	private Object returnStatus;
	@JsonProperty("CapturedDate")
	private Object capturedDate;
	@JsonProperty("CustomerTypeId")
	private Object customerTypeId;
	@JsonProperty("NextEventTime")
	private String nextEventTime;
	@JsonProperty("ChangeLog")
	private Object changeLog;
	@JsonProperty("TotalDiscounts")
	private Object totalDiscounts;
	@JsonProperty("CancelLineCount")
	private Integer cancelLineCount;
	@JsonProperty("ReturnTrackingDetail")
	private List<Object> returnTrackingDetail = null;
	@JsonProperty("IsOnHold")
	private Boolean isOnHold;
	@JsonProperty("Process")
	private Object process;
	@JsonProperty("IsConfirmed")
	private Boolean isConfirmed;
	@JsonProperty("RefundPaymentMethod")
	private Object refundPaymentMethod;
	@JsonProperty("SellingLocationId")
	private Object sellingLocationId;
	@JsonProperty("FulfillmentStatus")
	private String fulfillmentStatus;
	@JsonProperty("OrderChargeDetail")
	private List<OrderChargeDetail_> orderChargeDetail = null;
	@JsonProperty("OrderType")
	private OrderType orderType;
	@JsonProperty("TotalReturnFees")
	private Integer totalReturnFees;
	@JsonProperty("CountedDate")
	private String countedDate;
	@JsonProperty("TotalCharges")
	private Object totalCharges;
	@JsonProperty("ReturnLineCount")
	private Integer returnLineCount;
	@JsonProperty("PaymentStatus")
	private PaymentStatus paymentStatus;
	@JsonProperty("OrderSalesAssociate")
	private List<Object> orderSalesAssociate = null;
	@JsonProperty("Priority")
	private Object priority;
	@JsonProperty("StoreReturnCount")
	private Integer storeReturnCount;
	@JsonProperty("OrderTagDetail")
	private List<Object> orderTagDetail = null;
	@JsonProperty("OrderId")
	private String orderId;
	@JsonProperty("OrderSubTotal")
	private Double orderSubTotal;
	@JsonProperty("OrderCaptureDetail")
	private List<Object> orderCaptureDetail = null;
	@JsonProperty("CancelReason")
	private Object cancelReason;
	@JsonProperty("ContactPreference")
	private List<Object> contactPreference = null;
	@JsonProperty("OrderPromotionRequest")
	private List<Object> orderPromotionRequest = null;
	@JsonProperty("ConfirmedDate")
	private Object confirmedDate;
	@JsonProperty("IsReadyForTender")
	private Boolean isReadyForTender;
	@JsonProperty("CustomerAddress")
	private Object customerAddress;
	@JsonProperty("TransactionReference")
	private List<Object> transactionReference = null;
	@JsonProperty("TaxExemptComments")
	private Object taxExemptComments;
	@JsonProperty("CancelledOrderTotal")
	private Object cancelledOrderTotal;
	@JsonProperty("OrderPromisingInfo")
	private Object orderPromisingInfo;
	@JsonProperty("MinReturnStatus")
	private Object minReturnStatus;
	@JsonProperty("OrderTaxDetail")
	private List<Object> orderTaxDetail = null;
	@JsonProperty("PackageCount")
	private Object packageCount;
	@JsonProperty("SellingChannel")
	private SellingChannel sellingChannel;
	@JsonProperty("Release")
	private List<Release> release = null;
	@JsonProperty("ReturnTotalWithoutFees")
	private Integer returnTotalWithoutFees;
	@JsonProperty("MaxReturnStatusId")
	private Object maxReturnStatusId;
	@JsonProperty("MerchReturnLineCount")
	private Integer merchReturnLineCount;
	@JsonProperty("ProcessInfo")
	private Object processInfo;
	@JsonProperty("CancelComments")
	private Object cancelComments;
	@JsonProperty("MaxFulfillmentStatus")
	private MaxFulfillmentStatus_ maxFulfillmentStatus;
	@JsonProperty("OrderMilestone")
	private List<OrderMilestone> orderMilestone = null;
	@JsonProperty("TotalTaxes")
	private Double totalTaxes;
	@JsonProperty("PK")
	private String pK;
	@JsonProperty("OrderTotal")
	private Double orderTotal;
	@JsonProperty("Payment")
	private List<Payment> payment = null;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	@JsonProperty("Messages")
	public Object getMessages() {
		return messages;
	}

	@JsonProperty("Messages")
	public void setMessages(Object messages) {
		this.messages = messages;
	}

	@JsonProperty("PostVoidReason")
	public Object getPostVoidReason() {
		return postVoidReason;
	}

	@JsonProperty("PostVoidReason")
	public void setPostVoidReason(Object postVoidReason) {
		this.postVoidReason = postVoidReason;
	}

	@JsonProperty("SuspendedOrderId")
	public Object getSuspendedOrderId() {
		return suspendedOrderId;
	}

	@JsonProperty("SuspendedOrderId")
	public void setSuspendedOrderId(Object suspendedOrderId) {
		this.suspendedOrderId = suspendedOrderId;
	}

	@JsonProperty("Invoice")
	public List<Invoice> getInvoice() {
		return invoice;
	}

	@JsonProperty("Invoice")
	public void setInvoice(List<Invoice> invoice) {
		this.invoice = invoice;
	}

	@JsonProperty("CreatedTimestamp")
	public String getCreatedTimestamp() {
		return createdTimestamp;
	}

	@JsonProperty("CreatedTimestamp")
	public void setCreatedTimestamp(String createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}

	@JsonProperty("BusinessDate")
	public Object getBusinessDate() {
		return businessDate;
	}

	@JsonProperty("BusinessDate")
	public void setBusinessDate(Object businessDate) {
		this.businessDate = businessDate;
	}

	@JsonProperty("TaxOverrideValue")
	public Object getTaxOverrideValue() {
		return taxOverrideValue;
	}

	@JsonProperty("TaxOverrideValue")
	public void setTaxOverrideValue(Object taxOverrideValue) {
		this.taxOverrideValue = taxOverrideValue;
	}

	@JsonProperty("MaxFulfillmentStatusId")
	public String getMaxFulfillmentStatusId() {
		return maxFulfillmentStatusId;
	}

	@JsonProperty("MaxFulfillmentStatusId")
	public void setMaxFulfillmentStatusId(String maxFulfillmentStatusId) {
		this.maxFulfillmentStatusId = maxFulfillmentStatusId;
	}

	@JsonProperty("TaxExemptReason")
	public Object getTaxExemptReason() {
		return taxExemptReason;
	}

	@JsonProperty("TaxExemptReason")
	public void setTaxExemptReason(Object taxExemptReason) {
		this.taxExemptReason = taxExemptReason;
	}

	@JsonProperty("CurrencyCode")
	public String getCurrencyCode() {
		return currencyCode;
	}

	@JsonProperty("CurrencyCode")
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	@JsonProperty("CustomerPhone")
	public String getCustomerPhone() {
		return customerPhone;
	}

	@JsonProperty("CustomerPhone")
	public void setCustomerPhone(String customerPhone) {
		this.customerPhone = customerPhone;
	}

	@JsonProperty("EventSubmitTime")
	public String getEventSubmitTime() {
		return eventSubmitTime;
	}

	@JsonProperty("EventSubmitTime")
	public void setEventSubmitTime(String eventSubmitTime) {
		this.eventSubmitTime = eventSubmitTime;
	}

	@JsonProperty("UpdatedBy")
	public String getUpdatedBy() {
		return updatedBy;
	}

	@JsonProperty("UpdatedBy")
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	@JsonProperty("CustomerFirstName")
	public String getCustomerFirstName() {
		return customerFirstName;
	}

	@JsonProperty("CustomerFirstName")
	public void setCustomerFirstName(String customerFirstName) {
		this.customerFirstName = customerFirstName;
	}

	@JsonProperty("RefundRecipient")
	public RefundRecipient getRefundRecipient() {
		return refundRecipient;
	}

	@JsonProperty("RefundRecipient")
	public void setRefundRecipient(RefundRecipient refundRecipient) {
		this.refundRecipient = refundRecipient;
	}

	@JsonProperty("TaxExemptId")
	public Object getTaxExemptId() {
		return taxExemptId;
	}

	@JsonProperty("TaxExemptId")
	public void setTaxExemptId(Object taxExemptId) {
		this.taxExemptId = taxExemptId;
	}

	@JsonProperty("OrderLineCount")
	public Integer getOrderLineCount() {
		return orderLineCount;
	}

	@JsonProperty("OrderLineCount")
	public void setOrderLineCount(Integer orderLineCount) {
		this.orderLineCount = orderLineCount;
	}

	@JsonProperty("OrderHold")
	public List<Object> getOrderHold() {
		return orderHold;
	}

	@JsonProperty("OrderHold")
	public void setOrderHold(List<Object> orderHold) {
		this.orderHold = orderHold;
	}

	@JsonProperty("IsArchiveInProgress")
	public Boolean getIsArchiveInProgress() {
		return isArchiveInProgress;
	}

	@JsonProperty("IsArchiveInProgress")
	public void setIsArchiveInProgress(Boolean isArchiveInProgress) {
		this.isArchiveInProgress = isArchiveInProgress;
	}

	@JsonProperty("IsCapturedOffline")
	public Boolean getIsCapturedOffline() {
		return isCapturedOffline;
	}

	@JsonProperty("IsCapturedOffline")
	public void setIsCapturedOffline(Boolean isCapturedOffline) {
		this.isCapturedOffline = isCapturedOffline;
	}

	@JsonProperty("CreatedBy")
	public String getCreatedBy() {
		return createdBy;
	}

	@JsonProperty("CreatedBy")
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	@JsonProperty("IsCancelled")
	public Boolean getIsCancelled() {
		return isCancelled;
	}

	@JsonProperty("IsCancelled")
	public void setIsCancelled(Boolean isCancelled) {
		this.isCancelled = isCancelled;
	}

	@JsonProperty("OrderExtension5")
	public List<Object> getOrderExtension5() {
		return orderExtension5;
	}

	@JsonProperty("OrderExtension5")
	public void setOrderExtension5(List<Object> orderExtension5) {
		this.orderExtension5 = orderExtension5;
	}

	@JsonProperty("CustomerId")
	public String getCustomerId() {
		return customerId;
	}

	@JsonProperty("CustomerId")
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	@JsonProperty("OrderExtension3")
	public List<Object> getOrderExtension3() {
		return orderExtension3;
	}

	@JsonProperty("OrderExtension3")
	public void setOrderExtension3(List<Object> orderExtension3) {
		this.orderExtension3 = orderExtension3;
	}

	@JsonProperty("OrderExtension4")
	public List<Object> getOrderExtension4() {
		return orderExtension4;
	}

	@JsonProperty("OrderExtension4")
	public void setOrderExtension4(List<Object> orderExtension4) {
		this.orderExtension4 = orderExtension4;
	}

	@JsonProperty("OrderExtension1")
	public Object getOrderExtension1() {
		return orderExtension1;
	}

	@JsonProperty("OrderExtension1")
	public void setOrderExtension1(Object orderExtension1) {
		this.orderExtension1 = orderExtension1;
	}

	@JsonProperty("IsTaxExempt")
	public Boolean getIsTaxExempt() {
		return isTaxExempt;
	}

	@JsonProperty("IsTaxExempt")
	public void setIsTaxExempt(Boolean isTaxExempt) {
		this.isTaxExempt = isTaxExempt;
	}

	@JsonProperty("OrderExtension2")
	public List<Object> getOrderExtension2() {
		return orderExtension2;
	}

	@JsonProperty("OrderExtension2")
	public void setOrderExtension2(List<Object> orderExtension2) {
		this.orderExtension2 = orderExtension2;
	}

	@JsonProperty("MaxReturnStatus")
	public Object getMaxReturnStatus() {
		return maxReturnStatus;
	}

	@JsonProperty("MaxReturnStatus")
	public void setMaxReturnStatus(Object maxReturnStatus) {
		this.maxReturnStatus = maxReturnStatus;
	}

	@JsonProperty("ParentReservationRequestId")
	public Object getParentReservationRequestId() {
		return parentReservationRequestId;
	}

	@JsonProperty("ParentReservationRequestId")
	public void setParentReservationRequestId(Object parentReservationRequestId) {
		this.parentReservationRequestId = parentReservationRequestId;
	}

	@JsonProperty("OrderTrackingInfo")
	public List<OrderTrackingInfo> getOrderTrackingInfo() {
		return orderTrackingInfo;
	}

	@JsonProperty("OrderTrackingInfo")
	public void setOrderTrackingInfo(List<OrderTrackingInfo> orderTrackingInfo) {
		this.orderTrackingInfo = orderTrackingInfo;
	}

	@JsonProperty("ContextId")
	public String getContextId() {
		return contextId;
	}

	@JsonProperty("ContextId")
	public void setContextId(String contextId) {
		this.contextId = contextId;
	}

	@JsonProperty("ReturnLabel")
	public List<Object> getReturnLabel() {
		return returnLabel;
	}

	@JsonProperty("ReturnLabel")
	public void setReturnLabel(List<Object> returnLabel) {
		this.returnLabel = returnLabel;
	}

	@JsonProperty("ArchiveDate")
	public String getArchiveDate() {
		return archiveDate;
	}

	@JsonProperty("ArchiveDate")
	public void setArchiveDate(String archiveDate) {
		this.archiveDate = archiveDate;
	}

	@JsonProperty("LoyaltyNumber")
	public Object getLoyaltyNumber() {
		return loyaltyNumber;
	}

	@JsonProperty("LoyaltyNumber")
	public void setLoyaltyNumber(Object loyaltyNumber) {
		this.loyaltyNumber = loyaltyNumber;
	}

	@JsonProperty("TaxOverrideReason")
	public Object getTaxOverrideReason() {
		return taxOverrideReason;
	}

	@JsonProperty("TaxOverrideReason")
	public void setTaxOverrideReason(Object taxOverrideReason) {
		this.taxOverrideReason = taxOverrideReason;
	}

	@JsonProperty("StoreSaleCount")
	public Integer getStoreSaleCount() {
		return storeSaleCount;
	}

	@JsonProperty("StoreSaleCount")
	public void setStoreSaleCount(Integer storeSaleCount) {
		this.storeSaleCount = storeSaleCount;
	}

	@JsonProperty("MinReturnStatusId")
	public Object getMinReturnStatusId() {
		return minReturnStatusId;
	}

	@JsonProperty("MinReturnStatusId")
	public void setMinReturnStatusId(Object minReturnStatusId) {
		this.minReturnStatusId = minReturnStatusId;
	}

	@JsonProperty("IsTaxOverridden")
	public Boolean getIsTaxOverridden() {
		return isTaxOverridden;
	}

	@JsonProperty("IsTaxOverridden")
	public void setIsTaxOverridden(Boolean isTaxOverridden) {
		this.isTaxOverridden = isTaxOverridden;
	}

	@JsonProperty("IsPostVoided")
	public Boolean getIsPostVoided() {
		return isPostVoided;
	}

	@JsonProperty("IsPostVoided")
	public void setIsPostVoided(Boolean isPostVoided) {
		this.isPostVoided = isPostVoided;
	}

	@JsonProperty("AlternateOrderId")
	public Object getAlternateOrderId() {
		return alternateOrderId;
	}

	@JsonProperty("AlternateOrderId")
	public void setAlternateOrderId(Object alternateOrderId) {
		this.alternateOrderId = alternateOrderId;
	}

	@JsonProperty("CancelledOrderSubTotal")
	public Object getCancelledOrderSubTotal() {
		return cancelledOrderSubTotal;
	}

	@JsonProperty("CancelledOrderSubTotal")
	public void setCancelledOrderSubTotal(Object cancelledOrderSubTotal) {
		this.cancelledOrderSubTotal = cancelledOrderSubTotal;
	}

	@JsonProperty("OrderLine")
	public List<OrderLine> getOrderLine() {
		return orderLine;
	}

	@JsonProperty("OrderLine")
	public void setOrderLine(List<OrderLine> orderLine) {
		this.orderLine = orderLine;
	}

	@JsonProperty("CustomerEmail")
	public String getCustomerEmail() {
		return customerEmail;
	}

	@JsonProperty("CustomerEmail")
	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}

	@JsonProperty("DoNotReleaseBefore")
	public String getDoNotReleaseBefore() {
		return doNotReleaseBefore;
	}

	@JsonProperty("DoNotReleaseBefore")
	public void setDoNotReleaseBefore(String doNotReleaseBefore) {
		this.doNotReleaseBefore = doNotReleaseBefore;
	}

	@JsonProperty("OrderNote")
	public List<Object> getOrderNote() {
		return orderNote;
	}

	@JsonProperty("OrderNote")
	public void setOrderNote(List<Object> orderNote) {
		this.orderNote = orderNote;
	}

	@JsonProperty("OrderAttribute")
	public List<Object> getOrderAttribute() {
		return orderAttribute;
	}

	@JsonProperty("OrderAttribute")
	public void setOrderAttribute(List<Object> orderAttribute) {
		this.orderAttribute = orderAttribute;
	}

	@JsonProperty("MinFulfillmentStatusId")
	public String getMinFulfillmentStatusId() {
		return minFulfillmentStatusId;
	}

	@JsonProperty("MinFulfillmentStatusId")
	public void setMinFulfillmentStatusId(String minFulfillmentStatusId) {
		this.minFulfillmentStatusId = minFulfillmentStatusId;
	}

	@JsonProperty("DocType")
	public DocType getDocType() {
		return docType;
	}

	@JsonProperty("DocType")
	public void setDocType(DocType docType) {
		this.docType = docType;
	}

	@JsonProperty("PublishStatus")
	public PublishStatus_ getPublishStatus() {
		return publishStatus;
	}

	@JsonProperty("PublishStatus")
	public void setPublishStatus(PublishStatus_ publishStatus) {
		this.publishStatus = publishStatus;
	}

	@JsonProperty("MinFulfillmentStatus")
	public MinFulfillmentStatus_ getMinFulfillmentStatus() {
		return minFulfillmentStatus;
	}

	@JsonProperty("MinFulfillmentStatus")
	public void setMinFulfillmentStatus(MinFulfillmentStatus_ minFulfillmentStatus) {
		this.minFulfillmentStatus = minFulfillmentStatus;
	}

	@JsonProperty("UpdatedTimestamp")
	public String getUpdatedTimestamp() {
		return updatedTimestamp;
	}

	@JsonProperty("UpdatedTimestamp")
	public void setUpdatedTimestamp(String updatedTimestamp) {
		this.updatedTimestamp = updatedTimestamp;
	}

	@JsonProperty("ReturnLabelEmail")
	public Object getReturnLabelEmail() {
		return returnLabelEmail;
	}

	@JsonProperty("ReturnLabelEmail")
	public void setReturnLabelEmail(Object returnLabelEmail) {
		this.returnLabelEmail = returnLabelEmail;
	}

	@JsonProperty("ProcessReturnReason")
	public Object getProcessReturnReason() {
		return processReturnReason;
	}

	@JsonProperty("ProcessReturnReason")
	public void setProcessReturnReason(Object processReturnReason) {
		this.processReturnReason = processReturnReason;
	}

	@JsonProperty("TaxOverrideType")
	public Object getTaxOverrideType() {
		return taxOverrideType;
	}

	@JsonProperty("TaxOverrideType")
	public void setTaxOverrideType(Object taxOverrideType) {
		this.taxOverrideType = taxOverrideType;
	}

	@JsonProperty("ProcessReturnComments")
	public Object getProcessReturnComments() {
		return processReturnComments;
	}

	@JsonProperty("ProcessReturnComments")
	public void setProcessReturnComments(Object processReturnComments) {
		this.processReturnComments = processReturnComments;
	}

	@JsonProperty("CancelledTotalDiscounts")
	public Object getCancelledTotalDiscounts() {
		return cancelledTotalDiscounts;
	}

	@JsonProperty("CancelledTotalDiscounts")
	public void setCancelledTotalDiscounts(Object cancelledTotalDiscounts) {
		this.cancelledTotalDiscounts = cancelledTotalDiscounts;
	}

	@JsonProperty("OrderMilestoneEvent")
	public List<Object> getOrderMilestoneEvent() {
		return orderMilestoneEvent;
	}

	@JsonProperty("OrderMilestoneEvent")
	public void setOrderMilestoneEvent(List<Object> orderMilestoneEvent) {
		this.orderMilestoneEvent = orderMilestoneEvent;
	}

	@JsonProperty("MerchSaleLineCount")
	public Integer getMerchSaleLineCount() {
		return merchSaleLineCount;
	}

	@JsonProperty("MerchSaleLineCount")
	public void setMerchSaleLineCount(Integer merchSaleLineCount) {
		this.merchSaleLineCount = merchSaleLineCount;
	}

	@JsonProperty("CustomerIdentityDoc")
	public List<Object> getCustomerIdentityDoc() {
		return customerIdentityDoc;
	}

	@JsonProperty("CustomerIdentityDoc")
	public void setCustomerIdentityDoc(List<Object> customerIdentityDoc) {
		this.customerIdentityDoc = customerIdentityDoc;
	}

	@JsonProperty("OrgId")
	public String getOrgId() {
		return orgId;
	}

	@JsonProperty("OrgId")
	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}

	@JsonProperty("MaxAppeasementAmount")
	public Double getMaxAppeasementAmount() {
		return maxAppeasementAmount;
	}

	@JsonProperty("MaxAppeasementAmount")
	public void setMaxAppeasementAmount(Double maxAppeasementAmount) {
		this.maxAppeasementAmount = maxAppeasementAmount;
	}

	@JsonProperty("IsOrderCountable")
	public Boolean getIsOrderCountable() {
		return isOrderCountable;
	}

	@JsonProperty("IsOrderCountable")
	public void setIsOrderCountable(Boolean isOrderCountable) {
		this.isOrderCountable = isOrderCountable;
	}

	@JsonProperty("CustomerLastName")
	public String getCustomerLastName() {
		return customerLastName;
	}

	@JsonProperty("CustomerLastName")
	public void setCustomerLastName(String customerLastName) {
		this.customerLastName = customerLastName;
	}

	@JsonProperty("ReturnStatus")
	public Object getReturnStatus() {
		return returnStatus;
	}

	@JsonProperty("ReturnStatus")
	public void setReturnStatus(Object returnStatus) {
		this.returnStatus = returnStatus;
	}

	@JsonProperty("CapturedDate")
	public Object getCapturedDate() {
		return capturedDate;
	}

	@JsonProperty("CapturedDate")
	public void setCapturedDate(Object capturedDate) {
		this.capturedDate = capturedDate;
	}

	@JsonProperty("CustomerTypeId")
	public Object getCustomerTypeId() {
		return customerTypeId;
	}

	@JsonProperty("CustomerTypeId")
	public void setCustomerTypeId(Object customerTypeId) {
		this.customerTypeId = customerTypeId;
	}

	@JsonProperty("NextEventTime")
	public String getNextEventTime() {
		return nextEventTime;
	}

	@JsonProperty("NextEventTime")
	public void setNextEventTime(String nextEventTime) {
		this.nextEventTime = nextEventTime;
	}

	@JsonProperty("ChangeLog")
	public Object getChangeLog() {
		return changeLog;
	}

	@JsonProperty("ChangeLog")
	public void setChangeLog(Object changeLog) {
		this.changeLog = changeLog;
	}

	@JsonProperty("TotalDiscounts")
	public Object getTotalDiscounts() {
		return totalDiscounts;
	}

	@JsonProperty("TotalDiscounts")
	public void setTotalDiscounts(Object totalDiscounts) {
		this.totalDiscounts = totalDiscounts;
	}

	@JsonProperty("CancelLineCount")
	public Integer getCancelLineCount() {
		return cancelLineCount;
	}

	@JsonProperty("CancelLineCount")
	public void setCancelLineCount(Integer cancelLineCount) {
		this.cancelLineCount = cancelLineCount;
	}

	@JsonProperty("ReturnTrackingDetail")
	public List<Object> getReturnTrackingDetail() {
		return returnTrackingDetail;
	}

	@JsonProperty("ReturnTrackingDetail")
	public void setReturnTrackingDetail(List<Object> returnTrackingDetail) {
		this.returnTrackingDetail = returnTrackingDetail;
	}

	@JsonProperty("IsOnHold")
	public Boolean getIsOnHold() {
		return isOnHold;
	}

	@JsonProperty("IsOnHold")
	public void setIsOnHold(Boolean isOnHold) {
		this.isOnHold = isOnHold;
	}

	@JsonProperty("Process")
	public Object getProcess() {
		return process;
	}

	@JsonProperty("Process")
	public void setProcess(Object process) {
		this.process = process;
	}

	@JsonProperty("IsConfirmed")
	public Boolean getIsConfirmed() {
		return isConfirmed;
	}

	@JsonProperty("IsConfirmed")
	public void setIsConfirmed(Boolean isConfirmed) {
		this.isConfirmed = isConfirmed;
	}

	@JsonProperty("RefundPaymentMethod")
	public Object getRefundPaymentMethod() {
		return refundPaymentMethod;
	}

	@JsonProperty("RefundPaymentMethod")
	public void setRefundPaymentMethod(Object refundPaymentMethod) {
		this.refundPaymentMethod = refundPaymentMethod;
	}

	@JsonProperty("SellingLocationId")
	public Object getSellingLocationId() {
		return sellingLocationId;
	}

	@JsonProperty("SellingLocationId")
	public void setSellingLocationId(Object sellingLocationId) {
		this.sellingLocationId = sellingLocationId;
	}

	@JsonProperty("FulfillmentStatus")
	public String getFulfillmentStatus() {
		return fulfillmentStatus;
	}

	@JsonProperty("FulfillmentStatus")
	public void setFulfillmentStatus(String fulfillmentStatus) {
		this.fulfillmentStatus = fulfillmentStatus;
	}

	@JsonProperty("OrderChargeDetail")
	public List<OrderChargeDetail_> getOrderChargeDetail() {
		return orderChargeDetail;
	}

	@JsonProperty("OrderChargeDetail")
	public void setOrderChargeDetail(List<OrderChargeDetail_> orderChargeDetail) {
		this.orderChargeDetail = orderChargeDetail;
	}

	@JsonProperty("OrderType")
	public OrderType getOrderType() {
		return orderType;
	}

	@JsonProperty("OrderType")
	public void setOrderType(OrderType orderType) {
		this.orderType = orderType;
	}

	@JsonProperty("TotalReturnFees")
	public Integer getTotalReturnFees() {
		return totalReturnFees;
	}

	@JsonProperty("TotalReturnFees")
	public void setTotalReturnFees(Integer totalReturnFees) {
		this.totalReturnFees = totalReturnFees;
	}

	@JsonProperty("CountedDate")
	public String getCountedDate() {
		return countedDate;
	}

	@JsonProperty("CountedDate")
	public void setCountedDate(String countedDate) {
		this.countedDate = countedDate;
	}

	@JsonProperty("TotalCharges")
	public Object getTotalCharges() {
		return totalCharges;
	}

	@JsonProperty("TotalCharges")
	public void setTotalCharges(Object totalCharges) {
		this.totalCharges = totalCharges;
	}

	@JsonProperty("ReturnLineCount")
	public Integer getReturnLineCount() {
		return returnLineCount;
	}

	@JsonProperty("ReturnLineCount")
	public void setReturnLineCount(Integer returnLineCount) {
		this.returnLineCount = returnLineCount;
	}

	@JsonProperty("PaymentStatus")
	public PaymentStatus getPaymentStatus() {
		return paymentStatus;
	}

	@JsonProperty("PaymentStatus")
	public void setPaymentStatus(PaymentStatus paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	@JsonProperty("OrderSalesAssociate")
	public List<Object> getOrderSalesAssociate() {
		return orderSalesAssociate;
	}

	@JsonProperty("OrderSalesAssociate")
	public void setOrderSalesAssociate(List<Object> orderSalesAssociate) {
		this.orderSalesAssociate = orderSalesAssociate;
	}

	@JsonProperty("Priority")
	public Object getPriority() {
		return priority;
	}

	@JsonProperty("Priority")
	public void setPriority(Object priority) {
		this.priority = priority;
	}

	@JsonProperty("StoreReturnCount")
	public Integer getStoreReturnCount() {
		return storeReturnCount;
	}

	@JsonProperty("StoreReturnCount")
	public void setStoreReturnCount(Integer storeReturnCount) {
		this.storeReturnCount = storeReturnCount;
	}

	@JsonProperty("OrderTagDetail")
	public List<Object> getOrderTagDetail() {
		return orderTagDetail;
	}

	@JsonProperty("OrderTagDetail")
	public void setOrderTagDetail(List<Object> orderTagDetail) {
		this.orderTagDetail = orderTagDetail;
	}

	@JsonProperty("OrderId")
	public String getOrderId() {
		return orderId;
	}

	@JsonProperty("OrderId")
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	@JsonProperty("OrderSubTotal")
	public Double getOrderSubTotal() {
		return orderSubTotal;
	}

	@JsonProperty("OrderSubTotal")
	public void setOrderSubTotal(Double orderSubTotal) {
		this.orderSubTotal = orderSubTotal;
	}

	@JsonProperty("OrderCaptureDetail")
	public List<Object> getOrderCaptureDetail() {
		return orderCaptureDetail;
	}

	@JsonProperty("OrderCaptureDetail")
	public void setOrderCaptureDetail(List<Object> orderCaptureDetail) {
		this.orderCaptureDetail = orderCaptureDetail;
	}

	@JsonProperty("CancelReason")
	public Object getCancelReason() {
		return cancelReason;
	}

	@JsonProperty("CancelReason")
	public void setCancelReason(Object cancelReason) {
		this.cancelReason = cancelReason;
	}

	@JsonProperty("ContactPreference")
	public List<Object> getContactPreference() {
		return contactPreference;
	}

	@JsonProperty("ContactPreference")
	public void setContactPreference(List<Object> contactPreference) {
		this.contactPreference = contactPreference;
	}

	@JsonProperty("OrderPromotionRequest")
	public List<Object> getOrderPromotionRequest() {
		return orderPromotionRequest;
	}

	@JsonProperty("OrderPromotionRequest")
	public void setOrderPromotionRequest(List<Object> orderPromotionRequest) {
		this.orderPromotionRequest = orderPromotionRequest;
	}

	@JsonProperty("ConfirmedDate")
	public Object getConfirmedDate() {
		return confirmedDate;
	}

	@JsonProperty("ConfirmedDate")
	public void setConfirmedDate(Object confirmedDate) {
		this.confirmedDate = confirmedDate;
	}

	@JsonProperty("IsReadyForTender")
	public Boolean getIsReadyForTender() {
		return isReadyForTender;
	}

	@JsonProperty("IsReadyForTender")
	public void setIsReadyForTender(Boolean isReadyForTender) {
		this.isReadyForTender = isReadyForTender;
	}

	@JsonProperty("CustomerAddress")
	public Object getCustomerAddress() {
		return customerAddress;
	}

	@JsonProperty("CustomerAddress")
	public void setCustomerAddress(Object customerAddress) {
		this.customerAddress = customerAddress;
	}

	@JsonProperty("TransactionReference")
	public List<Object> getTransactionReference() {
		return transactionReference;
	}

	@JsonProperty("TransactionReference")
	public void setTransactionReference(List<Object> transactionReference) {
		this.transactionReference = transactionReference;
	}

	@JsonProperty("TaxExemptComments")
	public Object getTaxExemptComments() {
		return taxExemptComments;
	}

	@JsonProperty("TaxExemptComments")
	public void setTaxExemptComments(Object taxExemptComments) {
		this.taxExemptComments = taxExemptComments;
	}

	@JsonProperty("CancelledOrderTotal")
	public Object getCancelledOrderTotal() {
		return cancelledOrderTotal;
	}

	@JsonProperty("CancelledOrderTotal")
	public void setCancelledOrderTotal(Object cancelledOrderTotal) {
		this.cancelledOrderTotal = cancelledOrderTotal;
	}

	@JsonProperty("OrderPromisingInfo")
	public Object getOrderPromisingInfo() {
		return orderPromisingInfo;
	}

	@JsonProperty("OrderPromisingInfo")
	public void setOrderPromisingInfo(Object orderPromisingInfo) {
		this.orderPromisingInfo = orderPromisingInfo;
	}

	@JsonProperty("MinReturnStatus")
	public Object getMinReturnStatus() {
		return minReturnStatus;
	}

	@JsonProperty("MinReturnStatus")
	public void setMinReturnStatus(Object minReturnStatus) {
		this.minReturnStatus = minReturnStatus;
	}

	@JsonProperty("OrderTaxDetail")
	public List<Object> getOrderTaxDetail() {
		return orderTaxDetail;
	}

	@JsonProperty("OrderTaxDetail")
	public void setOrderTaxDetail(List<Object> orderTaxDetail) {
		this.orderTaxDetail = orderTaxDetail;
	}

	@JsonProperty("PackageCount")
	public Object getPackageCount() {
		return packageCount;
	}

	@JsonProperty("PackageCount")
	public void setPackageCount(Object packageCount) {
		this.packageCount = packageCount;
	}

	@JsonProperty("SellingChannel")
	public SellingChannel getSellingChannel() {
		return sellingChannel;
	}

	@JsonProperty("SellingChannel")
	public void setSellingChannel(SellingChannel sellingChannel) {
		this.sellingChannel = sellingChannel;
	}

	@JsonProperty("Release")
	public List<Release> getRelease() {
		return release;
	}

	@JsonProperty("Release")
	public void setRelease(List<Release> release) {
		this.release = release;
	}

	@JsonProperty("ReturnTotalWithoutFees")
	public Integer getReturnTotalWithoutFees() {
		return returnTotalWithoutFees;
	}

	@JsonProperty("ReturnTotalWithoutFees")
	public void setReturnTotalWithoutFees(Integer returnTotalWithoutFees) {
		this.returnTotalWithoutFees = returnTotalWithoutFees;
	}

	@JsonProperty("MaxReturnStatusId")
	public Object getMaxReturnStatusId() {
		return maxReturnStatusId;
	}

	@JsonProperty("MaxReturnStatusId")
	public void setMaxReturnStatusId(Object maxReturnStatusId) {
		this.maxReturnStatusId = maxReturnStatusId;
	}

	@JsonProperty("MerchReturnLineCount")
	public Integer getMerchReturnLineCount() {
		return merchReturnLineCount;
	}

	@JsonProperty("MerchReturnLineCount")
	public void setMerchReturnLineCount(Integer merchReturnLineCount) {
		this.merchReturnLineCount = merchReturnLineCount;
	}

	@JsonProperty("ProcessInfo")
	public Object getProcessInfo() {
		return processInfo;
	}

	@JsonProperty("ProcessInfo")
	public void setProcessInfo(Object processInfo) {
		this.processInfo = processInfo;
	}

	@JsonProperty("CancelComments")
	public Object getCancelComments() {
		return cancelComments;
	}

	@JsonProperty("CancelComments")
	public void setCancelComments(Object cancelComments) {
		this.cancelComments = cancelComments;
	}

	@JsonProperty("MaxFulfillmentStatus")
	public MaxFulfillmentStatus_ getMaxFulfillmentStatus() {
		return maxFulfillmentStatus;
	}

	@JsonProperty("MaxFulfillmentStatus")
	public void setMaxFulfillmentStatus(MaxFulfillmentStatus_ maxFulfillmentStatus) {
		this.maxFulfillmentStatus = maxFulfillmentStatus;
	}

	@JsonProperty("OrderMilestone")
	public List<OrderMilestone> getOrderMilestone() {
		return orderMilestone;
	}

	@JsonProperty("OrderMilestone")
	public void setOrderMilestone(List<OrderMilestone> orderMilestone) {
		this.orderMilestone = orderMilestone;
	}

	@JsonProperty("TotalTaxes")
	public Double getTotalTaxes() {
		return totalTaxes;
	}

	@JsonProperty("TotalTaxes")
	public void setTotalTaxes(Double totalTaxes) {
		this.totalTaxes = totalTaxes;
	}

	@JsonProperty("PK")
	public String getPK() {
		return pK;
	}

	@JsonProperty("PK")
	public void setPK(String pK) {
		this.pK = pK;
	}

	@JsonProperty("OrderTotal")
	public Double getOrderTotal() {
		return orderTotal;
	}

	@JsonProperty("OrderTotal")
	public void setOrderTotal(Double orderTotal) {
		this.orderTotal = orderTotal;
	}

	@JsonProperty("Payment")
	public List<Payment> getPayment() {
		return payment;
	}

	@JsonProperty("Payment")
	public void setPayment(List<Payment> payment) {
		this.payment = payment;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

}
