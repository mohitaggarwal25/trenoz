package com.dxl.oms.bean.inventory.network;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
	"Suppliers",
	"DistributionCenters",
	"Stores"
})
public class Quantity {

	@JsonProperty("Suppliers")
	private Integer suppliers;
	@JsonProperty("DistributionCenters")
	private Integer distributionCenters;
	@JsonProperty("Stores")
	private Integer stores;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	@JsonProperty("Suppliers")
	public Integer getSuppliers() {
		return suppliers;
	}

	@JsonProperty("Suppliers")
	public void setSuppliers(Integer suppliers) {
		this.suppliers = suppliers;
	}

	@JsonProperty("DistributionCenters")
	public Integer getDistributionCenters() {
		return distributionCenters;
	}

	@JsonProperty("DistributionCenters")
	public void setDistributionCenters(Integer distributionCenters) {
		this.distributionCenters = distributionCenters;
	}

	@JsonProperty("Stores")
	public Integer getStores() {
		return stores;
	}

	@JsonProperty("Stores")
	public void setStores(Integer stores) {
		this.stores = stores;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

}