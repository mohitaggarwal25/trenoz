package com.dxl.oms.bean.inventory.network;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
	"ItemId",
	"Status",
	"StatusCode",
	"NextAvailabilityDate",
	"ViewName",
	"ViewId",
	"TransactionDateTime",
	"Quantity",
	"NetworkProtectionQuantity",
	"TotalQuantity"
})
public class Datum {

	@JsonProperty("ItemId")
	private String itemId;
	@JsonProperty("Status")
	private String status;
	@JsonProperty("StatusCode")
	private Integer statusCode;
	@JsonProperty("NextAvailabilityDate")
	private Object nextAvailabilityDate;
	@JsonProperty("ViewName")
	private String viewName;
	@JsonProperty("ViewId")
	private String viewId;
	@JsonProperty("TransactionDateTime")
	private String transactionDateTime;
	@JsonProperty("Quantity")
	private Quantity quantity;
	@JsonProperty("NetworkProtectionQuantity")
	private NetworkProtectionQuantity networkProtectionQuantity;
	@JsonProperty("TotalQuantity")
	private Integer totalQuantity;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	@JsonProperty("ItemId")
	public String getItemId() {
		return itemId;
	}

	@JsonProperty("ItemId")
	public void setItemId(String itemId) {
		this.itemId = itemId;
	}

	@JsonProperty("Status")
	public String getStatus() {
		return status;
	}

	@JsonProperty("Status")
	public void setStatus(String status) {
		this.status = status;
	}

	@JsonProperty("StatusCode")
	public Integer getStatusCode() {
		return statusCode;
	}

	@JsonProperty("StatusCode")
	public void setStatusCode(Integer statusCode) {
		this.statusCode = statusCode;
	}

	@JsonProperty("NextAvailabilityDate")
	public Object getNextAvailabilityDate() {
		return nextAvailabilityDate;
	}

	@JsonProperty("NextAvailabilityDate")
	public void setNextAvailabilityDate(Object nextAvailabilityDate) {
		this.nextAvailabilityDate = nextAvailabilityDate;
	}

	@JsonProperty("ViewName")
	public String getViewName() {
		return viewName;
	}

	@JsonProperty("ViewName")
	public void setViewName(String viewName) {
		this.viewName = viewName;
	}

	@JsonProperty("ViewId")
	public String getViewId() {
		return viewId;
	}

	@JsonProperty("ViewId")
	public void setViewId(String viewId) {
		this.viewId = viewId;
	}

	@JsonProperty("TransactionDateTime")
	public String getTransactionDateTime() {
		return transactionDateTime;
	}

	@JsonProperty("TransactionDateTime")
	public void setTransactionDateTime(String transactionDateTime) {
		this.transactionDateTime = transactionDateTime;
	}

	@JsonProperty("Quantity")
	public Quantity getQuantity() {
		return quantity;
	}

	@JsonProperty("Quantity")
	public void setQuantity(Quantity quantity) {
		this.quantity = quantity;
	}

	@JsonProperty("NetworkProtectionQuantity")
	public NetworkProtectionQuantity getNetworkProtectionQuantity() {
		return networkProtectionQuantity;
	}

	@JsonProperty("NetworkProtectionQuantity")
	public void setNetworkProtectionQuantity(NetworkProtectionQuantity networkProtectionQuantity) {
		this.networkProtectionQuantity = networkProtectionQuantity;
	}

	@JsonProperty("TotalQuantity")
	public Integer getTotalQuantity() {
		return totalQuantity;
	}

	@JsonProperty("TotalQuantity")
	public void setTotalQuantity(Integer totalQuantity) {
		this.totalQuantity = totalQuantity;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

}
