
package com.dxl.oms.bean.ordersearch;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "Status",
    "UpdatedTimestamp",
    "CreatedBy",
    "CreatedTimestamp",
    "QuantityDetailId",
    "Quantity",
    "Process",
    "SubstitutionRatio",
    "ItemId",
    "Reason",
    "OrgId",
    "SubstitutionType",
    "UpdatedBy",
    "UOM",
    "ContextId",
    "StatusId",
    "ReasonType",
    "PK",
    "ChangeLog"
})
public class QuantityDetail {

    @JsonProperty("Status")
    private Status_ status;
    @JsonProperty("UpdatedTimestamp")
    private String updatedTimestamp;
    @JsonProperty("CreatedBy")
    private String createdBy;
    @JsonProperty("CreatedTimestamp")
    private String createdTimestamp;
    @JsonProperty("QuantityDetailId")
    private String quantityDetailId;
    @JsonProperty("Quantity")
    private Integer quantity;
    @JsonProperty("Process")
    private Object process;
    @JsonProperty("SubstitutionRatio")
    private Object substitutionRatio;
    @JsonProperty("ItemId")
    private String itemId;
    @JsonProperty("Reason")
    private Object reason;
    @JsonProperty("OrgId")
    private String orgId;
    @JsonProperty("SubstitutionType")
    private Object substitutionType;
    @JsonProperty("UpdatedBy")
    private String updatedBy;
    @JsonProperty("UOM")
    private String uOM;
    @JsonProperty("ContextId")
    private String contextId;
    @JsonProperty("StatusId")
    private String statusId;
    @JsonProperty("ReasonType")
    private Object reasonType;
    @JsonProperty("PK")
    private String pK;
    @JsonProperty("ChangeLog")
    private Object changeLog;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("Status")
    public Status_ getStatus() {
        return status;
    }

    @JsonProperty("Status")
    public void setStatus(Status_ status) {
        this.status = status;
    }

    @JsonProperty("UpdatedTimestamp")
    public String getUpdatedTimestamp() {
        return updatedTimestamp;
    }

    @JsonProperty("UpdatedTimestamp")
    public void setUpdatedTimestamp(String updatedTimestamp) {
        this.updatedTimestamp = updatedTimestamp;
    }

    @JsonProperty("CreatedBy")
    public String getCreatedBy() {
        return createdBy;
    }

    @JsonProperty("CreatedBy")
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    @JsonProperty("CreatedTimestamp")
    public String getCreatedTimestamp() {
        return createdTimestamp;
    }

    @JsonProperty("CreatedTimestamp")
    public void setCreatedTimestamp(String createdTimestamp) {
        this.createdTimestamp = createdTimestamp;
    }

    @JsonProperty("QuantityDetailId")
    public String getQuantityDetailId() {
        return quantityDetailId;
    }

    @JsonProperty("QuantityDetailId")
    public void setQuantityDetailId(String quantityDetailId) {
        this.quantityDetailId = quantityDetailId;
    }

    @JsonProperty("Quantity")
    public Integer getQuantity() {
        return quantity;
    }

    @JsonProperty("Quantity")
    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    @JsonProperty("Process")
    public Object getProcess() {
        return process;
    }

    @JsonProperty("Process")
    public void setProcess(Object process) {
        this.process = process;
    }

    @JsonProperty("SubstitutionRatio")
    public Object getSubstitutionRatio() {
        return substitutionRatio;
    }

    @JsonProperty("SubstitutionRatio")
    public void setSubstitutionRatio(Object substitutionRatio) {
        this.substitutionRatio = substitutionRatio;
    }

    @JsonProperty("ItemId")
    public String getItemId() {
        return itemId;
    }

    @JsonProperty("ItemId")
    public void setItemId(String itemId) {
        this.itemId = itemId;
    }

    @JsonProperty("Reason")
    public Object getReason() {
        return reason;
    }

    @JsonProperty("Reason")
    public void setReason(Object reason) {
        this.reason = reason;
    }

    @JsonProperty("OrgId")
    public String getOrgId() {
        return orgId;
    }

    @JsonProperty("OrgId")
    public void setOrgId(String orgId) {
        this.orgId = orgId;
    }

    @JsonProperty("SubstitutionType")
    public Object getSubstitutionType() {
        return substitutionType;
    }

    @JsonProperty("SubstitutionType")
    public void setSubstitutionType(Object substitutionType) {
        this.substitutionType = substitutionType;
    }

    @JsonProperty("UpdatedBy")
    public String getUpdatedBy() {
        return updatedBy;
    }

    @JsonProperty("UpdatedBy")
    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    @JsonProperty("UOM")
    public String getUOM() {
        return uOM;
    }

    @JsonProperty("UOM")
    public void setUOM(String uOM) {
        this.uOM = uOM;
    }

    @JsonProperty("ContextId")
    public String getContextId() {
        return contextId;
    }

    @JsonProperty("ContextId")
    public void setContextId(String contextId) {
        this.contextId = contextId;
    }

    @JsonProperty("StatusId")
    public String getStatusId() {
        return statusId;
    }

    @JsonProperty("StatusId")
    public void setStatusId(String statusId) {
        this.statusId = statusId;
    }

    @JsonProperty("ReasonType")
    public Object getReasonType() {
        return reasonType;
    }

    @JsonProperty("ReasonType")
    public void setReasonType(Object reasonType) {
        this.reasonType = reasonType;
    }

    @JsonProperty("PK")
    public String getPK() {
        return pK;
    }

    @JsonProperty("PK")
    public void setPK(String pK) {
        this.pK = pK;
    }

    @JsonProperty("ChangeLog")
    public Object getChangeLog() {
        return changeLog;
    }

    @JsonProperty("ChangeLog")
    public void setChangeLog(Object changeLog) {
        this.changeLog = changeLog;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
